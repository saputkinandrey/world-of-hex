import {CreatureTemplateLensEntity} from "../../domain/character/creature-template-lens.entity";

export const IQ2CreatureLens = new CreatureTemplateLensEntity({
    name: 'IQ2 Creature',
    memeIdsAdd: [
        "cog.iq2"
    ],
    actionTagsAdd: [

    ],
});
