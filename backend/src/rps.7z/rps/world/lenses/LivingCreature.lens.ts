import {CreatureTemplateLensEntity} from "../../domain/character/creature-template-lens.entity";
import {ActionTag} from "../actions/action-tags";

export const LivingCreatureLens = new CreatureTemplateLensEntity({
    name: 'Living Creature',
    memeIdsAdd: [

    ],
    morphIdsAdd: [
        "core.motor_coordination",
        "core.perception",
        "core.vital.living",
    ],
    actionTagsAdd: [
        "EAT" as ActionTag,
        'DRINK' as ActionTag,
        "SLEEP" as ActionTag,
    ],
});
