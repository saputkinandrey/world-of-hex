// domain/creature/creature-template-lens.entity.ts

import { NamedEntity } from '../base/named.entity';
import type { MemeId } from '../../world/memes';
import type { MorphId } from '../../world/morphs';
import type { CreatureTemplateLens } from './creature-template.entity';
import {ActionTag} from "../../from-gpt/action-tags";

export interface CreatureTemplateLensProps {
    name?: string;
    alias?: string;

    sizeModifierDelta?: number;

    primaryDelta?: CreatureTemplateLens['primaryDelta'];
    secondaryDelta?: CreatureTemplateLens['secondaryDelta'];

    memeIdsAdd?: MemeId[];
    morphIdsAdd?: MorphId[];
    actionTagsAdd?: ActionTag[];
}

/**
 * Линза для CreatureTemplate как полноценная доменная сущность.
 *
 * Можно:
 *  - хранить коллекции линз отдельно,
 *  - версионировать через event-sourcing,
 *  - навешивать их на шаблоны/персонажей по имени/идентификатору.
 */
export class CreatureTemplateLensEntity extends NamedEntity implements CreatureTemplateLens {
    sizeModifierDelta?: number;

    primaryDelta?: CreatureTemplateLens['primaryDelta'];
    secondaryDelta?: CreatureTemplateLens['secondaryDelta'];

    memeIdsAdd: MemeId[] = [];
    morphIdsAdd: MorphId[] = [];
    actionTagsAdd: ActionTag[] = [];

    constructor(props: CreatureTemplateLensProps = {}) {
        const {
            name = '',
            alias = '',
        } = props;

        super({ name, alias });

        this
            .setSizeModifierDelta(props.sizeModifierDelta)
            .setPrimaryDelta(props.primaryDelta)
            .setSecondaryDelta(props.secondaryDelta)
            .setMemeIdsAdd(props.memeIdsAdd)
            .setMorphIdsAdd(props.morphIdsAdd)
            .setActionTagsAdd(props.actionTagsAdd);
    }

    setSizeModifierDelta(delta?: number | null): this {
        if (typeof delta === 'number' && !Number.isNaN(delta)) {
            this.sizeModifierDelta = delta;
        } else {
            this.sizeModifierDelta = undefined;
        }
        return this;
    }

    setPrimaryDelta(delta?: CreatureTemplateLens['primaryDelta'] | null): this {
        if (delta && Object.keys(delta).length > 0) {
            this.primaryDelta = { ...delta };
        } else {
            this.primaryDelta = undefined;
        }
        return this;
    }

    setSecondaryDelta(delta?: CreatureTemplateLens['secondaryDelta'] | null): this {
        if (delta && Object.keys(delta).length > 0) {
            this.secondaryDelta = { ...delta };
        } else {
            this.secondaryDelta = undefined;
        }
        return this;
    }

    setMemeIdsAdd(memeIds?: MemeId[] | null): this {
        if (Array.isArray(memeIds)) {
            this.memeIdsAdd = [...memeIds];
        } else {
            this.memeIdsAdd = [];
        }
        return this;
    }

    setMorphIdsAdd(morphIds?: MorphId[] | null): this {
        if (Array.isArray(morphIds)) {
            this.morphIdsAdd = [...morphIds];
        } else {
            this.morphIdsAdd = [];
        }
        return this;
    }

    setActionTagsAdd(actionTags?: string[] | null): this {
        if (Array.isArray(actionTags)) {
            this.actionTagsAdd = [...actionTags];
        } else {
            this.actionTagsAdd = [];
        }
        return this;
    }
}
