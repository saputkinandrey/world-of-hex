import { EquipmentEntity } from '../../../domain/character/inventory/equipment/equipment.entity';

export type SaveArmourResponsePayloadDto = EquipmentEntity;
