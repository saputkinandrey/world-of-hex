
export type LoadEncounterResponsePayloadDto = object
