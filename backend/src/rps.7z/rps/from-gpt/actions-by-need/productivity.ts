import { ActionDefinition } from '../action-definition';
import { ProductivityActionTag } from '../action-tags';
import { cog, comm, culture, econ, health, org, record } from '../../world/memes';
export const ProductivityActions: ActionDefinition[] = [
    {
        tag: ProductivityActionTag.MORNING_TALLY_AND_BRIEF,
        costEnergy: -0.08,
        costTime: 0.8,
        rewardSecondary: {
            PRODUCTIVITY: 0.65,
            CLARITY: 0.5,
            ORDER: 0.4,
            FOCUS: 0.3,
        },
        requiresLocation: 'workyard|guild_hall',
        tradeEffect: { chalk: -1, board_use: '+1' },
        socialImpact: { DISCIPLINE: 0.3, TRUST: 0.2 },
        ownershipEffect: { accessScope: 'task_board', grantAccess: true },
        lawEffect: { rosterPosted: 'yes', enforceable: true },
        requiredMemes: [
            comm.language.written,
            org.duty_roster,
            record.ledgerkeeping,
            cog.number_concept,
            org.workshop_practice,
        ]
    },
    {
        tag: ProductivityActionTag.TASK_BOARD_PULL_TOKENS,
        costEnergy: -0.06,
        costTime: 0.6,
        rewardSecondary: {
            PRODUCTIVITY: 0.6,
            EFFICIENCY: 0.4,
            ORDER: 0.3,
            FOCUS: 0.3,
        },
        requiresLocation: 'task_board',
        tradeEffect: { tokens: '-move' },
        socialImpact: { ACCOUNTABILITY: 0.3 as any, CLARITY: 0.3 },
        ownershipEffect: { workItem: 'claimed' },
        lawEffect: { queueRule: 'pull_not_push', enforceable: true },
        requiredMemes: [
            comm.language.written,
            record.ledgerkeeping,
            econ.pooling_common_fund,
        ]
    },
    {
        tag: ProductivityActionTag.SET_WIP_LIMITS,
        costEnergy: -0.08,
        costTime: 0.8,
        rewardSecondary: {
            PRODUCTIVITY: 0.65,
            EFFICIENCY: 0.5,
            QUALITY: 0.3,
            ORDER: 0.4,
        },
        socialImpact: { DISCIPLINE: 0.4, FAIRNESS: 0.2 },
        lawEffect: { wipMax: 'posted', enforceable: true }
    },
    {
        tag: ProductivityActionTag.STANDARDIZE_WORK_STEPS,
        costEnergy: -0.12,
        costTime: 1.2,
        rewardSecondary: {
            PRODUCTIVITY: 0.7,
            QUALITY: 0.5,
            EFFICIENCY: 0.4,
            CLARITY: 0.4,
        },
        tradeEffect: { parchment: -1, ink: -1 },
        socialImpact: { INTEGRITY: 0.3, ORDER: 0.4 },
        ownershipEffect: { standardSheet: 'created', archive: 'yes' },
        lawEffect: { guildStandard: 'ratified', enforceable: true },
        requiredMemes: [comm.language.written]
    },
    {
        tag: ProductivityActionTag.TOOLS_MAINTENANCE_ROTA,
        costEnergy: -0.16,
        costTime: 1.4,
        rewardSecondary: {
            PRODUCTIVITY: 0.7,
            EFFICIENCY: 0.4,
            QUALITY: 0.3,
            STABILITY: 0.3,
        },
        tradeEffect: { oil: -1, whetstone_wear: '-minor' },
        socialImpact: { RESPONSIBILITY: 0.3 as any, TRUST: 0.2 },
        ownershipEffect: { toolState: 'maintained' },
        lawEffect: { rota: 'logged', enforceable: true }
    },
    {
        tag: ProductivityActionTag.BENCH_LAYOUT_STREAMLINE,
        costEnergy: -0.2,
        costTime: 1.6,
        rewardSecondary: {
            PRODUCTIVITY: 0.75,
            EFFICIENCY: 0.6,
            ORDER: 0.4,
            SAFETY: 0.2 as any,
        },
        requiresLocation: 'workshop',
        tradeEffect: { labor: '-rearrange', chalk: -1 },
        socialImpact: { COORDINATION: 0.3 as any, DISCIPLINE: 0.2 },
        ownershipEffect: { layout: 'streamlined' },
        requiredMemes: [
            comm.language.written,
            org.workshop_practice,
        ]
    },
    {
        tag: ProductivityActionTag.BATCH_PREP_MATERIALS,
        costEnergy: -0.18,
        costTime: 1.6,
        rewardSecondary: {
            PRODUCTIVITY: 0.7,
            EFFICIENCY: 0.5,
            STABILITY: 0.3,
            ORDER: 0.3,
        },
        tradeEffect: { raw_materials: '-N' as any, blanks: '+N' },
        socialImpact: { READINESS: 0.3 as any, TRUST: 0.1 },
        ownershipEffect: { storesLevel: 'raised' }
    },
    {
        tag: ProductivityActionTag.CROSS_TRAIN_PAIRING,
        costEnergy: -0.16,
        costTime: 1.8,
        rewardSecondary: {
            PRODUCTIVITY: 0.75,
            MASTERY: 0.4,
            RESILIENCE: 0.3,
            EFFICIENCY: 0.3,
        },
        requiresSkill: 'teaching|apprentice',
        socialImpact: { LOYALTY: 0.2, COMMUNITY: 0.2 },
        ownershipEffect: { accessScope: 'bench_guest', grantAccess: true },
        lawEffect: { apprenticeRoll: 'updated', enforceable: true }
    },
    {
        tag: ProductivityActionTag.PRIORITIZE_HIGH_IMPACT,
        costEnergy: -0.1,
        costTime: 0.9,
        rewardSecondary: {
            PRODUCTIVITY: 0.7,
            CLARITY: 0.5,
            WEALTH: 0.3,
            ORDER: 0.3,
        },
        socialImpact: { DISCIPLINE: 0.3, FAIRNESS: 0.2 },
        lawEffect: { priorityRule: 'value_first', enforceable: true }
    },
    {
        tag: ProductivityActionTag.REMOVE_BOTTLENECK,
        costEnergy: -0.2,
        costTime: 1.6,
        risk: 0.1,
        rewardSecondary: {
            PRODUCTIVITY: 0.8,
            EFFICIENCY: 0.6,
            STABILITY: 0.4,
            CLARITY: 0.3,
        },
        tradeEffect: { reassign_workers: '+2', idle_loss: '-1' },
        socialImpact: { COORDINATION: 0.4 as any, RESENTMENT: -0.1 },
        lawEffect: { dutyRota: 'amended', enforceable: true }
    },
    {
        tag: ProductivityActionTag.MEASURE_THROUGHPUT_TALLY,
        costEnergy: -0.08,
        costTime: 0.8,
        rewardSecondary: {
            PRODUCTIVITY: 0.6,
            CLARITY: 0.5,
            EFFICIENCY: 0.3,
            QUALITY: 0.2,
        },
        requiresItem: ['tally_sticks|abacus'],
        tradeEffect: { ink: '-1 | 0' as any },
        socialImpact: { TRANSPARENCY: 0.3 as any, TRUST: 0.2 },
        ownershipEffect: { tallyLog: 'updated' },
        lawEffect: { ledgerPolicy: 'accurate_entry', enforceable: true },
        requiredMemes: [
            comm.language.written,
            record.ledgerkeeping,
            cog.number_concept,
        ]
    },
    {
        tag: ProductivityActionTag.QUALITY_CHECK_AT_SOURCE,
        costEnergy: -0.1,
        costTime: 1.0,
        rewardSecondary: {
            PRODUCTIVITY: 0.7,
            QUALITY: 0.6,
            EFFICIENCY: 0.3,
            WASTE: -0.2 as any,
        },
        requiresLocation: 'workbench',
        socialImpact: { INTEGRITY: 0.3, RESPECT: 0.2 },
        lawEffect: { defectStopRule: 'worker_can_stop', enforceable: true },
        requiredMemes: [
            health.sanitation_norms,
            health.waste_handling,
        ]
    },
    {
        tag: ProductivityActionTag.MIDDAY_SYNCH_AND_REALLOC,
        costEnergy: -0.1,
        costTime: 0.9,
        rewardSecondary: {
            PRODUCTIVITY: 0.65,
            EFFICIENCY: 0.4,
            ORDER: 0.3,
            CLARITY: 0.3,
        },
        requiresLocation: 'workyard',
        socialImpact: { COORDINATION: 0.4 as any, TRUST: 0.2 },
        ownershipEffect: { accessScope: 'task_board', grantAccess: true },
        requiredMemes: [comm.language.written]
    },
    {
        tag: ProductivityActionTag.BUFFER_STOCK_ESTABLISH,
        costEnergy: -0.18,
        costTime: 1.6,
        rewardSecondary: {
            PRODUCTIVITY: 0.7,
            STABILITY: 0.5,
            RESILIENCE: 0.4,
            EFFICIENCY: 0.2,
        },
        tradeEffect: { blanks: '+N', storage_space: '-capacity' },
        socialImpact: { READINESS: 0.3 as any },
        ownershipEffect: { storeState: 'buffered' },
        lawEffect: { storeLedger: 'updated', enforceable: true }
    },
    {
        tag: ProductivityActionTag.SHIFT_HANDOFF_RITUAL,
        costEnergy: -0.08,
        costTime: 0.8,
        rewardSecondary: {
            PRODUCTIVITY: 0.65,
            ORDER: 0.4,
            CLARITY: 0.4,
            QUALITY: 0.3,
        },
        requiresLocation: 'workbench|gate',
        tradeEffect: { seal_wax: '-1 | 0' as any },
        socialImpact: { TRUST: 0.3, DISCIPLINE: 0.3 },
        ownershipEffect: {
            logbook: 'signed',
            accessScope: 'shift_area',
            grantAccess: true,
        },
        lawEffect: { handoffRule: 'required', enforceable: true },
        requiredMemes: [
            culture.vigil_ritual,
            cog.timekeeping.basic,
            record.ledgerkeeping,
            econ.pooling_common_fund,
        ]
    },
    {
        tag: ProductivityActionTag.FAIR_REWARD_DISTRIBUTION,
        costEnergy: -0.1,
        costTime: 1.0,
        rewardSecondary: {
            PRODUCTIVITY: 0.8,
            FAIRNESS: 0.6,
            MORALE: 0.5,
            STABILITY: 0.3,
        },
        requiresLocation: 'hall|yard',
        tradeEffect: { coin_purse: '-distributed' },
        socialImpact: { TRUST: 0.4, LOYALTY: 0.3, RESENTMENT: -0.2 },
        lawEffect: { rewardLedger: 'posted', enforceable: true },
        requiredMemes: [
            health.sanitation_norms,
            health.waste_handling,
            comm.language.written,
            record.ledgerkeeping,
        ]
    },
];
