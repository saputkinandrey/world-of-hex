import { ActionDefinition } from '../action-definition';
import { SocialNeedActionTag } from '../action-tags';
import { cog, comm, culture, health, org, tech } from '../../world/memes';
export const SocialNeedActions: ActionDefinition[] = [
    {
        tag: SocialNeedActionTag.GREET_NEIGHBORS,
        costEnergy: -0.02,
        costTime: 0.3,
        rewardSecondary: { SOCIAL: 0.45, COMMUNITY: 0.2, RESPECT: 0.1 },
        socialImpact: { SOCIAL: 0.35, TRUST: 0.2 },
        lawEffect: { etiquette: 'observed', enforceable: false }
    },
    {
        tag: SocialNeedActionTag.SMALL_TALK_MARKET,
        costEnergy: -0.04,
        costTime: 0.8,
        risk: 0.06,
        rewardSecondary: { SOCIAL: 0.5, NETWORK: 0.25, CLARITY: 0.1 },
        requiresLocation: 'market_square',
        socialImpact: { SOCIAL: 0.45, REPUTATION: 0.1, RUMOR: 0.05 as any },
        lawEffect: { speechRule: 'no_defamation', enforceable: true },
        requiredMemes: [
            health.sanitation_norms,
            health.waste_handling,
            comm.language.written,
        ]
    },
    {
        tag: SocialNeedActionTag.SHARE_NEWS_BULLETIN,
        costEnergy: -0.06,
        costTime: 0.9,
        rewardSecondary: { SOCIAL: 0.5, COMMUNITY: 0.3, CLARITY: 0.25 },
        tradeEffect: { parchment: -1, ink: -1 },
        socialImpact: { SOCIAL: 0.5, TRUST: 0.2, PANIC: -0.1 as any },
        lawEffect: { bulletinPermit: 'approved', enforceable: true },
        ownershipEffect: { accessScope: 'notice_board', grantAccess: true },
        requiredMemes: [comm.language.written]
    },
    {
        tag: SocialNeedActionTag.VISIT_RELATIVES,
        costEnergy: -0.08,
        costTime: 1.4,
        rewardSecondary: { SOCIAL: 0.55, FAMILY: 0.4, AFFECTION: 0.3 },
        socialImpact: { SOCIAL: 0.5, LOYALTY: 0.2 }
    },
    {
        tag: SocialNeedActionTag.HOST_TEAHOUSE_TABLE,
        costEnergy: -0.12,
        costTime: 1.6,
        rewardSecondary: { SOCIAL: 0.6, NETWORK: 0.4, STATUS: 0.2 },
        requiresLocation: 'teahouse|tavern',
        tradeEffect: { tea: -2, bread: -1, table_fee: -1 },
        socialImpact: { SOCIAL: 0.6, COHESION: 0.3, VISIBILITY: 0.2 },
        lawEffect: { gatheringPermit: 'not_required', enforceable: false }
    },
    {
        tag: SocialNeedActionTag.HELP_WITH_CHORES,
        costEnergy: -0.18,
        costTime: 1.6,
        rewardSecondary: { SOCIAL: 0.55, COMMUNITY: 0.5, FAIRNESS: 0.2 },
        socialImpact: { SOCIAL: 0.6, GRATITUDE: 0.4, TRUST: 0.3 },
        ownershipEffect: { reciprocityCredit: '+1' }
    },
    {
        tag: SocialNeedActionTag.INTRODUCE_CONTACTS,
        costEnergy: -0.06,
        costTime: 0.8,
        risk: 0.08,
        rewardSecondary: { SOCIAL: 0.55, NETWORK: 0.5, STATUS: 0.1 },
        socialImpact: { SOCIAL: 0.55, TRUST: 0.2, BROKER_REP: 0.2 as any },
        lawEffect: { patronageRule: 'disclose_conflict', enforceable: true }
    },
    {
        tag: SocialNeedActionTag.MEDIATE_DISPUTE,
        costEnergy: -0.2,
        costTime: 1.8,
        risk: 0.15,
        rewardSecondary: { SOCIAL: 0.6, JUSTICE: 0.4, STABILITY: 0.4 },
        requiresSkill: 'mediation',
        socialImpact: { SOCIAL: 0.6, TRUST: 0.4, RESENTMENT: -0.1 },
        lawEffect: { mediationRecord: 'filed', enforceable: true }
    },
    {
        tag: SocialNeedActionTag.JOIN_COMMON_WORK,
        costEnergy: -0.22,
        costTime: 2.0,
        rewardSecondary: { SOCIAL: 0.55, COMMUNITY: 0.6, ORDER: 0.3 },
        requiresLocation: 'common_field|yard',
        tradeEffect: { tools_wear: '-minor' },
        socialImpact: { SOCIAL: 0.6, COHESION: 0.5, EFFICIENCY: 0.2 },
        lawEffect: { rota: 'volunteer', enforceable: false },
        requiredMemes: [
            health.sanitation_norms,
            health.waste_handling,
            tech.tool.use_basic,
            comm.language.written,
        ]
    },
    {
        tag: SocialNeedActionTag.SING_ALONG_EVENING,
        costEnergy: -0.12,
        costTime: 1.6,
        rewardSecondary: { SOCIAL: 0.65, MOOD: 0.5, CULTURE: 0.3 },
        tradeEffect: { musician_fee: -1 as any },
        socialImpact: { SOCIAL: 0.65, UNITY: 0.4 as any, JOY: 0.4 as any },
        lawEffect: { quietHours: 'respected', enforceable: true }
    },
    {
        tag: SocialNeedActionTag.EXCHANGE_GIFTS,
        costEnergy: -0.08,
        costTime: 1.0,
        rewardSecondary: { SOCIAL: 0.6, AFFECTION: 0.4, TRUST: 0.2 },
        tradeEffect: { gifts_out: -1, gifts_in: '+1' },
        socialImpact: { SOCIAL: 0.6, REPUTATION: 0.2 },
        lawEffect: { giftPolicy: 'no_bribe', enforceable: true }
    },
    {
        tag: SocialNeedActionTag.VISIT_SICK,
        costEnergy: -0.14,
        costTime: 1.4,
        rewardSecondary: { SOCIAL: 0.6, FAMILY: 0.3, SPIRIT: 0.2 },
        tradeEffect: { broth: -1, herbs: -1 },
        socialImpact: { SOCIAL: 0.65, COMPASSION: 0.5 as any, LOYALTY: 0.2 },
        lawEffect: { sickroomEtiquette: 'observed', enforceable: true }
    },
    {
        tag: SocialNeedActionTag.CELEBRATE_NAME_DAY,
        costEnergy: -0.18,
        costTime: 1.8,
        rewardSecondary: { SOCIAL: 0.7, MOOD: 0.5, IDENTITY: 0.4 },
        requiresLocation: 'home|hall',
        tradeEffect: { sweets: -2, drink: -2 },
        socialImpact: { SOCIAL: 0.7, COHESION: 0.4, VISIBILITY: 0.3 },
        lawEffect: { gatheringPermit: 'not_required', enforceable: false },
        requiredMemes: [comm.language.written]
    },
    {
        tag: SocialNeedActionTag.FORM_INTEREST_CIRCLE,
        costEnergy: -0.16,
        costTime: 1.8,
        rewardSecondary: { SOCIAL: 0.65, NETWORK: 0.5, MASTERY: 0.2 },
        requiresLocation: 'hall|workshop',
        tradeEffect: { tea_and_bread: -1 },
        socialImpact: { SOCIAL: 0.65, COORDINATION: 0.4 as any, RESPECT: 0.2 },
        lawEffect: { circleCharter: 'noted', enforceable: true },
        ownershipEffect: { accessScope: 'circle_room', grantAccess: true },
        requiredMemes: [
            comm.language.written,
            org.workshop_practice,
        ]
    },
    {
        tag: SocialNeedActionTag.MENTOR_JUNIOR,
        costEnergy: -0.2,
        costTime: 2.0,
        rewardSecondary: { SOCIAL: 0.6, MASTERY: 0.5, FAMILY: 0.2 },
        socialImpact: { SOCIAL: 0.6, RESPECT: 0.4, CONTINUITY: 0.4 as any },
        lawEffect: { mentorshipRoll: 'filed', enforceable: true }
    },
    {
        tag: SocialNeedActionTag.NEIGHBORHOOD_WATCH,
        costEnergy: -0.22,
        costTime: 2.0,
        rewardSecondary: { SOCIAL: 0.55, SECURITY: 0.5, TRUST: 0.3 },
        requiresLocation: 'streets|gates',
        socialImpact: { SOCIAL: 0.6, READINESS: 0.4 as any, FEAR: -0.15 },
        lawEffect: { watchRoster: 'logged', enforceable: true },
        ownershipEffect: { accessScope: 'watch_posts', grantAccess: true },
        requiredMemes: [
            health.sanitation_norms,
            health.waste_handling,
            culture.vigil_ritual,
            cog.timekeeping.basic,
        ]
    },
];
