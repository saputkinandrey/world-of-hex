import { ActionDefinition } from '../action-definition';
import { FaithActionTag } from '../action-tags';
import { cog, comm, culture, food } from '../../world/memes';
export const FaithActions: ActionDefinition[] = [
    {
        tag: FaithActionTag.PRIVATE_DEVOTION,
        costEnergy: -0.04,
        costTime: 0.6,
        rewardSecondary: {
            FAITH: 0.55,
            SPIRIT: 0.3,
            FOCUS: 0.2,
            RESILIENCE: 0.2,
        },
        requiresLocation: 'shrine|quiet_room',
        socialImpact: { CALM: 0.4, DISCIPLINE: 0.2 },
        lawEffect: { rite: 'private_devotion', enforceable: false }
    },
    {
        tag: FaithActionTag.LIGHT_VOTIVE_CANDLE,
        costEnergy: -0.05,
        costTime: 0.5,
        rewardSecondary: {
            FAITH: 0.5,
            MOOD: 0.25,
            HOPE: 0.3 as any,
            TRADITION: 0.2,
        },
        tradeEffect: { candle: -1, oil: -1 },
        socialImpact: { REVERENCE: 0.3, COMMUNITY: 0.1 },
        lawEffect: { fireSafety: 'observed', enforceable: true }
    },
    {
        tag: FaithActionTag.ATTEND_SERVICE,
        costEnergy: -0.06,
        costTime: 1.2,
        rewardSecondary: {
            FAITH: 0.6,
            COMMUNITY: 0.3,
            CULTURE: 0.2,
            CLARITY: 0.2,
        },
        requiresLocation: 'temple|assembly',
        socialImpact: { COHESION: 0.3, ORDER: 0.2, RESPECT: 0.2 },
        lawEffect: { riteCalendar: 'observed', enforceable: false },
        requiredMemes: [
            culture.vigil_ritual,
            cog.timekeeping.basic,
        ]
    },
    {
        tag: FaithActionTag.CONFESS_TRANSGRESSION,
        costEnergy: -0.08,
        costTime: 0.8,
        risk: 0.12,
        rewardSecondary: {
            FAITH: 0.7,
            INTEGRITY: 0.5,
            CLARITY: 0.3,
            REST: 0.1,
        },
        requiresLocation: 'confessional|quiet_room',
        socialImpact: { TRUST: 0.2, STIGMA: 0.05 as any },
        lawEffect: { confessionalSeal: 'respected', enforceable: true }
    },
    {
        tag: FaithActionTag.MAKE_VOW,
        costEnergy: -0.08,
        costTime: 0.9,
        risk: 0.15,
        rewardSecondary: {
            FAITH: 0.75,
            PURPOSE: 0.4,
            DISCIPLINE: 0.3,
            STABILITY: 0.2,
        },
        requiresLocation: 'altar|shrine',
        socialImpact: { ACCOUNTABILITY: 0.4 as any, RESPECT: 0.2 },
        lawEffect: { sacredOath: 'registered', enforceable: true }
    },
    {
        tag: FaithActionTag.FULFILL_VOW,
        costEnergy: -0.12,
        costTime: 1.2,
        rewardSecondary: {
            FAITH: 0.9,
            HONOR: 0.5,
            REPUTATION: 0.3,
            ORDER: 0.2,
        },
        tradeEffect: { offering_value: -2 },
        socialImpact: { TRUST: 0.3, CREDIBILITY: 0.3 },
        lawEffect: { oathRecord: 'closed', enforceable: true }
    },
    {
        tag: FaithActionTag.DONATE_ALMS,
        costEnergy: -0.06,
        costTime: 0.6,
        rewardSecondary: {
            FAITH: 0.6,
            COMMUNITY: 0.3,
            FAIRNESS: 0.2,
            JUSTICE: 0.2,
        },
        tradeEffect: { coin: -2, bread: -1 },
        socialImpact: { GRATITUDE: 0.4 as any, RESPECT: 0.2 },
        lawEffect: { almsLedger: 'updated', enforceable: true }
    },
    {
        tag: FaithActionTag.CARE_FOR_SHRINE,
        costEnergy: -0.16,
        costTime: 1.6,
        rewardSecondary: {
            FAITH: 0.7,
            CULTURE: 0.3,
            TRADITION: 0.3,
            ORDER: 0.3,
        },
        tradeEffect: { linen: -1, herbs: -1, water: -1 },
        socialImpact: { REVERENCE: 0.4, DIGNITY: 0.3 as any },
        ownershipEffect: { accessScope: 'inner_yard', grantAccess: true },
        lawEffect: { caretakerRoster: 'logged', enforceable: true }
    },
    {
        tag: FaithActionTag.STUDY_SACRED_TEXTS,
        costEnergy: -0.12,
        costTime: 1.6,
        rewardSecondary: {
            FAITH: 0.65,
            KNOWLEDGE: 0.4,
            CLARITY: 0.4,
            INTEGRITY: 0.2,
        },
        requiresItem: ['scroll|codex'],
        tradeEffect: { lamp_oil: -1, parchment_wear: '-minor' },
        needRework: true,
        requiredMemes: [comm.language.written],
        socialImpact: { RESPECT: 0.2, DISCIPLINE: 0.3 },
        lawEffect: { readerPass: 'issued', enforceable: true }
    },
    {
        tag: FaithActionTag.CONSULT_PRIEST,
        costEnergy: -0.1,
        costTime: 1.0,
        rewardSecondary: {
            FAITH: 0.65,
            CLARITY: 0.5,
            STABILITY: 0.3,
            COURAGE: 0.2,
        },
        tradeEffect: { counsel_fee: -1 as any },
        socialImpact: { TRUST: 0.3, HOPE: 0.3 as any },
        lawEffect: { counselRecord: 'sealed', enforceable: true }
    },
    {
        tag: FaithActionTag.FASTING_OBSERVANCE,
        costEnergy: -0.15,
        costTime: 1.0,
        risk: 0.08,
        rewardSecondary: {
            FAITH: 0.7,
            DISCIPLINE: 0.5,
            PURPOSE: 0.2,
            HEALTH: 0.05,
        },
        socialImpact: { RESPECT: 0.2, PIETY: 0.4 as any },
        lawEffect: { fastingRule: 'seasonal|voluntary', enforceable: false }
    },
    {
        tag: FaithActionTag.PROCESSION_PARTICIPATE,
        costEnergy: -0.22,
        costTime: 1.8,
        rewardSecondary: {
            FAITH: 0.85,
            COMMUNITY: 0.5,
            CULTURE: 0.4,
            MORALE: 0.3,
        },
        tradeEffect: { garlands: -1, banners: -1 },
        socialImpact: { COHESION: 0.5, VISIBILITY: 0.3, REVERENCE: 0.4 },
        lawEffect: { processionPermit: 'granted', enforceable: true },
        ownershipEffect: { accessScope: 'procession_route', grantAccess: true }
    },
    {
        tag: FaithActionTag.BLESS_HOME,
        costEnergy: -0.1,
        costTime: 1.0,
        rewardSecondary: {
            FAITH: 0.75,
            SECURITY: 0.3,
            ORDER: 0.2,
            STABILITY: 0.3,
        },
        tradeEffect: { incense: -1, sacred_salt: -1 },
        needRework: true,
        requiredMemes: [food.preservation.salting],
        socialImpact: { TRUST: 0.2, DIGNITY: 0.2 },
        ownershipEffect: { homeBlessed: true, duration: 'season' },
        lawEffect: { parishNote: 'logged', enforceable: true }
    },
    {
        tag: FaithActionTag.PRAYER_CHAIN_COMMUNITY,
        costEnergy: -0.18,
        costTime: 1.6,
        rewardSecondary: {
            FAITH: 0.8,
            COMMUNITY: 0.5,
            RESILIENCE: 0.4,
            HOPE: 0.4 as any,
        },
        socialImpact: { COHESION: 0.5, TRUST: 0.3 },
        lawEffect: { vigilPermit: 'approved', enforceable: true },
        requiredMemes: [
            culture.vigil_ritual,
            cog.timekeeping.basic,
        ]
    },
    {
        tag: FaithActionTag.TESTIMONY_SHARE,
        costEnergy: -0.1,
        costTime: 1.0,
        risk: 0.12,
        rewardSecondary: {
            FAITH: 0.75,
            COURAGE: 0.3,
            NETWORK: 0.2,
            CULTURE: 0.2,
        },
        requiresLocation: 'hall|assembly',
        socialImpact: { CREDIBILITY: 0.2, CONTROVERSY: 0.1 },
        lawEffect: { speechRule: 'no_defamation', enforceable: true },
        requiredMemes: [comm.language.written]
    },
    {
        tag: FaithActionTag.PILGRIMAGE_STEP_FAITH,
        costEnergy: -0.28,
        costTime: 2.4,
        risk: 0.18,
        rewardSecondary: {
            FAITH: 0.9,
            PURPOSE: 0.4,
            STABILITY: 0.3,
            COURAGE: 0.3,
        },
        tradeEffect: { travel_supplies: -2, tolls: -1 },
        socialImpact: {
            REPUTATION: 0.2,
            HUMILITY: 0.3 as any,
            HOPE: 0.3 as any,
        },
        ownershipEffect: { accessScope: 'pilgrim_hostels', grantAccess: true },
        lawEffect: { pilgrimMark: 'stamped', enforceable: true },
        requiredMemes: [comm.language.written]
    },
];
