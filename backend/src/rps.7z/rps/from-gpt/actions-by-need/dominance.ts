import { ActionDefinition } from '../action-definition';
import { DominanceActionTag } from '../action-tags';
export const DominanceActions: ActionDefinition[] = [
    {
        tag: DominanceActionTag.INTIMIDATING_DISPLAY,
        costEnergy: -0.18,
        costTime: 0.8,
        risk: 0.12,
        rewardSecondary: {
            DOMINANCE: 0.55,
            POWER: 0.3,
            SECURITY: 0.2,
            STATUS: 0.2,
        },
        requiresItem: ['arms|armor|banners'],
        socialImpact: {
            DOMINANCE: 0.6,
            FEAR: 0.5,
            COMPLIANCE: 0.25 as any,
            RESENTMENT: 0.15,
        },
        lawEffect: { code: 'display_allowed', enforceable: true }
    },
    {
        tag: DominanceActionTag.SUMMON_SUBORDINATE,
        costEnergy: -0.05,
        costTime: 0.4,
        rewardSecondary: { DOMINANCE: 0.45, CONTROL: 0.3, ORDER: 0.2 as any },
        socialImpact: {
            DOMINANCE: 0.5,
            OBEDIENCE: 0.35 as any,
            RESENTMENT: 0.1,
        },
        lawEffect: { writ: 'summons_issued', enforceable: true },
        ownershipEffect: { accessScope: 'audience_chamber', grantAccess: true }
    },
    {
        tag: DominanceActionTag.ISSUE_NONNEGOTIABLE_ORDER,
        costEnergy: -0.08,
        costTime: 0.3,
        risk: 0.18,
        rewardSecondary: { DOMINANCE: 0.55, CONTROL: 0.5, STABILITY: 0.2 },
        socialImpact: { DOMINANCE: 0.6, COMPLIANCE: 0.45, MORALE: -0.1 as any },
        lawEffect: { decree: 'nonnegotiable', enforceable: true }
    },
    {
        tag: DominanceActionTag.ENFORCE_CURFEW,
        costEnergy: -0.2,
        costTime: 1.6,
        risk: 0.2,
        rewardSecondary: { DOMINANCE: 0.6, SECURITY: 0.5, STABILITY: 0.4 },
        socialImpact: { DOMINANCE: 0.6, FEAR: 0.3, RESENTMENT: 0.25 },
        lawEffect: {
            curfew: 'active',
            hours: 'sunset->dawn',
            enforceable: true,
        },
        ownershipEffect: { accessScope: 'streets', accessLevel: 'RESTRICTED' }
    },
    {
        tag: DominanceActionTag.CONFISCATE_CONTRABAND,
        costEnergy: -0.18,
        costTime: 1.0,
        risk: 0.22,
        rewardSecondary: {
            DOMINANCE: 0.6,
            CONTROL: 0.4,
            SECURITY: 0.3,
            WEALTH: 0.2,
        },
        requiresSkill: 'inspection',
        socialImpact: { DOMINANCE: 0.55, FEAR: 0.25, TRUST: -0.1 },
        lawEffect: { seizureRecord: 'logged', enforceable: true },
        ownershipEffect: { seizeItems: true, toInventory: 'treasury|armory' },
        tradeEffect: { blackmarket: '-Δ', fines_collected: '+X' }
    },
    {
        tag: DominanceActionTag.STRIP_PRIVILEGE,
        costEnergy: -0.12,
        costTime: 0.8,
        risk: 0.2,
        rewardSecondary: { DOMINANCE: 0.55, CONTROL: 0.4, JUSTICE: 0.2 },
        socialImpact: { DOMINANCE: 0.55, FEAR: 0.2, RESENTMENT: 0.3 },
        lawEffect: { revocation: 'privilege_removed', enforceable: true },
        ownershipEffect: { accessRevoked: true, accessScope: 'licence|office' }
    },
    {
        tag: DominanceActionTag.IMPOSE_FINE_OR_LEVY,
        costEnergy: -0.1,
        costTime: 0.8,
        risk: 0.15,
        rewardSecondary: { DOMINANCE: 0.6, WEALTH: 0.4, CONTROL: 0.3 },
        socialImpact: { DOMINANCE: 0.5, FEAR: 0.2, FAIRNESS: 0.1 },
        lawEffect: { fineOrder: 'served', enforceable: true },
        tradeEffect: { collect_silver: '+X', arrears: '-Y' },
        ownershipEffect: { treasury: 'credited' }
    },
    {
        tag: DominanceActionTag.DEMAND_PUBLIC_SUBMISSION,
        costEnergy: -0.12,
        costTime: 0.9,
        risk: 0.22,
        rewardSecondary: { DOMINANCE: 0.7, STATUS: 0.3, CONTROL: 0.3 },
        socialImpact: {
            DOMINANCE: 0.65,
            HUMILIATION: 0.5 as any,
            RESENTMENT: 0.35,
        },
        lawEffect: { protocol: 'public_apology', enforceable: true }
    },
    {
        tag: DominanceActionTag.ASSERT_TERRITORIAL_MARKER,
        costEnergy: -0.15,
        costTime: 1.2,
        rewardSecondary: { DOMINANCE: 0.6, CONTROL: 0.35, SECURITY: 0.25 },
        tradeEffect: { place_banners: '-N', patrol_signs: '-M' },
        socialImpact: {
            DOMINANCE: 0.5,
            FEAR: 0.2,
            BOUNDARY_CLARITY: 0.4 as any,
        },
        lawEffect: { boundaryDecree: 'posted', enforceable: true },
        ownershipEffect: {
            territoryFlag: 'claimed',
            accessScope: 'area',
            accessLevel: 'OWNER',
        }
    },
    {
        tag: DominanceActionTag.DEMONSTRATE_PUNISHMENT,
        costEnergy: -0.2,
        costTime: 1.4,
        risk: 0.3,
        rewardSecondary: { DOMINANCE: 0.7, JUSTICE: 0.3, STABILITY: 0.3 },
        socialImpact: { DOMINANCE: 0.7, FEAR: 0.55, TRUST: -0.1 },
        lawEffect: {
            sentencePublic: 'due_process_required',
            enforceable: true,
        }
    },
    {
        tag: DominanceActionTag.FORCE_LABOR_ROTATION,
        costEnergy: -0.22,
        costTime: 1.8,
        risk: 0.22,
        rewardSecondary: { DOMINANCE: 0.6, PRODUCTIVITY: 0.4, CONTROL: 0.4 },
        socialImpact: { DOMINANCE: 0.55, RESENTMENT: 0.35, COMPLIANCE: 0.3 },
        lawEffect: { rota: 'labor_compulsory', enforceable: true },
        ownershipEffect: { accessScope: 'worksites', grantAccess: true }
    },
    {
        tag: DominanceActionTag.IMPOSE_QUOTA,
        costEnergy: -0.12,
        costTime: 0.8,
        risk: 0.2,
        rewardSecondary: { DOMINANCE: 0.55, CONTROL: 0.5, WEALTH: 0.3 },
        socialImpact: {
            DOMINANCE: 0.55,
            PRESSURE: 0.45 as any,
            MORALE: -0.2 as any,
        },
        lawEffect: { quota: 'per_day|per_season', enforceable: true },
        tradeEffect: { output_target: '+N', penalties: 'defined' }
    },
    {
        tag: DominanceActionTag.TAKE_HOSTAGE_AS_SURETY,
        costEnergy: -0.18,
        costTime: 1.2,
        risk: 0.3,
        rewardSecondary: { DOMINANCE: 0.6, SECURITY: 0.4, CONTROL: 0.4 },
        socialImpact: { DOMINANCE: 0.6, FEAR: 0.5, TRUST: -0.2 },
        lawEffect: {
            suretyTreaty: 'filed',
            enforceable: true,
            duration: 'term',
        },
        ownershipEffect: {
            custodyRights: 'holder',
            accessScope: 'hostage_quarters',
        }
    },
    {
        tag: DominanceActionTag.BREAK_RIVAL_NETWORK,
        costEnergy: -0.25,
        costTime: 2.0,
        risk: 0.28,
        rewardSecondary: {
            DOMINANCE: 0.75,
            POWER: 0.5,
            CONTROL: 0.5,
            STABILITY: 0.3,
        },
        requiresSkill: 'investigation',
        socialImpact: { DOMINANCE: 0.65, FEAR: 0.35, RESENTMENT: 0.3 },
        lawEffect: { banOrder: 'rival_guild_disbanded', enforceable: true },
        ownershipEffect: { seizeAssets: true, accessScope: 'rival_hall' },
        tradeEffect: { market_share: '+Δ', fines_collected: '+X' }
    },
    {
        tag: DominanceActionTag.BANISHMENT_WITH_CONDITION,
        costEnergy: -0.2,
        costTime: 1.5,
        risk: 0.22,
        rewardSecondary: { DOMINANCE: 0.6, STABILITY: 0.4, SECURITY: 0.3 },
        socialImpact: { DOMINANCE: 0.55, FEAR: 0.3, MERCY: 0.15 as any },
        lawEffect: {
            banishment: 'conditional',
            condition: 'reparations|time',
            enforceable: true,
        },
        ownershipEffect: { accessScope: 'settlement', accessLevel: 'DENIED' }
    },
    {
        tag: DominanceActionTag.SHOW_OF_FORCE_PATROL,
        costEnergy: -0.22,
        costTime: 1.6,
        risk: 0.18,
        rewardSecondary: { DOMINANCE: 0.6, SECURITY: 0.5, STABILITY: 0.3 },
        requiresItem: ['armed_patrol'],
        socialImpact: { DOMINANCE: 0.55, FEAR: 0.35, CRIME: -0.2 as any },
        lawEffect: { patrolRoutes: 'established', enforceable: true },
        ownershipEffect: {
            accessScope: 'streets|gates|markets',
            grantAccess: true,
        }
    },
];
