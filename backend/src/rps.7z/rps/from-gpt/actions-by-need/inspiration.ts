import { ActionDefinition } from '../action-definition';
import { InspirationActionTag } from '../action-tags';
import { cog, comm, culture, econ, fire, heat, org, record } from '../../world/memes';
export const InspirationActions: ActionDefinition[] = [
    {
        tag: InspirationActionTag.SEEK_MUSE_IN_NATURE,
        costEnergy: -0.1,
        costTime: 1.4,
        rewardSecondary: {
            INSPIRATION: 0.7,
            MOOD: 0.3,
            CREATIVITY: 0.3,
            FOCUS: 0.15,
        },
        requiresLocation: 'grove|riverbank|hilltop',
        socialImpact: { CALM: 0.4 as any },
        ownershipEffect: { accessScope: 'greenway', grantAccess: true },
        lawEffect: { natureReserve: 'respect_paths', enforceable: true }
    },
    {
        tag: InspirationActionTag.VISIT_MASTERWORKS,
        costEnergy: -0.12,
        costTime: 1.6,
        rewardSecondary: {
            INSPIRATION: 0.75,
            CREATIVITY: 0.4,
            CULTURE: 0.3,
            QUALITY: 0.2,
        },
        requiresLocation: 'gallery|temple|hall_of_crafts',
        tradeEffect: { entry_fee: -1 },
        socialImpact: { REVERENCE: 0.4, AMBITION: 0.2 as any },
        lawEffect: { exhibitEtiquette: 'observed', enforceable: true },
        requiredMemes: [
            culture.vigil_ritual,
            cog.timekeeping.basic,
            comm.language.written,
        ]
    },
    {
        tag: InspirationActionTag.CREATIVE_JAM_SESSION,
        costEnergy: -0.2,
        costTime: 2.0,
        risk: 0.12,
        rewardSecondary: {
            INSPIRATION: 0.9,
            SOCIAL: 0.4,
            NETWORK: 0.4,
            INNOVATION_REP: 0.3,
        },
        requiresLocation: 'atelier|hall',
        tradeEffect: { refreshments: -2, materials_shared: -2 },
        socialImpact: { COHESION: 0.3, CONTROVERSY: 0.1 },
        ownershipEffect: { accessScope: 'atelier', grantAccess: true },
        lawEffect: { gatheringPermit: 'approved', enforceable: true },
        requiredMemes: [comm.language.written]
    },
    {
        tag: InspirationActionTag.RITUAL_OF_SPARK,
        costEnergy: -0.04,
        costTime: 0.5,
        rewardSecondary: { INSPIRATION: 0.55, FOCUS: 0.3, DISCIPLINE: 0.2 },
        requiresLocation: 'quiet_spot|shrine',
        socialImpact: { FOCUS: 0.2 },
        lawEffect: { rite: 'private', enforceable: false }
    },
    {
        tag: InspirationActionTag.COLLECT_MOTIFS_FIELD,
        costEnergy: -0.16,
        costTime: 1.8,
        rewardSecondary: { INSPIRATION: 0.65, KNOWLEDGE: 0.3, CREATIVITY: 0.3 },
        requiresItem: ['charcoal|stylus', 'scrap_parchment'],
        tradeEffect: { parchment: -1 },
        socialImpact: { CREDIBILITY: 0.2 },
        ownershipEffect: { motifSheets: '+1', archive: 'yes' },
        requiredMemes: [comm.language.written]
    },
    {
        tag: InspirationActionTag.DREAM_NOTEBOOK,
        costEnergy: -0.03,
        costTime: 0.4,
        rewardSecondary: { INSPIRATION: 0.5, CLARITY: 0.25, FOCUS: 0.15 },
        tradeEffect: { wax_tablet: -1 as any },
        socialImpact: { MEMORY: 0.3 as any },
        ownershipEffect: { dreamLog: 'updated' },
        requiredMemes: [
            record.ledgerkeeping,
            econ.pooling_common_fund,
        ]
    },
    {
        tag: InspirationActionTag.CHANCE_CONSTRAINTS,
        costEnergy: -0.08,
        costTime: 0.8,
        risk: 0.1,
        rewardSecondary: { INSPIRATION: 0.65, CREATIVITY: 0.4, COURAGE: 0.2 },
        requiresItem: ['dice|cards'],
        socialImpact: { PLAYFULNESS: 0.3 as any },
        lawEffect: { gamblingBan: 'non_wager_ok', enforceable: true }
    },
    {
        tag: InspirationActionTag.CROSS_DISCIPLINE_EXPOSURE,
        costEnergy: -0.14,
        costTime: 1.6,
        rewardSecondary: {
            INSPIRATION: 0.7,
            KNOWLEDGE: 0.4,
            INNOVATION_REP: 0.3,
        },
        requiresLocation: 'guild_workshop|forge|kitchen',
        socialImpact: { NETWORK: 0.3, RESPECT: 0.2 },
        ownershipEffect: { accessScope: 'guest_bench', grantAccess: true },
        lawEffect: { visitorBadge: 'issued', enforceable: true },
        requiredMemes: [
            heat.industrial,
            fire.control,
            comm.language.written,
            org.workshop_practice,
        ]
    },
    {
        tag: InspirationActionTag.PROMPT_CARD_DRAW,
        costEnergy: -0.04,
        costTime: 0.5,
        rewardSecondary: { INSPIRATION: 0.55, FOCUS: 0.2, CLARITY: 0.2 },
        requiresItem: ['prompt_cards'],
        socialImpact: { ORGANIZATION: 0.15 as any },
        ownershipEffect: { promptCard: 'drawn' }
    },
    {
        tag: InspirationActionTag.STORY_PROMPT_EXCHANGE,
        costEnergy: -0.08,
        costTime: 0.8,
        rewardSecondary: { INSPIRATION: 0.6, SOCIAL: 0.3, NETWORK: 0.3 },
        tradeEffect: { parchment: -1, ink: -1 },
        socialImpact: { TRUST: 0.2, COHESION: 0.2 },
        ownershipEffect: { promptPool: '+1', license: 'open' },
        lawEffect: { authorshipNote: 'logged', enforceable: true },
        requiredMemes: [
            comm.language.written,
            record.ledgerkeeping,
            econ.pooling_common_fund,
        ]
    },
    {
        tag: InspirationActionTag.ONE_HOUR_PROTOTYPE,
        costEnergy: -0.2,
        costTime: 1.0,
        risk: 0.12,
        rewardSecondary: {
            INSPIRATION: 0.8,
            CREATIVITY: 0.5,
            PRODUCTIVITY: 0.3,
        },
        requiresItem: ['tools', 'scrap_materials'],
        tradeEffect: { materials: -2, scrap: '+1' },
        socialImpact: { EFFICIENCY: 0.3, COURAGE: 0.2 },
        ownershipEffect: { prototype: 'v1', blueprint: 'draft' },
        lawEffect: { workshopEtiquette: 'observed', enforceable: true }
    },
    {
        tag: InspirationActionTag.INSPIRATION_WALKABOUT,
        costEnergy: -0.1,
        costTime: 1.2,
        rewardSecondary: { INSPIRATION: 0.65, CURIOSITY: 0.3, IDENTITY: 0.2 },
        requiresLocation: 'market|docks|foreign_quarter',
        socialImpact: { NETWORK: 0.2, CLARITY: 0.1 },
        lawEffect: { curfew: 'not_active', enforceable: true }
    },
    {
        tag: InspirationActionTag.PATRON_BRIEF_SESSION,
        costEnergy: -0.1,
        costTime: 0.9,
        risk: 0.1,
        rewardSecondary: { INSPIRATION: 0.7, CLARITY: 0.5, STATUS: 0.2 },
        requiresLocation: 'hall|atelier',
        socialImpact: { TRUST: 0.2, ACCOUNTABILITY: 0.3 as any },
        ownershipEffect: { brief: 'captured' },
        lawEffect: { commissionNote: 'filed', enforceable: true },
        requiredMemes: [comm.language.written]
    },
    {
        tag: InspirationActionTag.FAILURE_GALLERY,
        costEnergy: -0.12,
        costTime: 1.2,
        risk: 0.12,
        rewardSecondary: {
            INSPIRATION: 0.75,
            COURAGE: 0.4,
            RESILIENCE: 0.4,
            CULTURE: 0.2,
        },
        requiresLocation: 'hall|atelier',
        socialImpact: { HUMILITY: 0.4 as any, COHESION: 0.3 },
        lawEffect: { ridiculeBan: 'posted', enforceable: true },
        requiredMemes: [comm.language.written]
    },
    {
        tag: InspirationActionTag.MENTOR_CRITIQUE,
        costEnergy: -0.14,
        costTime: 1.4,
        risk: 0.15,
        rewardSecondary: { INSPIRATION: 0.8, QUALITY: 0.5, MASTERY: 0.4 },
        tradeEffect: { mentor_fee: -1 as any },
        socialImpact: { RESPECT: 0.3, TRUST: 0.2 },
        ownershipEffect: { notes: 'critique_log' },
        lawEffect: { mentorshipRoll: 'filed', enforceable: true }
    },
    {
        tag: InspirationActionTag.ARCHIVE_REFERENCE_BOARD,
        costEnergy: -0.1,
        costTime: 1.2,
        rewardSecondary: { INSPIRATION: 0.7, CLARITY: 0.4, FOCUS: 0.3 },
        requiresItem: ['board|wall', 'pins|glue'],
        tradeEffect: { parchment_scraps: -2, glue: -1 },
        socialImpact: { ORDER: 0.3 },
        ownershipEffect: {
            referenceBoard: 'assembled',
            accessScope: 'atelier',
            grantAccess: true,
        },
        lawEffect: { archivePolicy: 'index_required', enforceable: true },
        requiredMemes: [comm.language.written]
    },
];
