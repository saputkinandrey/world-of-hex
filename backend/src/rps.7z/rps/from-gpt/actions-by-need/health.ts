import { ActionDefinition } from '../action-definition';
import { HealthActionTag } from '../action-tags';
import { health } from '../../world/memes';
export const HealthActions: ActionDefinition[] = [
    {
        tag: HealthActionTag.HEAL_SELF,
        costEnergy: -0.2,
        costTime: 1.5,
        rewardSecondary: { HEALTH: 0.6, HYGIENE: 0.1, MOOD: 0.2 },
        skillRequired: 'FirstAid',
        locationType: 'any',
        targetType: 'SELF'
    },
    {
        tag: HealthActionTag.HEAL_OTHER,
        costEnergy: -0.3,
        costTime: 2,
        rewardSecondary: { HEALTH: 0.8, TRUST: 0.3, COMMUNITY: 0.2 },
        skillRequired: 'Medicine',
        targetType: 'OTHER',
        socialImpact: { gratitude: 0.3, respect: 0.3 }
    },
    {
        tag: HealthActionTag.APPLY_BANDAGE,
        costEnergy: -0.15,
        costTime: 1,
        rewardSecondary: { HEALTH: 0.4 },
        requiresItem: ['bandage'],
        locationType: 'any',
        skillRequired: 'FirstAid'
    },
    {
        tag: HealthActionTag.CLEAN_WOUND,
        costEnergy: -0.1,
        costTime: 0.5,
        requiresItem: ['clean_water'],
        rewardSecondary: { HEALTH: 0.3, HYGIENE: 0.3 },
        requiredMemes: [
            health.sanitation_norms,
            health.waste_handling,
        ]
    },
    {
        tag: HealthActionTag.APPLY_HERBAL_REMEDY,
        costEnergy: -0.2,
        costTime: 2,
        requiresItem: ['herbs'],
        skillRequired: 'Herbalism',
        rewardSecondary: { HEALTH: 0.7, SPIRIT: 0.1 }
    },
    {
        tag: HealthActionTag.DRINK_MEDICINE,
        costEnergy: -0.05,
        costTime: 0.2,
        requiresItem: ['medicine'],
        rewardSecondary: { HEALTH: 0.5, MOOD: 0.2 }
    },
    {
        tag: HealthActionTag.REST_FOR_RECOVERY,
        costEnergy: -0.3,
        costTime: 6,
        rewardSecondary: { HEALTH: 1.0, REST: 0.6, MOOD: 0.3 },
        locationType: 'bed'
    },
    {
        tag: HealthActionTag.SEEK_HEALER,
        costEnergy: -0.4,
        costTime: 3,
        rewardSecondary: { HEALTH: 0.7, TRUST: 0.2 },
        targetType: 'OTHER',
        locationType: 'village'
    },
    {
        tag: HealthActionTag.PRAY_FOR_HEALTH,
        costEnergy: -0.1,
        costTime: 1,
        rewardSecondary: { HEALTH: 0.4, SPIRIT: 0.3, MOOD: 0.2 },
        locationType: 'temple'
    },
    {
        tag: HealthActionTag.PERFORM_RITUAL_HEALING,
        costEnergy: -0.2,
        costTime: 3,
        rewardSecondary: { HEALTH: 0.8, SPIRIT: 0.6, COMMUNITY: 0.4 },
        skillRequired: 'Ritualism',
        locationType: 'sacred_site'
    },
    {
        tag: HealthActionTag.CLEAN_BODY,
        costEnergy: -0.15,
        costTime: 1,
        rewardSecondary: { HEALTH: 0.3, HYGIENE: 0.5 },
        locationType: 'river',
        requiredMemes: [
            health.sanitation_norms,
            health.waste_handling,
        ]
    },
    {
        tag: HealthActionTag.EAT_HEALTHY_MEAL,
        costEnergy: -0.05,
        costTime: 0.5,
        rewardSecondary: { HEALTH: 0.3, FOOD: 0.5, MOOD: 0.2 },
        requiresItem: ['meal_healthy']
    },
    {
        tag: HealthActionTag.ISOLATE_SELF,
        costEnergy: -0.2,
        costTime: 4,
        risk: 0.1,
        rewardSecondary: { HEALTH: 0.4, COMMUNITY: -0.1 },
        locationType: 'hut'
    },
    {
        tag: HealthActionTag.MASSAGE,
        costEnergy: -0.15,
        costTime: 1.5,
        rewardSecondary: { HEALTH: 0.5, REST: 0.4, AFFECTION: 0.3 },
        targetType: 'SELF'
    },
    {
        tag: HealthActionTag.CHECK_HEALTH,
        costEnergy: -0.05,
        costTime: 0.5,
        rewardSecondary: { HEALTH: 0.2, KNOWLEDGE: 0.1 },
        skillRequired: 'Medicine'
    },
    {
        tag: HealthActionTag.MAKE_MEDICINE,
        costEnergy: -0.25,
        costTime: 2.5,
        rewardSecondary: { HEALTH: 0.6, KNOWLEDGE: 0.3 },
        requiresItem: ['herbs', 'water'],
        skillRequired: 'Alchemy'
    },
];
