import { ActionDefinition } from '../action-definition';
import { ActionTags, LoyaltyActionTag } from '../action-tags';
import { cog, comm, culture } from '../../world/memes';
export const LoyaltyActions: ActionDefinition[] = [
    {
        tag: LoyaltyActionTag.SWEAR_FEALTY,
        costEnergy: -0.05,
        costTime: 0.6,
        rewardSecondary: {
            LOYALTY: 0.7,
            BELONGING: 0.4,
            LAW: 0.3,
            STATUS: 0.1,
        },
        requiresLocation: 'hall',
        targetType: 'GROUP',
        socialImpact: { LOYALTY: 0.6, TRUST: 0.3, RESPECT: 0.2 },
        lawEffect: {
            oathRecord: 'fealty_v1',
            enforceable: true,
            duration: '1y',
        },
        requiredMemes: [comm.language.written]
    },
    {
        tag: LoyaltyActionTag.RENEW_OATH,
        costEnergy: -0.05,
        costTime: 0.5,
        rewardSecondary: { LOYALTY: 0.5, TRADITION: 0.4, COMMUNITY: 0.3 },
        requiresLocation: 'temple',
        socialImpact: { LOYALTY: 0.4, COHESION: 0.3 },
        lawEffect: { oathRenewal: 'yearly_festival', enforceable: true },
        requiredMemes: [
            culture.vigil_ritual,
            cog.timekeeping.basic,
        ]
    },
    {
        tag: LoyaltyActionTag.OBEY_ORDER_PROMPTLY,
        costEnergy: -0.1,
        costTime: 0.4,
        risk: 0.05,
        rewardSecondary: { LOYALTY: 0.5, ORDER: 0.3, PRODUCTIVITY: 0.3 },
        targetType: 'OTHER',
        socialImpact: { OBEDIENCE: 0.4, TRUST: 0.2 },
        lawEffect: { orderRef: 'ord-runtime', enforceable: true }
    },
    {
        tag: LoyaltyActionTag.DEFEND_LEADER,
        costEnergy: -0.55,
        costTime: 1.2,
        risk: 0.35,
        rewardSecondary: {
            LOYALTY: 0.9,
            HONOR: 0.5,
            SECURITY: 0.4,
            STATUS: 0.3,
        },
        requiresItem: ['weapon'],
        targetType: 'OTHER',
        socialImpact: { RESPECT: 0.5, COURAGE: 0.4, TRUST: 0.3 },
        ownershipEffect: {
            grantAccess: true,
            accessScope: 'inner_circle',
            accessLevel: 'GUARD',
        }
    },
    {
        tag: LoyaltyActionTag.ESCORT_LEADER,
        costEnergy: -0.25,
        costTime: 2,
        risk: 0.15,
        rewardSecondary: { LOYALTY: 0.6, SECURITY: 0.4, BELONGING: 0.2 },
        targetType: 'OTHER',
        socialImpact: { TRUST: 0.3, RELIABILITY: 0.3 }
    },
    {
        tag: LoyaltyActionTag.PROTECT_LEADER_KIN,
        costEnergy: -0.35,
        costTime: 2.5,
        risk: 0.2,
        rewardSecondary: { LOYALTY: 0.7, FAMILY: 0.4, COMMUNITY: 0.3 },
        targetType: 'OTHER',
        socialImpact: { GRATITUDE: 0.4, LOYALTY: 0.4 }
    },
    {
        tag: ActionTags.REFUSE_BRIBE,
        costEnergy: -0.08,
        costTime: 0.3,
        risk: 0.1,
        rewardSecondary: {
            LOYALTY: 0.6,
            JUSTICE: 0.3,
            LAW: 0.2,
            INTEGRITY: 0.3 as any,
        },
        tradeEffect: { bribe_refused: 'yes', attempted_amount: '+X' },
        socialImpact: { TRUST: 0.5, RESPECT: 0.3, SUSPICION: -0.2 },
        lawEffect: { report: 'bribe_attempt_logged', enforceable: true }
    },
    {
        tag: LoyaltyActionTag.INFORM_LEADER,
        costEnergy: -0.05,
        costTime: 0.5,
        risk: 0.05,
        rewardSecondary: { LOYALTY: 0.5, CONTROL: 0.3, STABILITY: 0.2 },
        targetType: 'OTHER',
        socialImpact: { TRUST: 0.3, USEFULNESS: 0.3 as any },
        lawEffect: { memo: 'intel_report', confidentiality: 'HIGH' }
    },
    {
        tag: LoyaltyActionTag.VOLUNTEER_DANGEROUS_TASK,
        costEnergy: -0.45,
        costTime: 2.5,
        risk: 0.4,
        rewardSecondary: { LOYALTY: 0.9, HONOR: 0.5, STATUS: 0.3, POWER: 0.2 },
        socialImpact: { RESPECT: 0.5, COURAGE: 0.5 },
        ownershipEffect: {
            grantAccess: true,
            accessScope: 'elite_missions',
            accessLevel: 'VOLUNTEER',
        }
    },
    {
        tag: LoyaltyActionTag.CARRY_BANNER,
        costEnergy: -0.15,
        costTime: 1.2,
        risk: 0.1,
        rewardSecondary: { LOYALTY: 0.6, COMMUNITY: 0.4, TRADITION: 0.3 },
        requiresItem: ['banner'],
        targetType: 'GROUP',
        socialImpact: {
            VISIBILITY: 0.4 as any,
            PRIDE: 0.4 as any,
            LOYALTY: 0.3,
        }
    },
    {
        tag: LoyaltyActionTag.PAY_EXTRA_TITHE,
        costEnergy: -0.05,
        costTime: 0.3,
        rewardSecondary: { LOYALTY: 0.5, STATUS: 0.2, BELONGING: 0.2 },
        tradeEffect: { transfer: 'personal->leader:+10', note: 'extra_tithe' },
        socialImpact: { GRATITUDE: 0.4, FAVOR: 0.3 as any },
        ownershipEffect: {
            grantAccess: true,
            accessScope: 'leader_favor',
            accessLevel: 'PREFERRED',
        },
        lawEffect: { titheReceipt: 'ok', enforceable: true }
    },
    {
        tag: LoyaltyActionTag.DENOUNCE_TRAITOR,
        costEnergy: -0.2,
        costTime: 0.8,
        risk: 0.25,
        rewardSecondary: { LOYALTY: 0.7, JUSTICE: 0.4, LAW: 0.3 },
        targetType: 'GROUP',
        socialImpact: { TRUST: 0.3, FEAR: 0.2, RESPECT: 0.2 },
        lawEffect: { caseOpened: true, charge: 'treason' }
    },
    {
        tag: LoyaltyActionTag.KEEP_LEADER_SECRETS,
        costEnergy: -0.02,
        costTime: 0.2,
        risk: 0.05,
        rewardSecondary: { LOYALTY: 0.5, TRUST: 0.4, CONTROL: 0.2 },
        socialImpact: { RELIABILITY: 0.4 as any, TRUST: 0.3 },
        lawEffect: { confidentialityOath: 'signed', enforceable: true }
    },
    {
        tag: LoyaltyActionTag.REINFORCE_MORALE,
        costEnergy: -0.15,
        costTime: 1.0,
        rewardSecondary: {
            LOYALTY: 0.6,
            COMMUNITY: 0.4,
            REST: 0.2,
            POWER: 0.1,
        },
        targetType: 'GROUP',
        socialImpact: { MORALE: 0.6 as any, COHESION: 0.4, HOPE: 0.3 as any }
    },
    {
        tag: LoyaltyActionTag.GUARD_LEADER_SLEEP,
        costEnergy: -0.3,
        costTime: 3,
        risk: 0.1,
        rewardSecondary: { LOYALTY: 0.6, SECURITY: 0.5, BELONGING: 0.3 },
        targetType: 'OTHER',
        socialImpact: { TRUST: 0.5, CARE: 0.3 as any }
    },
    {
        tag: LoyaltyActionTag.PARTICIPATE_BODYGUARD_ROTATION,
        costEnergy: -0.25,
        costTime: 2,
        risk: 0.1,
        rewardSecondary: {
            FAIRNESS: 0.3 as any,
            STABILITY: 0.3,
            SECURITY: 0.3,
            LOYALTY: 0.5,
        },
        targetType: 'GROUP',
        socialImpact: { LOYALTY: 0.3, TRUST: 0.2 },
        lawEffect: { rotaPolicy: 'weekly', enforceable: true }
    },
];
