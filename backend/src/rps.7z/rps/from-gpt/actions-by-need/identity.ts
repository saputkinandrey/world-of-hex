import { ActionDefinition } from '../action-definition';
import { IdentityActionTag } from '../action-tags';
import { cog, comm, culture, econ, fire, health, heat, org, record } from '../../world/memes';
export const IdentityActions: ActionDefinition[] = [
    {
        tag: IdentityActionTag.DECLARE_CLAN_AFFILIATION,
        costEnergy: -0.06,
        costTime: 0.7,
        rewardSecondary: {
            IDENTITY: 0.65,
            COMMUNITY: 0.4,
            RESPECT: 0.3,
            TRADITION: 0.3,
        },
        requiresLocation: 'hall|square',
        socialImpact: { BELONGING: 0.4 as any, NETWORK: 0.2 },
        lawEffect: { clanRoll: 'updated', enforceable: true },
        requiredMemes: [
            health.sanitation_norms,
            health.waste_handling,
            comm.language.written,
        ]
    },
    {
        tag: IdentityActionTag.WEAR_HERALDIC_MARKS,
        costEnergy: -0.04,
        costTime: 0.5,
        rewardSecondary: {
            IDENTITY: 0.55,
            STATUS: 0.3,
            CULTURE: 0.2,
            RESPECT: 0.2,
        },
        tradeEffect: { dye: '-1 | 0' as any, cloth: '-1 | 0' as any },
        socialImpact: { VISIBILITY: 0.3 as any, UNITY: 0.2 as any },
        lawEffect: { heraldryRule: 'observed', enforceable: true },
        ownershipEffect: { attireState: 'colors_worn' }
    },
    {
        tag: IdentityActionTag.GENEALOGY_RECITAL,
        costEnergy: -0.1,
        costTime: 1.0,
        rewardSecondary: {
            IDENTITY: 0.7,
            TRADITION: 0.6,
            CLARITY: 0.4,
            HONOR: 0.3,
        },
        requiresLocation: 'hearth|hall|temple',
        socialImpact: { RESPECT: 0.3, COMMUNITY: 0.3 },
        ownershipEffect: { lineageScroll: 'updated' },
        lawEffect: { lineageRegistry: 'filed', enforceable: true },
        requiredMemes: [
            culture.vigil_ritual,
            cog.timekeeping.basic,
            heat.space.hearth,
            comm.language.written,
        ]
    },
    {
        tag: IdentityActionTag.RITE_OF_NAMING_OR_RENAMING,
        costEnergy: -0.12,
        costTime: 1.2,
        risk: 0.06,
        rewardSecondary: {
            IDENTITY: 0.85,
            PURPOSE: 0.4,
            TRADITION: 0.4,
            COMMUNITY: 0.3,
        },
        requiresLocation: 'temple|sacred_grove|hall',
        socialImpact: { RESPECT: 0.3, DIGNITY: 0.3 as any },
        lawEffect: { nameRoll: 'amended', enforceable: true },
        ownershipEffect: { sealImprint: 'issued' },
        requiredMemes: [
            culture.vigil_ritual,
            cog.timekeeping.basic,
            comm.language.written,
        ]
    },
    {
        tag: IdentityActionTag.PERSONAL_CREST_DESIGN,
        costEnergy: -0.12,
        costTime: 1.2,
        rewardSecondary: {
            IDENTITY: 0.7,
            CREATIVITY: 0.3 as any,
            STATUS: 0.2,
            CULTURE: 0.3,
        },
        tradeEffect: { parchment: -1, ink: -1 },
        socialImpact: { REPUTATION: 0.2, VISIBILITY: 0.2 as any },
        ownershipEffect: { crest: 'drafted', rights: 'display' },
        lawEffect: { crestRegister: 'filed', enforceable: true },
        requiredMemes: [
            comm.language.written,
            record.ledgerkeeping,
        ]
    },
    {
        tag: IdentityActionTag.LINEAGE_MARK_TATTOO,
        costEnergy: -0.14,
        costTime: 1.4,
        risk: 0.08,
        rewardSecondary: {
            IDENTITY: 0.8,
            TRADITION: 0.5,
            RESILIENCE: 0.2,
            STATUS: 0.2,
        },
        tradeEffect: { ink: -1, needle_wear: '-minor' },
        socialImpact: { COURAGE: 0.2, RESPECT: 0.2 },
        lawEffect: { markCharter: 'permitted', enforceable: true },
        ownershipEffect: { bodyMark: 'applied' },
        requiredMemes: [
            comm.language.written,
            cog.number_concept,
        ]
    },
    {
        tag: IdentityActionTag.SIGNATURE_STYLE_CRAFT,
        costEnergy: -0.18,
        costTime: 1.6,
        rewardSecondary: {
            IDENTITY: 0.8,
            MASTERY: 0.5,
            REPUTATION: 0.4,
            CULTURE: 0.2,
        },
        requiresLocation: 'workbench|loom|forge',
        socialImpact: { STATUS: 0.3, NETWORK: 0.2 },
        ownershipEffect: { makerMark: 'engraved', provenance: 'traceable' },
        requiredMemes: [
            heat.industrial,
            fire.control,
            comm.language.written,
        ]
    },
    {
        tag: IdentityActionTag['OATH_TO_CODE_OR PATRON'],
        costEnergy: -0.1,
        costTime: 1.0,
        risk: 0.12,
        rewardSecondary: {
            IDENTITY: 0.85,
            INTEGRITY: 0.5,
            PURPOSE: 0.5,
            HONOR: 0.4,
        },
        requiresLocation: 'temple|hall',
        socialImpact: { TRUST: 0.3, RESPECT: 0.3 },
        lawEffect: { oathRecord: 'sworn', enforceable: true },
        requiredMemes: [
            culture.vigil_ritual,
            cog.timekeeping.basic,
            comm.language.written,
        ]
    },
    {
        tag: IdentityActionTag.MENTOR_LINE_ACKNOWLEDGE,
        costEnergy: -0.08,
        costTime: 0.8,
        rewardSecondary: {
            IDENTITY: 0.7,
            TRADITION: 0.5,
            MASTERY: 0.3,
            COMMUNITY: 0.3,
        },
        requiresLocation: 'guild_hall|workshop',
        socialImpact: { RESPECT: 0.3, NETWORK: 0.3 },
        ownershipEffect: { lineageMap: 'updated' },
        lawEffect: { apprenticeRoll: 'annotated', enforceable: true },
        requiredMemes: [
            comm.language.written,
            org.workshop_practice,
        ]
    },
    {
        tag: IdentityActionTag.PILGRIMAGE_TO_ORIGIN_SITE,
        costEnergy: -0.22,
        costTime: 2.0,
        risk: 0.1,
        rewardSecondary: {
            IDENTITY: 0.9,
            PURPOSE: 0.5,
            CULTURE: 0.4,
            RESILIENCE: 0.3,
        },
        tradeEffect: { travel_supplies: -1, offerings: '-1 | 0' as any },
        requiresLocation: 'ancestral_site|sacred_spring|old_hall',
        socialImpact: { COMMUNITY: 0.3, RESPECT: 0.2 },
        ownershipEffect: { token: 'pilgrim_mark' },
        requiredMemes: [
            comm.language.written,
            cog.number_concept,
        ]
    },
    {
        tag: IdentityActionTag.CLAN_SERVICE_DAY,
        costEnergy: -0.18,
        costTime: 1.6,
        rewardSecondary: {
            IDENTITY: 0.8,
            COMMUNITY: 0.5,
            PURPOSE: 0.4,
            MORALE: 0.3,
        },
        requiresLocation: 'commons|fields|hall',
        socialImpact: { BELONGING: 0.4 as any, NETWORK: 0.2 },
        ownershipEffect: { commonsState: 'improved' },
        requiredMemes: [
            health.sanitation_norms,
            health.waste_handling,
            comm.language.written,
        ]
    },
    {
        tag: IdentityActionTag.DIALECT_OR_SONG_KEEP,
        costEnergy: -0.12,
        costTime: 1.2,
        rewardSecondary: {
            IDENTITY: 0.75,
            TRADITION: 0.5,
            CULTURE: 0.4,
            COMMUNITY: 0.3,
        },
        requiresLocation: 'hearth|hall|green',
        socialImpact: { RESPECT: 0.2, COHESION: 0.3 },
        ownershipEffect: { repertoire: 'preserved' },
        requiredMemes: [
            culture.vigil_ritual,
            cog.timekeeping.basic,
            heat.space.hearth,
            comm.language.written,
        ]
    },
    {
        tag: IdentityActionTag.TOTEM_OBJECT_CONSECRATE,
        costEnergy: -0.14,
        costTime: 1.4,
        rewardSecondary: {
            IDENTITY: 0.8,
            CULTURE: 0.4,
            HONOR: 0.3,
            COMMUNITY: 0.3,
        },
        tradeEffect: { incense: -1, ribbon: '-1 | 0' as any },
        needRework: true,
        requiresLocation: 'shrine|hearth',
        requiredMemes: [
            culture.vigil_ritual,
            cog.timekeeping.basic,
            heat.space.hearth,
            record.ledgerkeeping,
            econ.pooling_common_fund,
        ],
        socialImpact: { REVERENCE: 0.4 as any, UNITY: 0.2 as any },
        lawEffect: { reliquaryRegister: 'filed', enforceable: true },
        ownershipEffect: { totem: 'consecrated' }
    },
    {
        tag: IdentityActionTag.ROLE_MASTERY_BADGE,
        costEnergy: -0.16,
        costTime: 1.4,
        rewardSecondary: {
            IDENTITY: 0.85,
            STATUS: 0.5,
            REPUTATION: 0.4,
            MASTERY: 0.4,
        },
        requiresLocation: 'guild_hall|yard',
        tradeEffect: { badge: -1 },
        socialImpact: { RESPECT: 0.4, NETWORK: 0.2 },
        lawEffect: { masteryRoll: 'updated', enforceable: true },
        ownershipEffect: { badgeRights: 'wear_in_ceremony' },
        requiredMemes: [
            health.sanitation_norms,
            health.waste_handling,
            comm.language.written,
            org.workshop_practice,
        ]
    },
    {
        tag: IdentityActionTag.PERSONAL_CHRONICLE_ENTRY,
        costEnergy: -0.1,
        costTime: 1.0,
        rewardSecondary: {
            IDENTITY: 0.7,
            CLARITY: 0.5,
            PURPOSE: 0.3,
            CULTURE: 0.2,
        },
        tradeEffect: { parchment: -1, ink: -1 },
        socialImpact: { REFLECTION: 0.3 as any },
        ownershipEffect: { chronicle: 'updated' },
        requiredMemes: [comm.language.written]
    },
    {
        tag: IdentityActionTag.BOUNDARY_STATEMENT,
        costEnergy: -0.06,
        costTime: 0.6,
        risk: 0.08,
        rewardSecondary: {
            IDENTITY: 0.7,
            INTEGRITY: 0.5,
            RESPECT: 0.3,
            CLARITY: 0.4,
        },
        requiresLocation: 'hall|yard',
        socialImpact: { DIGNITY: 0.4 as any, CONFLICT: -0.1 as any },
        lawEffect: { boundaryNote: 'posted', enforceable: true },
        requiredMemes: [
            health.sanitation_norms,
            health.waste_handling,
            comm.language.written,
        ]
    },
];
