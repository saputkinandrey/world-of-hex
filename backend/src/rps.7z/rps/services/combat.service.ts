import { Injectable } from '@nestjs/common';

@Injectable()
export class CombatService {
  constructor() {}
}
