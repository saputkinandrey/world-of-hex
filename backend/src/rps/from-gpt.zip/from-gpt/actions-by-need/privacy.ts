import { ActionDefinition } from '../action-definition';
import { PrivacyActionTag } from '../action-tags';
import { cog, comm, culture, econ, heat, record } from '../memes';
export const PrivacyActions: ActionDefinition[] = [
    {
        tag: PrivacyActionTag.CREATE_PRIVATE_QUARTERS,
        costEnergy: -0.18,
        costTime: 1.8,
        rewardSecondary: {
            PRIVACY: 0.85,
            STABILITY: 0.4,
            SECURITY: 0.3,
            CONTROL: 0.3 as any,
        },
        requiresLocation: 'house|longhouse|barracks',
        tradeEffect: {
            curtains: -1,
            chest: -1 | (0 as any),
            rugs: -1 | (0 as any),
        },
        socialImpact: { RESPECT: 0.2, CONFLICT: -0.05 as any },
        ownershipEffect: {
            roomState: 'private_quarters',
            accessScope: 'owner_only',
        },
        lawEffect: { trespassRule: 'posted', enforceable: true }
    },
    {
        tag: PrivacyActionTag.SET_SCREEN_PARTITIONS,
        costEnergy: -0.14,
        costTime: 1.2,
        rewardSecondary: {
            PRIVACY: 0.7,
            CONTROL: 0.3 as any,
            STABILITY: 0.3,
            CLARITY: 0.2,
        },
        tradeEffect: {
            screens: -1,
            rope: -1 | (0 as any),
            stakes: '-N' as any,
        },
        socialImpact: { BOUNDARIES: 0.3 as any },
        ownershipEffect: { areaDivision: 'partitioned' }
    },
    {
        tag: PrivacyActionTag.SECURE_STORAGE_CHEST,
        costEnergy: -0.12,
        costTime: 1.0,
        rewardSecondary: {
            PRIVACY: 0.7,
            SECURITY: 0.4,
            TRUST: 0.2,
            STABILITY: 0.2,
        },
        tradeEffect: { chest: -1 | (0 as any), lock_or_seal: -1 | (0 as any) },
        socialImpact: { THEFT: -0.1 as any, RESPECT: 0.1 },
        ownershipEffect: {
            chestState: 'locked|sealed',
            accessScope: 'owner_only',
        },
        lawEffect: { sealTamperPenalty: 'fine|shame', enforceable: true },
        requiredMemes: [
            record.ledgerkeeping,
            econ.pooling_common_fund,
        ]
    },
    {
        tag: PrivacyActionTag.QUIET_ZONE_DECLARATION,
        costEnergy: -0.06,
        costTime: 0.6,
        rewardSecondary: {
            PRIVACY: 0.6,
            CLARITY: 0.3,
            STABILITY: 0.3,
            TRUST: 0.2,
        },
        requiresLocation: 'hall|library|hearth',
        socialImpact: { CALM: 0.3 as any, RESPECT: 0.2 },
        lawEffect: { quietHours: 'posted', enforceable: true },
        ownershipEffect: { accessScope: 'quiet_zone', grantAccess: true },
        requiredMemes: [
            culture.vigil_ritual,
            cog.timekeeping.basic,
            heat.space.hearth,
            comm.language.written,
        ]
    },
    {
        tag: PrivacyActionTag.PRIVATE_COUNSEL_MEET,
        costEnergy: -0.08,
        costTime: 0.9,
        rewardSecondary: {
            PRIVACY: 0.7,
            TRUST: 0.4,
            INTEGRITY: 0.3,
            CLARITY: 0.2,
        },
        requiresLocation: 'side_room|sacristy|study',
        socialImpact: { GOSSIP: -0.1 as any },
        lawEffect: { confidentialityRule: 'affirmed', enforceable: true }
    },
    {
        tag: PrivacyActionTag.REDACT_SENSITIVE_RECORDS,
        costEnergy: -0.1,
        costTime: 1.0,
        rewardSecondary: {
            PRIVACY: 0.65,
            INTEGRITY: 0.4,
            TRUST: 0.3,
            ORDER: 0.2,
        },
        tradeEffect: { ink: -1, wax: -1 | (0 as any) },
        socialImpact: { TRANSPARENCY: 0.2 as any, HARM: -0.1 as any },
        ownershipEffect: {
            ledgerState: 'redacted',
            accessScope: 'need_to_know',
        },
        lawEffect: { privacyRoll: 'updated', enforceable: true },
        requiredMemes: [
            comm.language.written,
            record.ledgerkeeping,
            econ.pooling_common_fund,
        ]
    },
    {
        tag: PrivacyActionTag.CONFIDE_TRUSTED_CONFIDANT,
        costEnergy: -0.06,
        costTime: 0.8,
        risk: 0.06,
        rewardSecondary: {
            PRIVACY: 0.7,
            TRUST: 0.4,
            RESILIENCE: 0.2,
            CLARITY: 0.2,
        },
        requiresSkill: 'empathy|counsel',
        socialImpact: { BOND: 0.3 as any, GOSSIP: -0.05 as any },
        lawEffect: { oathOfSilence: 'sworn', enforceable: false }
    },
    {
        tag: PrivacyActionTag.PERSONAL_TIME_BLOCK,
        costEnergy: -0.04,
        costTime: 0.5,
        rewardSecondary: {
            PRIVACY: 0.6,
            STABILITY: 0.3,
            CONTROL: 0.3 as any,
            FOCUS: 0.2,
        },
        socialImpact: { RESPECT: 0.2, CONFLICT: -0.05 as any },
        lawEffect: { doNotDisturb: 'posted', enforceable: true }
    },
    {
        tag: PrivacyActionTag.MARKET_PRIVACY_CURTAIN,
        costEnergy: -0.08,
        costTime: 0.8,
        rewardSecondary: {
            PRIVACY: 0.65,
            TRUST: 0.3,
            SECURITY: 0.2,
            FAIRNESS: 0.2,
        },
        requiresLocation: 'market|stall',
        tradeEffect: { curtain: -1, hooks: -1 | (0 as any) },
        socialImpact: { GOSSIP: -0.1 as any, CREDIBILITY: 0.1 },
        ownershipEffect: { boothState: 'curtained' },
        lawEffect: { marketEtiquette: 'observed', enforceable: true }
    },
    {
        tag: PrivacyActionTag.SOUND_DAMPENING_MATS,
        costEnergy: -0.12,
        costTime: 1.0,
        rewardSecondary: {
            PRIVACY: 0.65,
            STABILITY: 0.3,
            CONTROL: 0.2 as any,
            HEALTH: 0.1,
        },
        tradeEffect: { hay_bales: '-N' as any, felt_mats: '-N' as any },
        socialImpact: { CALM: 0.3 as any },
        ownershipEffect: { roomAcoustics: 'dampened' }
    },
    {
        tag: PrivacyActionTag.CONTROL_VISITORS_LEDGER,
        costEnergy: -0.1,
        costTime: 0.9,
        rewardSecondary: {
            PRIVACY: 0.65,
            SECURITY: 0.3,
            CLARITY: 0.3,
            TRUST: 0.2,
        },
        tradeEffect: { parchment: -1, ink: -1 },
        socialImpact: { ABUSE: -0.1 as any, RESPECT: 0.1 },
        ownershipEffect: { visitorLog: 'active', accessScope: 'gate_clerk' },
        lawEffect: { entryRule: 'sign_in_required', enforceable: true },
        requiredMemes: [
            comm.language.written,
            record.ledgerkeeping,
        ]
    },
    {
        tag: PrivacyActionTag.SEALED_LETTER_SERVICE,
        costEnergy: -0.08,
        costTime: 0.9,
        rewardSecondary: {
            PRIVACY: 0.7,
            TRUST: 0.4,
            INTEGRITY: 0.3,
            STABILITY: 0.2,
        },
        tradeEffect: {
            wax: -1,
            ribbon: -1 | (0 as any),
            messenger_fee: -1 as any,
        },
        socialImpact: { GOSSIP: -0.15 as any, CREDIBILITY: 0.2 },
        ownershipEffect: { letterState: 'sealed', chainOfCustody: 'tracked' },
        lawEffect: { tamperPenalty: 'severe', enforceable: true },
        requiredMemes: [
            record.ledgerkeeping,
            econ.pooling_common_fund,
        ]
    },
    {
        tag: PrivacyActionTag.MASK_IDENTITY_ATTIRE,
        costEnergy: -0.06,
        costTime: 0.6,
        risk: 0.06,
        rewardSecondary: {
            CONTROL: 0.3 as any,
            SECURITY: 0.2,
            RESILIENCE: 0.1,
            PRIVACY: 0.6,
        },
        tradeEffect: { hood_cloak: -1 | (0 as any), veil: -1 | (0 as any) },
        socialImpact: { VISIBILITY: -0.2 as any, RESPECT: 0.1 },
        lawEffect: { maskRule: 'allowed_within_market', enforceable: true }
    },
    {
        tag: PrivacyActionTag.BATHING_SCHEDULE_SEPARATE,
        costEnergy: -0.06,
        costTime: 0.7,
        rewardSecondary: {
            PRIVACY: 0.7,
            RESPECT: 0.3,
            HEALTH: 0.2,
            STABILITY: 0.2,
        },
        requiresLocation: 'baths|river_hut',
        socialImpact: { CONFLICT: -0.1 as any, DIGNITY: 0.3 as any },
        lawEffect: { bathRoster: 'posted', enforceable: true }
    },
    {
        tag: PrivacyActionTag.WINDOW_SHUTTERS_PROTOCOL,
        costEnergy: -0.05,
        costTime: 0.5,
        rewardSecondary: {
            CONTROL: 0.25 as any,
            SECURITY: 0.2,
            STABILITY: 0.2,
            PRIVACY: 0.55,
        },
        tradeEffect: { shutters: -1 | (0 as any), cords: -1 | (0 as any) },
        socialImpact: { GAZE: -0.2 as any, RESPECT: 0.1 },
        ownershipEffect: { homeState: 'shutters_rule_active' },
        lawEffect: { nightPrivacy: 'observed', enforceable: true },
        requiredMemes: [
            culture.vigil_ritual,
            cog.timekeeping.basic,
        ]
    },
    {
        tag: PrivacyActionTag.SECLUDED_PATH_MAPPING,
        costEnergy: -0.12,
        costTime: 1.2,
        risk: 0.06,
        rewardSecondary: {
            PRIVACY: 0.7,
            CONTROL: 0.3 as any,
            SECURITY: 0.2,
            CLARITY: 0.2,
        },
        tradeEffect: { parchment: -1, ink: -1, chalk: -1 },
        socialImpact: { CONFLICT: -0.05 as any },
        ownershipEffect: { routeMap: 'secluded_paths_marked' },
        lawEffect: { accessRule: 'private_paths_respected', enforceable: true },
        requiredMemes: [comm.language.written]
    },
];
