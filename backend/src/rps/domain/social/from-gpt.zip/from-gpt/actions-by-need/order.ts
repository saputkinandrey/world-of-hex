import { ActionDefinition } from '../action-definition';
import { OrderActionTag } from '../action-tags';
import { cog, comm, culture, econ, health, record, tech } from '../memes';
export const OrderActions: ActionDefinition[] = [
    {
        tag: OrderActionTag.POST_HOUSE_RULES,
        costEnergy: -0.08,
        costTime: 0.9,
        rewardSecondary: {
            ORDER: 0.65,
            CLARITY: 0.6,
            STABILITY: 0.4,
            FAIRNESS: 0.3,
        },
        tradeEffect: { parchment: -1, ink: -1 },
        socialImpact: { TRUST: 0.2, DISCIPLINE: 0.3 },
        lawEffect: { houseRules: 'posted', enforceable: true },
        ownershipEffect: { accessScope: 'notice_board', grantAccess: true },
        requiredMemes: [comm.language.written]
    },
    {
        tag: OrderActionTag.LAY_FLOOR_MARKS,
        costEnergy: -0.14,
        costTime: 1.4,
        rewardSecondary: {
            ORDER: 0.7,
            EFFICIENCY: 0.4,
            CLARITY: 0.4,
            SAFETY: 0.2 as any,
        },
        tradeEffect: { paint: -1, chalk: -1 },
        socialImpact: { COORDINATION: 0.2 as any, DISCIPLINE: 0.2 },
        ownershipEffect: { layoutMarks: 'painted' },
        requiredMemes: [
            comm.language.written,
            record.ledgerkeeping,
            cog.number_concept,
        ]
    },
    {
        tag: OrderActionTag.APPOINT_STEWARD,
        costEnergy: -0.1,
        costTime: 1.0,
        risk: 0.08,
        rewardSecondary: {
            ORDER: 0.75,
            STABILITY: 0.5,
            CLARITY: 0.5,
            TRUST: 0.3,
        },
        socialImpact: { ACCOUNTABILITY: 0.4 as any, RESPECT: 0.2 },
        lawEffect: { stewardMandate: 'sealed', enforceable: true },
        ownershipEffect: { accessScope: 'stores|keys', grantAccess: true }
    },
    {
        tag: OrderActionTag.DAILY_TIDY_PASS,
        costEnergy: -0.16,
        costTime: 1.2,
        rewardSecondary: {
            ORDER: 0.65,
            EFFICIENCY: 0.3,
            HYGIENE: 0.3,
            CLARITY: 0.3,
        },
        tradeEffect: { brooms: '-wear', linens: '-wear' },
        socialImpact: { DIGNITY: 0.2 as any },
        ownershipEffect: { commonAreas: 'tidy' }
    },
    {
        tag: OrderActionTag.INVENTORY_SHELVING,
        costEnergy: -0.2,
        costTime: 1.8,
        rewardSecondary: {
            ORDER: 0.75,
            CLARITY: 0.5,
            EFFICIENCY: 0.5,
            STABILITY: 0.3,
        },
        tradeEffect: { shelves: -1 | (0 as any), bins: '-N' as any },
        socialImpact: { TRUST: 0.2 },
        ownershipEffect: { storesState: 'shelved', binSystem: 'A-B-C' },
        lawEffect: { storeLedger: 'updated', enforceable: true }
    },
    {
        tag: OrderActionTag.QUEUE_LINE_FORMATION,
        costEnergy: -0.08,
        costTime: 0.8,
        rewardSecondary: {
            ORDER: 0.6,
            FAIRNESS: 0.5,
            CLARITY: 0.4,
            STABILITY: 0.3,
        },
        requiresLocation: 'gate|market|hall',
        socialImpact: { RESENTMENT: -0.15 as any, TRUST: 0.2 },
        lawEffect: { queueRule: 'first_in_line', enforceable: true },
        requiredMemes: [
            culture.vigil_ritual,
            cog.timekeeping.basic,
            comm.language.written,
        ]
    },
    {
        tag: OrderActionTag.STANDARD_BOX_LABELS,
        costEnergy: -0.1,
        costTime: 1.0,
        rewardSecondary: {
            ORDER: 0.65,
            CLARITY: 0.6,
            EFFICIENCY: 0.4,
            QUALITY: 0.2,
        },
        tradeEffect: { dye: -1 | (0 as any), tags: '-N' as any },
        socialImpact: { DISCIPLINE: 0.2 },
        ownershipEffect: { labelScheme: 'standardized' }
    },
    {
        tag: OrderActionTag.SCHEDULE_BELLS,
        costEnergy: -0.06,
        costTime: 0.6,
        rewardSecondary: {
            ORDER: 0.6,
            CLARITY: 0.5,
            STABILITY: 0.4,
            EFFICIENCY: 0.2,
        },
        requiresItem: ['bell|drum'],
        socialImpact: { PUNCTUALITY: 0.3 as any, DISCIPLINE: 0.2 },
        lawEffect: { timeSignals: 'posted', enforceable: true }
    },
    {
        tag: OrderActionTag.SORT_INBOX_OUTBOX,
        costEnergy: -0.1,
        costTime: 0.9,
        rewardSecondary: {
            ORDER: 0.65,
            CLARITY: 0.6,
            EFFICIENCY: 0.4,
            FAIRNESS: 0.2,
        },
        requiresLocation: 'clerk_desk|hall',
        tradeEffect: { trays: -1 | (0 as any) },
        socialImpact: { TRANSPARENCY: 0.3 as any, TRUST: 0.2 },
        ownershipEffect: { messageFlow: 'separated' },
        requiredMemes: [comm.language.written]
    },
    {
        tag: OrderActionTag.MAP_TERRITORY_PLOTS,
        costEnergy: -0.2,
        costTime: 2.0,
        rewardSecondary: {
            ORDER: 0.75,
            STABILITY: 0.5,
            CLARITY: 0.5,
            SECURITY: 0.3,
        },
        tradeEffect: { parchment: -2, ink: -2, pegs: '-N' as any },
        socialImpact: { FAIRNESS: 0.3, TRUST: 0.2 },
        ownershipEffect: { plotMap: 'created', markers: 'placed' },
        lawEffect: { cadaster: 'opened', enforceable: true },
        requiredMemes: [comm.language.written]
    },
    {
        tag: OrderActionTag.ROTATION_ROTA_BOARD,
        costEnergy: -0.12,
        costTime: 1.0,
        rewardSecondary: {
            ORDER: 0.65,
            FAIRNESS: 0.5,
            STABILITY: 0.4,
            DISCIPLINE: 0.3,
        },
        tradeEffect: { chalk: -1, board_use: '+1' },
        socialImpact: { RESENTMENT: -0.1, TRUST: 0.2 },
        lawEffect: { rota: 'posted', enforceable: true },
        ownershipEffect: { accessScope: 'task_board', grantAccess: true },
        requiredMemes: [comm.language.written]
    },
    {
        tag: OrderActionTag.LOST_FOUND_STATION,
        costEnergy: -0.08,
        costTime: 0.8,
        rewardSecondary: {
            ORDER: 0.6,
            TRUST: 0.3,
            CLARITY: 0.3,
            STABILITY: 0.2,
        },
        tradeEffect: { chest: -1 | (0 as any) },
        socialImpact: { COMMUNITY: 0.2, HONOR: 0.2 },
        ownershipEffect: { foundItems: 'catalogued' },
        lawEffect: { lostAndFoundLedger: 'active', enforceable: true }
    },
    {
        tag: OrderActionTag.DISPUTE_QUEUE_TOKENS,
        costEnergy: -0.1,
        costTime: 0.9,
        rewardSecondary: {
            ORDER: 0.7,
            FAIRNESS: 0.6,
            STABILITY: 0.5,
            CLARITY: 0.4,
        },
        tradeEffect: { tokens: '-N' as any },
        socialImpact: { PANIC: -0.2 as any, TRUST: 0.2 },
        lawEffect: { courtDocket: 'numbered', enforceable: true },
        requiredMemes: [
            record.ledgerkeeping,
            econ.pooling_common_fund,
        ]
    },
    {
        tag: OrderActionTag.CLEAN_RECORDS_ARCHIVE,
        costEnergy: -0.16,
        costTime: 1.4,
        rewardSecondary: {
            ORDER: 0.7,
            CLARITY: 0.6,
            EFFICIENCY: 0.3,
            INTEGRITY: 0.3,
        },
        tradeEffect: { parchment: '-rebind', boxes: '-1|0' as any },
        socialImpact: { TRUST: 0.2 },
        ownershipEffect: { archiveState: 'indexed', obsolete: 'purged' },
        lawEffect: { archivePolicy: 'retention_applied', enforceable: true },
        requiredMemes: [
            health.sanitation_norms,
            health.waste_handling,
            comm.language.written,
        ]
    },
    {
        tag: OrderActionTag.ONE_WAY_WALKWAYS,
        costEnergy: -0.12,
        costTime: 1.0,
        rewardSecondary: {
            ORDER: 0.65,
            EFFICIENCY: 0.4,
            SAFETY: 0.2 as any,
            CLARITY: 0.3,
        },
        tradeEffect: { signs: '-N' as any, paint: -1 | (0 as any) },
        socialImpact: { COORDINATION: 0.3 as any },
        lawEffect: { walkwayRule: 'posted', enforceable: true },
        ownershipEffect: { pathsFlow: 'one_way' }
    },
    {
        tag: OrderActionTag.WASTE_SEPARATION_POINTS,
        costEnergy: -0.18,
        costTime: 1.6,
        rewardSecondary: {
            ORDER: 0.7,
            HYGIENE: 0.4,
            EFFICIENCY: 0.3,
            STABILITY: 0.3,
        },
        tradeEffect: { barrels: '-N' as any, lime: -1 },
        socialImpact: { DIGNITY: 0.2 as any, COMMUNITY: 0.2 },
        lawEffect: { wasteCode: 'adopted', enforceable: true },
        ownershipEffect: { refuseStations: 'placed' },
        requiredMemes: [
            health.sanitation_norms,
            health.waste_handling,
            tech.tool.use_basic,
        ]
    },
];
