import { ActionDefinition } from '../action-definition';
import { AccountabilityActionTag } from '../action-tags';
import { cog, comm, culture, econ, health, org, record } from '../memes';
export const AccountabilityActions: ActionDefinition[] = [
    {
        tag: AccountabilityActionTag.DUTY_CHART_POST,
        costEnergy: -0.08,
        costTime: 0.9,
        rewardSecondary: {
            ACCOUNTABILITY: 0.65,
            CLARITY: 0.5,
            ORDER: 0.4,
            TRUST: 0.3,
        },
        tradeEffect: { parchment: -1, ink: -1 },
        ownershipEffect: { roleMatrix: 'posted_named_owners' },
        lawEffect: { dutyCharter: 'ratified', enforceable: true },
        needRework: true,
        requiredMemes: [
            comm.language.written,
            org.duty_roster,
        ]
    },
    {
        tag: AccountabilityActionTag.PERSONAL_WEEKLY_REPORT,
        costEnergy: -0.1,
        costTime: 1.0,
        rewardSecondary: {
            ACCOUNTABILITY: 0.7,
            INTEGRITY: 0.4,
            TRUST: 0.3,
            CLARITY: 0.3,
        },
        tradeEffect: { parchment: -1, ink: -1 },
        ownershipEffect: { worklog: 'weekly_summary_posted' },
        needRework: true,

        requiredMemes: [
            comm.language.written,
            record.ledgerkeeping,
        ]
    },
    {
        tag: AccountabilityActionTag.TASK_HANDOFF_FORMALIZE,
        costEnergy: -0.08,
        costTime: 0.8,
        rewardSecondary: {
            ACCOUNTABILITY: 0.65,
            FAIRNESS: 0.3,
            TRUST: 0.3,
            STABILITY: 0.3,
        },
        needRework: true,

        ownershipEffect: { taskOwner: 'reassigned_with_receipt' },
        lawEffect: { handoffRule: 'required', enforceable: true }
    },
    {
        tag: AccountabilityActionTag.AUDIT_RANDOM_SPOTCHECK,
        costEnergy: -0.12,
        costTime: 0.9,
        risk: 0.06,
        rewardSecondary: {
            ACCOUNTABILITY: 0.65,
            QUALITY: 0.3,
            INTEGRITY: 0.4,
            TRUST: 0.2,
        },
        requiresLocation: 'workyard|stores|gate',
        socialImpact: { TRANSPARENCY: 0.3 as any, RESENTMENT: -0.05 },
        ownershipEffect: { auditNotes: 'logged' },
        needRework: true,

        requiredMemes: [
            culture.vigil_ritual,
            cog.timekeeping.basic,
        ]
    },
    {
        tag: AccountabilityActionTag.WITNESS_SIGNATURES,
        costEnergy: -0.06,
        costTime: 0.7,
        rewardSecondary: {
            ACCOUNTABILITY: 0.6,
            TRUST: 0.4,
            INTEGRITY: 0.4,
            FAIRNESS: 0.3,
        },
        tradeEffect: { wax: -1 | (0 as any) },
        socialImpact: { CREDIBILITY: 0.3, COMMUNITY: 0.2 },
        ownershipEffect: { document: 'witness_countersigned' },
        needRework: true,

        requiredMemes: [
            record.ledgerkeeping,
            econ.pooling_common_fund,
        ]
    },
    {
        tag: AccountabilityActionTag.PUBLIC_RETROSPECT,
        costEnergy: -0.12,
        costTime: 1.2,
        rewardSecondary: {
            ACCOUNTABILITY: 0.75,
            CLARITY: 0.5,
            TRUST: 0.3,
            MORALE: 0.2,
        },
        requiresLocation: 'hall|yard',
        socialImpact: { COHESION: 0.3, TRANSPARENCY: 0.4 as any },
        ownershipEffect: { actionItems: 'issued_named_owners' },
        needRework: true,

        requiredMemes: [
            health.sanitation_norms,
            health.waste_handling,
            comm.language.written,
        ]
    },
    {
        tag: AccountabilityActionTag.INCIDENT_REPORT_FILE,
        costEnergy: -0.1,
        costTime: 1.0,
        risk: 0.08,
        rewardSecondary: {
            ACCOUNTABILITY: 0.65,
            SAFETY: 0.3 as any,
            CLARITY: 0.3,
            TRUST: 0.2,
        },
        tradeEffect: { parchment: -1, ink: -1 },
        ownershipEffect: { incidentLog: 'filed', mitigation: 'assigned' },
        lawEffect: { reportRule: 'mandatory', enforceable: true },
        needRework: true,

        requiredMemes: [
            comm.language.written,
            record.ledgerkeeping,
        ]
    },
    {
        tag: AccountabilityActionTag.CHECKLIST_BEFORE_AFTER,
        costEnergy: -0.08,
        costTime: 0.8,
        rewardSecondary: {
            ACCOUNTABILITY: 0.65,
            QUALITY: 0.4,
            EFFICIENCY: 0.2,
            TRUST: 0.2,
        },
        tradeEffect: { board_or_tablet: -1 | (0 as any) },
        ownershipEffect: { checklist: 'used_pre_post' },
        requiredMemes: [comm.language.written]
    },
    {
        tag: AccountabilityActionTag.TOOL_COUNTERSIGN,
        costEnergy: -0.06,
        costTime: 0.7,
        rewardSecondary: {
            ACCOUNTABILITY: 0.6,
            ORDER: 0.4,
            TRUST: 0.3,
            FAIRNESS: 0.2,
        },
        requiresLocation: 'stores|tool_wall',
        ownershipEffect: { toolLedger: 'countersigned_in_out' },
        needRework: true,

        lawEffect: { depositRule: 'posted', enforceable: true }
    },
    {
        tag: AccountabilityActionTag.WORKLOG_STAMP,
        costEnergy: -0.06,
        costTime: 0.6,
        rewardSecondary: {
            ACCOUNTABILITY: 0.6,
            PRODUCTIVITY: 0.2,
            TRUST: 0.2,
            ORDER: 0.3,
        },
        tradeEffect: { stamp_wax: -1 | (0 as any) },
        ownershipEffect: { worklog: 'time_stamped' },
        needRework: true,

        requiredMemes: [
            record.ledgerkeeping,
            econ.pooling_common_fund,
        ]
    },
    {
        tag: AccountabilityActionTag.PEER_REVIEW_ROTATION,
        costEnergy: -0.12,
        costTime: 1.2,
        rewardSecondary: {
            ACCOUNTABILITY: 0.75,
            QUALITY: 0.4,
            FAIRNESS: 0.3,
            TRUST: 0.3,
        },
        requiresLocation: 'workshop|guild_hall',
        socialImpact: { RESPECT: 0.2, COMPETITION: 0.1 },
        ownershipEffect: { reviewRoster: 'rotating_pairs' },
        needRework: true,

        requiredMemes: [
            comm.language.written,
            org.duty_roster,
            org.workshop_practice,
        ]
    },
    {
        tag: AccountabilityActionTag.ESCALATION_PATH_POST,
        costEnergy: -0.08,
        costTime: 0.7,
        rewardSecondary: {
            ACCOUNTABILITY: 0.65,
            CLARITY: 0.5,
            STABILITY: 0.3,
            TRUST: 0.2,
        },
        tradeEffect: { parchment: -1, ink: -1 },
        ownershipEffect: { noticeBoard: 'escalation_tree_posted' },
        needRework: true,

        requiredMemes: [
            comm.language.written,
            org.duty_roster,
        ]
    },
    {
        tag: AccountabilityActionTag.KPI_TALLY_MARKS,
        costEnergy: -0.1,
        costTime: 0.9,
        rewardSecondary: {
            PRODUCTIVITY: 0.3,
            QUALITY: 0.3,
            CONTROL: 0.3 as any,
            ACCOUNTABILITY: 0.7,
        },
        tradeEffect: { chalk: -1, tokens: '-N' as any },
        ownershipEffect: { boardState: 'kpi_marks_visible' },
        needRework: true,

        requiredMemes: [
            comm.language.written,
            record.ledgerkeeping,
            cog.number_concept,
            econ.pooling_common_fund,
        ]
    },
    {
        tag: AccountabilityActionTag.OATH_OF_OFFICE_RENEW,
        costEnergy: -0.08,
        costTime: 0.8,
        rewardSecondary: {
            ACCOUNTABILITY: 0.7,
            INTEGRITY: 0.5,
            TRUST: 0.3,
            ORDER: 0.2,
        },
        requiresLocation: 'hall|temple',
        socialImpact: { RESPECT: 0.3, DIGNITY: 0.3 as any },
        lawEffect: { oathRecord: 'renewed', enforceable: true },
        needRework: true,

        requiredMemes: [
            culture.vigil_ritual,
            cog.timekeeping.basic,
            comm.language.written,
        ]
    },
    {
        tag: AccountabilityActionTag.BUDGET_POUCH_SEALS,
        costEnergy: -0.1,
        costTime: 0.9,
        rewardSecondary: {
            ACCOUNTABILITY: 0.7,
            TRUST: 0.4,
            FAIRNESS: 0.3,
            ORDER: 0.3,
        },
        tradeEffect: {
            wax: -1,
            ribbon: -1 | (0 as any),
            pouch: -1 | (0 as any),
        },
        socialImpact: { THEFT: -0.1 as any, CREDIBILITY: 0.2 },
        ownershipEffect: { treasuryPouches: 'sealed_with_countersign' },
        lawEffect: { tamperPenalty: 'severe', enforceable: true },
        needRework: true,

        requiredMemes: [
            record.ledgerkeeping,
            econ.pooling_common_fund,
        ]
    },
    {
        tag: AccountabilityActionTag.FEEDBACK_ONE_ON_ONE,
        costEnergy: -0.1,
        costTime: 1.0,
        rewardSecondary: {
            ACCOUNTABILITY: 0.75,
            CLARITY: 0.4,
            QUALITY: 0.3,
            TRUST: 0.3,
        },
        requiresLocation: 'side_room|workbench',
        socialImpact: { LOYALTY: 0.2, RESENTMENT: -0.05 },
        needRework: true,

        ownershipEffect: { improvementPlan: 'agreed_named_actions' }
    },
];
