import { ActionDefinition } from '../action-definition';
import { ActionTags } from '../action-tags';
export const RestActions: ActionDefinition[] = [
    {
        tag: ActionTags.SIT,
        costEnergy: -0.1,
        costTime: 0.5,
        rewardSecondary: { REST: 0.1, COMFORT: 0.1 },
        locationType: 'any'
    },
    {
        tag: ActionTags.LIE_DOWN,
        costEnergy: -0.15,
        costTime: 1,
        risk: 0.05,
        rewardSecondary: { REST: 0.2, HEALTH: 0.1 },
        locationType: 'camp'
    },
    {
        tag: ActionTags.NAP,
        costEnergy: -0.25,
        costTime: 2,
        risk: 0.05,
        rewardSecondary: { REST: 0.4, MOOD: 0.2 },
        locationType: 'any'
    },
    {
        tag: ActionTags.SLEEP,
        costEnergy: -0.4,
        costTime: 6,
        risk: 0.1,
        rewardSecondary: { REST: 1.0, HEALTH: 0.5, MOOD: 0.4 },
        locationType: 'shelter'
    },
    {
        tag: ActionTags.REST_AT_HOME,
        costEnergy: -0.5,
        costTime: 8,
        rewardSecondary: { REST: 1.2, HEALTH: 0.6, MOOD: 0.5 },
        locationType: 'home',
        socialImpact: { communication: 0.1 }
    },
    {
        tag: ActionTags.REST_FIELD,
        costEnergy: -0.2,
        costTime: 3,
        risk: 0.4,
        rewardSecondary: { REST: 0.3, HEALTH: -0.1 },
        locationType: 'field'
    },
    {
        tag: ActionTags.REST_BY_FIRE,
        costEnergy: -0.25,
        costTime: 2,
        risk: 0.05,
        rewardSecondary: { REST: 0.6, COMFORT: 0.4, SOCIAL: 0.2 },
        locationType: 'campfire'
    },
    {
        tag: ActionTags.MEDITATE,
        costEnergy: -0.2,
        costTime: 1,
        risk: 0,
        rewardSecondary: { REST: 0.5, FOCUS: 0.6 },
        skillRequired: 'Discipline',
        locationType: 'quiet'
    },
    {
        tag: ActionTags.RELAX,
        costEnergy: -0.15,
        costTime: 1,
        rewardSecondary: { REST: 0.3, MOOD: 0.3 },
        locationType: 'any'
    },
    {
        tag: ActionTags.SOCIALIZE_FOR_REST,
        costEnergy: -0.1,
        costTime: 2,
        rewardSecondary: { REST: 0.5, SOCIAL: 0.5, MOOD: 0.3 },
        locationType: 'village',
        visibleToOthers: true
    },
    {
        tag: ActionTags.BATHING,
        costEnergy: -0.2,
        costTime: 1.5,
        rewardSecondary: { REST: 0.4, HYGIENE: 0.4, COMFORT: 0.3 },
        locationType: 'river'
    },
    {
        tag: ActionTags.REST_GUARDED,
        costEnergy: -0.3,
        costTime: 6,
        risk: 0.05,
        rewardSecondary: { REST: 1.1, TRUST: 0.4 },
        locationType: 'camp',
        groupAffinity: 0.4
    },
    {
        tag: ActionTags.REST_IN_SHADE,
        costEnergy: -0.2,
        costTime: 1.5,
        rewardSecondary: { REST: 0.3, COMFORT: 0.3 },
        locationType: 'outdoor'
    },
    {
        tag: ActionTags.DREAM,
        costEnergy: -0.4,
        costTime: 7,
        rewardSecondary: { REST: 0.9, INSPIRATION: 0.5, FAITH: 0.3 },
        locationType: 'shelter'
    },
];
