import { ActionDefinition } from '../action-definition';
import { FreedomActionTag } from '../action-tags';
import { comm, econ, record, tech } from '../memes';
export const FreedomActions: ActionDefinition[] = [
    {
        tag: FreedomActionTag.NEGOTIATE_AUTONOMY_PACT,
        costEnergy: -0.18,
        costTime: 1.6,
        risk: 0.15,
        rewardSecondary: {
            FREEDOM: 0.75,
            CONTROL: 0.4,
            STATUS: 0.2,
            STABILITY: 0.2,
        },
        requiresSkill: 'negotiation',
        socialImpact: { FREEDOM: 0.6, RESPECT: 0.2, TRUST: 0.2 },
        ownershipEffect: { accessScope: 'self_schedule', grantAccess: true },
        lawEffect: {
            pactId: 'autonomy_v1',
            enforceable: true,
            terms: 'duty_floor_only',
        }
    },
    {
        tag: FreedomActionTag.DECLARE_PERSONAL_BOUNDARIES,
        costEnergy: -0.08,
        costTime: 0.8,
        rewardSecondary: { FREEDOM: 0.6, STABILITY: 0.2, PURPOSE: 0.2 },
        socialImpact: { FREEDOM: 0.45, RESPECT: 0.25, CONFLICT: 0.05 },
        lawEffect: { notice: 'boundaries_recorded', enforceable: true }
    },
    {
        tag: FreedomActionTag.RESERVE_FREE_TIME_BLOCKS,
        costEnergy: -0.06,
        costTime: 0.6,
        rewardSecondary: { FREEDOM: 0.55, REST: 0.2, MASTERY: 0.1 },
        socialImpact: { FREEDOM: 0.35, RELIABILITY: 0.2 },
        ownershipEffect: { timeBlocks: 'personal_reserved' },
        lawEffect: { rotaPolicy: 'free_block_protected', enforceable: true }
    },
    {
        tag: FreedomActionTag.TRAVEL_WITHOUT_ESCORT,
        costEnergy: -0.25,
        costTime: 2.2,
        risk: 0.2,
        rewardSecondary: { FREEDOM: 0.7, CURIOSITY: 0.3, KNOWLEDGE: 0.2 },
        socialImpact: { FREEDOM: 0.45, COURAGE: 0.2 },
        lawEffect: { checkpointNote: 'solo_travel', enforceable: true },
        ownershipEffect: { accessScope: 'roads|paths', grantAccess: true }
    },
    {
        tag: FreedomActionTag.CHOOSE_WORK_ASSIGNMENT,
        costEnergy: -0.12,
        costTime: 0.9,
        rewardSecondary: { FREEDOM: 0.65, PURPOSE: 0.3, PRODUCTIVITY: 0.2 },
        socialImpact: { FREEDOM: 0.5, MOTIVATION: 0.3 as any },
        lawEffect: {
            assignmentPolicy: 'self_select_allowed',
            enforceable: true,
        }
    },
    {
        tag: FreedomActionTag.REFUSE_UNJUST_ORDER,
        costEnergy: -0.12,
        costTime: 0.6,
        risk: 0.25,
        rewardSecondary: { FREEDOM: 0.65, JUSTICE: 0.4, PURPOSE: 0.2 },
        socialImpact: { FREEDOM: 0.6, RESPECT: 0.3, CONFLICT: 0.2 },
        lawEffect: { whistleblowerShield: 'weak|strong', enforceable: true }
    },
    {
        tag: FreedomActionTag.SWITCH_PATRON_OR_GUILD,
        costEnergy: -0.2,
        costTime: 1.6,
        risk: 0.22,
        rewardSecondary: {
            FREEDOM: 0.7,
            WEALTH: 0.2,
            STATUS: 0.2,
            MASTERY: 0.2,
        },
        tradeEffect: { exit_fee: -2, join_fee: -2 },
        socialImpact: { FREEDOM: 0.55, NETWORK: 0.3, LOYALTY: -0.1 },
        lawEffect: { transferNote: 'guild_switch', enforceable: true },
        ownershipEffect: { accessScope: 'new_guild_assets', grantAccess: true }
    },
    {
        tag: FreedomActionTag.RENOUNCE_DEBT,
        costEnergy: -0.15,
        costTime: 1.0,
        rewardSecondary: { FREEDOM: 0.8, STABILITY: 0.3, STATUS: 0.1 },
        tradeEffect: { pay_off: '-X', collateral_release: 'yes' },
        socialImpact: { FREEDOM: 0.7, TRUST: 0.2 },
        lawEffect: { debtRecord: 'settled', enforceable: true },
        ownershipEffect: { collateral_pledged: false }
    },
    {
        tag: FreedomActionTag.SECURE_TRAVEL_PERMIT,
        costEnergy: -0.1,
        costTime: 0.9,
        rewardSecondary: { FREEDOM: 0.55, SECURITY: 0.2, STABILITY: 0.2 },
        tradeEffect: { fee: -1, seal: 'issued' },
        socialImpact: { FREEDOM: 0.4, TRUST: 0.2 },
        lawEffect: {
            travelPermit: 'granted',
            enforceable: true,
            routes: 'green',
        },
        ownershipEffect: { accessScope: 'gates|bridges', grantAccess: true },
        requiredMemes: [
            record.ledgerkeeping,
            econ.pooling_common_fund,
        ]
    },
    {
        tag: FreedomActionTag.ACQUIRE_PRIVATE_WORKSPACE,
        costEnergy: -0.22,
        costTime: 1.6,
        rewardSecondary: {
            PRODUCTIVITY: 0.4,
            SECURITY: 0.2,
            PRIVACY: 0.4 as any,
            FREEDOM: 0.75,
        },
        tradeEffect: { rent: -2, furnish: -2 },
        socialImpact: { FREEDOM: 0.55, RESPECT: 0.2 },
        ownershipEffect: { accessScope: 'private_workshop', grantAccess: true },
        lawEffect: { leaseRecord: 'signed', enforceable: true }
    },
    {
        tag: FreedomActionTag.HIDE_TRAIL,
        costEnergy: -0.15,
        costTime: 0.8,
        risk: 0.12,
        rewardSecondary: { FREEDOM: 0.55, SECURITY: 0.25, CONTROL: 0.2 },
        requiresSkill: 'stealth',
        socialImpact: { FREEDOM: 0.35, SUSPICION: -0.1 },
        lawEffect: { conductRule: 'legal_evasion_only', enforceable: true }
    },
    {
        tag: FreedomActionTag.ENCRYPT_COMMUNICATION,
        costEnergy: -0.12,
        costTime: 1.0,
        rewardSecondary: { FREEDOM: 0.6, TRUST: 0.2, CONTROL: 0.2 },
        tradeEffect: { cipher_tools: -1, training: -1 },
        socialImpact: { FREEDOM: 0.45, PRIVACY: 0.5 as any },
        lawEffect: { codeUse: 'permitted_with_notice', enforceable: true },
        requiredMemes: [
            comm.language.written,
            tech.tool.use_basic,
        ]
    },
    {
        tag: FreedomActionTag.PORTABLE_TOOLKIT,
        costEnergy: -0.18,
        costTime: 1.4,
        rewardSecondary: { FREEDOM: 0.6, PRODUCTIVITY: 0.3, STABILITY: 0.2 },
        tradeEffect: { assemble_kit: '-materials', weight: '-light' },
        socialImpact: { FREEDOM: 0.4, MOBILITY: 0.4 as any },
        ownershipEffect: { carryCapacity: '+tools_portable' }
    },
    {
        tag: FreedomActionTag.SET_OWN_PRICES,
        costEnergy: -0.06,
        costTime: 0.6,
        risk: 0.1,
        rewardSecondary: { FREEDOM: 0.65, WEALTH: 0.3, STATUS: 0.1 },
        tradeEffect: {
            price_table: 'self_defined',
            contract_terms: 'flexible',
        },
        socialImpact: { FREEDOM: 0.5, REPUTATION: 0.2, ENVY: 0.05 },
        lawEffect: { marketRules: 'price_floor_only', enforceable: true }
    },
    {
        tag: FreedomActionTag.CHART_NEW_ROUTE,
        costEnergy: -0.28,
        costTime: 2.2,
        risk: 0.22,
        rewardSecondary: { FREEDOM: 0.8, KNOWLEDGE: 0.4, WEALTH: 0.2 },
        requiresSkill: 'scouting',
        socialImpact: { FREEDOM: 0.55, FAME: 0.2 },
        lawEffect: { explorationClaim: 'route_logged', enforceable: true },
        ownershipEffect: { routeRight: 'discoverer_bonus' },
        requiredMemes: [comm.language.written]
    },
    {
        tag: FreedomActionTag.ASSERT_RIGHT_TO_SILENCE,
        costEnergy: -0.05,
        costTime: 0.4,
        risk: 0.1,
        rewardSecondary: { FREEDOM: 0.55, JUSTICE: 0.25, STABILITY: 0.15 },
        socialImpact: { FREEDOM: 0.45, RESPECT: 0.2, SUSPICION: 0.05 },
        lawEffect: { rightToSilence: 'invoked', enforceable: true }
    },
];
