import { ActionDefinition } from '../action-definition';
import { ActionTags } from '../action-tags';
export const FoodActions: ActionDefinition[] = [
    {
        tag: ActionTags.FORAGE,
        costEnergy: 0.2,
        costTime: 3,
        risk: 0.1,
        rewardSecondary: { FOOD: 0.4, CURIOSITY: 0.1 },
        skillRequired: 'Survival',
        resourceOutput: ['berries', 'roots'],
        locationType: 'wilderness',
        emotionalImpact: 0.1,
        environmentalImpact: -0.1
    },
    {
        tag: ActionTags.HUNT,
        costEnergy: 0.5,
        costTime: 5,
        risk: 0.4,
        rewardSecondary: { FOOD: 0.8, STATUS: 0.2, WEALTH: 0.1 },
        socialImpact: { respect: +0.1 },
        moralWeight: 0.3,
        groupAffinity: 0.2,
        skillRequired: 'Hunting',
        resourceOutput: ['meat', 'hide'],
        locationType: 'wilderness',
        respectGain: 0.3,
        emotionalImpact: 0.2
    },
    {
        tag: ActionTags.STEAL_FOOD,
        costEnergy: 0.1,
        costTime: 1,
        risk: 0.6,
        rewardSecondary: { FOOD: 0.6 },
        socialImpact: { respect: -0.5 },
        moralWeight: -0.8,
        shameGain: 0.3,
        locationType: 'village',
        visibleToOthers: true,
        emotionalImpact: -0.3
    },
];
