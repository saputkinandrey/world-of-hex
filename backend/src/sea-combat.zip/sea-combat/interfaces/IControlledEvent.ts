export interface IControlledEvent {
  publish: boolean;
}
