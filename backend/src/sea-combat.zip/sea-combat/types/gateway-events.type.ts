export enum WSMessage {
  USER_CONNECTED = 'user-connected.message',
  LOAD_ENCOUNTER = 'load-encounter.message',
}

export enum WSResponse {
  USER_CONNECTED = 'user-connected.response',
  LOAD_ENCOUNTER = 'load-encounter.response',
}
