export enum ShipType {
  DRAKKAR = 'drakkar',
  GALLEON = 'galleon',
  STEAMSHIP = 'steamship',
  TRIREME = 'trireme',
}
