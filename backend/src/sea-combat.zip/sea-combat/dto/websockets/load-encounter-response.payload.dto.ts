import { Encounter } from '../../schemas/encounter.schema';

export type LoadEncounterResponsePayloadDto = Encounter
