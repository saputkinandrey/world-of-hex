import { Injectable } from '@nestjs/common';

import { Encounter } from '../schemas/encounter.schema';
import { PlayerRepository } from '../repositories/player.repository';
import { PlayerDocument } from '../schemas/player.schema';
import { Ship } from '../schemas/ship.schema';

@Injectable()
export class PlayerService {
  encounters: Encounter[] = [];

  constructor(private readonly playerRepository: PlayerRepository) {}

  ownAShip(player: PlayerDocument, ship: Ship) {
    const ownedShip = player.ownedShips.find((owned) => owned._id === ship._id);

    if (ownedShip) {
      throw new Error(
        `Player ${player._id} already owns ship with id ${ship._id}`,
      );
    }

    player.ownedShips.push({ _id: ship._id });

    return player.save();
  }
}
