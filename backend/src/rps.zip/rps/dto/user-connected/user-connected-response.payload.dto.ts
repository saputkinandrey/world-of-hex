export type UserConnectedResponsePayloadDto = boolean;
