import { StabilityActionTag } from '../action-tags';
import { ActionDefinition } from '../action-definition';
import { cog, comm, culture } from '../../world/memes';
export const StabilityActions: ActionDefinition[] = [
    {
        tag: StabilityActionTag.MAINTAIN_STORAGE,
        costEnergy: -0.3,
        costTime: 2,
        rewardSecondary: { STABILITY: 0.7, SECURITY: 0.4, CONTROL: 0.3 },
        requiresItem: ['tools'],
        requiresLocation: 'granary',
        requiresSkill: 'organization'
    },
    {
        tag: StabilityActionTag.REPAIR_TOOLS,
        costEnergy: -0.2,
        costTime: 1,
        rewardSecondary: { STABILITY: 0.4, CONTROL: 0.2, MASTERY: 0.2 },
        requiresItem: ['broken_tool', 'iron'],
        requiresSkill: 'crafting'
    },
    {
        tag: StabilityActionTag.HOLD_COUNCIL,
        costEnergy: -0.5,
        costTime: 3,
        rewardSecondary: { STABILITY: 0.8, COMMUNITY: 0.6, LAW: 0.5 },
        requiresLocation: 'hall',
        targetType: 'GROUP',
        requiresSkill: 'leadership',
        requiredMemes: [comm.language.written]
    },
    {
        tag: StabilityActionTag.FOLLOW_TRADITION,
        costEnergy: -0.1,
        costTime: 1,
        rewardSecondary: { STABILITY: 0.6, TRADITION: 0.7, SPIRIT: 0.3 },
        moralWeight: 0.5
    },
    {
        tag: StabilityActionTag.MANAGE_SUPPLIES,
        costEnergy: -0.4,
        costTime: 2,
        rewardSecondary: { STABILITY: 0.8, SECURITY: 0.5, CONTROL: 0.4 },
        requiresSkill: 'logistics'
    },
    {
        tag: StabilityActionTag.RESTORE_ORDER,
        costEnergy: -0.3,
        costTime: 1.5,
        rewardSecondary: { STABILITY: 0.7, LAW: 0.6, CONTROL: 0.5 },
        requiresSkill: 'leadership',
        targetType: 'GROUP'
    },
    {
        tag: StabilityActionTag.MEDIATE_CONFLICT,
        costEnergy: -0.2,
        costTime: 2,
        rewardSecondary: { STABILITY: 0.6, TRUST: 0.5, COMMUNITY: 0.3 },
        requiresSkill: 'diplomacy'
    },
    {
        tag: StabilityActionTag.HOLD_CEREMONY,
        costEnergy: -0.4,
        costTime: 3,
        rewardSecondary: { STABILITY: 0.8, COMMUNITY: 0.5, TRADITION: 0.6 },
        requiresLocation: 'temple',
        requiredMemes: [
            culture.vigil_ritual,
            cog.timekeeping.basic,
        ]
    },
    {
        tag: StabilityActionTag.KEEP_RECORDS,
        costEnergy: -0.15,
        costTime: 1,
        rewardSecondary: { STABILITY: 0.5, KNOWLEDGE: 0.3, CONTROL: 0.2 },
        requiresItem: ['parchment', 'ink'],
        requiresSkill: 'writing'
    },
    {
        tag: StabilityActionTag.PLANT_SEASONAL_CROPS,
        costEnergy: -0.6,
        costTime: 4,
        rewardSecondary: { STABILITY: 0.7, FOOD: 0.5, TRADITION: 0.3 },
        requiresSkill: 'farming',
        locationType: 'fields'
    },
];
