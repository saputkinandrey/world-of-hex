import { ActionDefinition } from '../action-definition';
import { JusticeActionTag } from '../action-tags';
import { cog, comm, culture, econ, health, record } from '../../world/memes';
export const JusticeActions: ActionDefinition[] = [
    {
        tag: JusticeActionTag.ACCUSE_OFFENDER,
        costEnergy: -0.1,
        costTime: 0.5,
        risk: 0.2,
        rewardSecondary: { JUSTICE: 0.4, LAW: 0.3, TRUST: 0.2 },
        requiresSkill: 'Oratory',
        targetType: 'OTHER',
        socialImpact: { respect: +0.2 },
        requiresLocation: 'assembly'
    },
    {
        tag: JusticeActionTag.GATHER_EVIDENCE,
        costEnergy: -0.3,
        costTime: 2,
        risk: 0.15,
        rewardSecondary: { JUSTICE: 0.6, KNOWLEDGE: 0.4, LAW: 0.3 },
        requiresSkill: 'Investigation',
        locationType: 'any'
    },
    {
        tag: JusticeActionTag.TESTIFY,
        costEnergy: -0.1,
        costTime: 0.5,
        risk: 0.1,
        rewardSecondary: { JUSTICE: 0.4, TRUST: 0.3, COMMUNITY: 0.2 },
        requiresSkill: 'Honesty',
        requiresLocation: 'court',
        visibleToOthers: true
    },
    {
        tag: JusticeActionTag.DEMAND_RESTITUTION,
        costEnergy: -0.1,
        costTime: 0.5,
        risk: 0.2,
        rewardSecondary: { JUSTICE: 0.6, CONTROL: 0.2, WEALTH: 0.3 },
        targetType: 'OTHER',
        socialImpact: { respect: +0.1 }
    },
    {
        tag: JusticeActionTag.PAY_BLOOD_PRICE,
        costEnergy: -0.1,
        costTime: 0.2,
        rewardSecondary: { JUSTICE: 0.7, STABILITY: 0.4, COMMUNITY: 0.3 },
        requiresItem: ['valuables'],
        moralWeight: 0.5,
        socialImpact: { respect: +0.3 }
    },
    {
        tag: JusticeActionTag.PUBLIC_APOLOGY,
        costEnergy: -0.05,
        costTime: 0.3,
        risk: 0.05,
        rewardSecondary: { JUSTICE: 0.5, RESPECT: 0.3, COMMUNITY: 0.3 },
        moralWeight: 0.4,
        visibleToOthers: true,
        requiresLocation: 'public_square',
        requiredMemes: [
            health.sanitation_norms,
            health.waste_handling,
            comm.language.written,
        ]
    },
    {
        tag: JusticeActionTag.REPUTATION_RESTORATION,
        costEnergy: -0.2,
        costTime: 1,
        rewardSecondary: { JUSTICE: 0.8, STATUS: 0.4, RESPECT: 0.5 },
        requiresSkill: 'Diplomacy',
        socialImpact: { respect: +0.4 }
    },
    {
        tag: JusticeActionTag.NEGOTIATE_SETTLEMENT,
        costEnergy: -0.2,
        costTime: 1.5,
        risk: 0.15,
        rewardSecondary: { JUSTICE: 0.7, STABILITY: 0.5, COMMUNITY: 0.4 },
        requiresSkill: 'Negotiation',
        targetType: 'GROUP'
    },
    {
        tag: JusticeActionTag.MEDIATE_REPARATION,
        costEnergy: -0.2,
        costTime: 1.5,
        rewardSecondary: { JUSTICE: 0.6, TRUST: 0.4, LAW: 0.3 },
        requiresSkill: 'Mediation',
        targetType: 'GROUP'
    },
    {
        tag: JusticeActionTag.SHUN_OFFENDER,
        costEnergy: -0.05,
        costTime: 0.2,
        risk: 0.1,
        rewardSecondary: { JUSTICE: 0.5, COMMUNITY: 0.3, CONTROL: 0.2 },
        moralWeight: 0.2,
        socialImpact: { respect: +0.3 },
        targetType: 'OTHER'
    },
    {
        tag: JusticeActionTag.CURSE_OFFENDER,
        costEnergy: -0.1,
        costTime: 0.5,
        rewardSecondary: { JUSTICE: 0.6, SPIRIT: 0.4, COMMUNITY: 0.2 },
        requiresSkill: 'Ritualism',
        requiresLocation: 'temple',
        moralWeight: 0.3,
        requiredMemes: [
            culture.vigil_ritual,
            cog.timekeeping.basic,
        ]
    },
    {
        tag: JusticeActionTag.DUEL_OF_HONOR,
        costEnergy: -0.6,
        costTime: 1,
        risk: 0.6,
        rewardSecondary: { JUSTICE: 0.9, HONOR: 0.6, STATUS: 0.4 },
        requiresItem: ['weapon'],
        requiresSkill: 'Combat',
        targetType: 'OTHER'
    },
    {
        tag: JusticeActionTag.APPEAL_VERDICT,
        costEnergy: -0.2,
        costTime: 1,
        risk: 0.1,
        rewardSecondary: { JUSTICE: 0.5, LAW: 0.4, TRUST: 0.2 },
        requiresSkill: 'Rhetoric',
        requiresLocation: 'council_hall',
        requiredMemes: [comm.language.written]
    },
    {
        tag: JusticeActionTag.REDEEM_OFFENDER,
        costEnergy: -0.3,
        costTime: 2,
        rewardSecondary: { JUSTICE: 0.7, COMMUNITY: 0.4, LOYALTY: 0.3 },
        requiresSkill: 'Leadership',
        targetType: 'OTHER'
    },
    {
        tag: JusticeActionTag.PLEDGE_NO_REVENGE,
        costEnergy: -0.05,
        costTime: 0.2,
        rewardSecondary: { JUSTICE: 0.4, STABILITY: 0.3, TRUST: 0.3 },
        requiresLocation: 'temple',
        moralWeight: 0.4,
        requiredMemes: [
            culture.vigil_ritual,
            cog.timekeeping.basic,
            record.ledgerkeeping,
            econ.pooling_common_fund,
            econ.deposit_contract,
        ]
    },
    {
        tag: JusticeActionTag.VOW_REVENGE,
        costEnergy: -0.1,
        costTime: 0.2,
        risk: 0.4,
        rewardSecondary: { JUSTICE: 0.6, POWER: 0.2 },
        moralWeight: -0.3,
        emotionalImpact: -0.1
    },
];
