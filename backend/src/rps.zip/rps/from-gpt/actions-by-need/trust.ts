import { ActionDefinition } from '../action-definition';
import { ActionTags, TrustActionTag } from '../action-tags';
import { econ, record } from '../../world/memes';
export const TrustActions: ActionDefinition[] = [
    {
        tag: TrustActionTag.KEEP_PROMISE,
        costEnergy: -0.05,
        costTime: 0.5,
        rewardSecondary: { TRUST: 0.7, REPUTATION: 0.3, LOYALTY: 0.3 },
        socialImpact: { TRUST: 0.6, RELIABILITY: 0.4 },
        lawEffect: { note: 'promise_fulfilled', enforceable: false }
    },
    {
        tag: TrustActionTag.SHARE_SECRET,
        costEnergy: -0.05,
        costTime: 0.4,
        risk: 0.15,
        rewardSecondary: { TRUST: 0.6, AFFECTION: 0.2, BELONGING: 0.2 },
        socialImpact: { TRUST: 0.5, INTIMACY: 0.4 },
        ownershipEffect: {
            confidentiality: 'MUTUAL',
            accessScope: 'personal_story',
        }
    },
    {
        tag: TrustActionTag.TRANSPARENT_ACCOUNTING,
        costEnergy: -0.1,
        costTime: 1.2,
        rewardSecondary: { TRUST: 0.7, LAW: 0.2, STABILITY: 0.2 },
        tradeEffect: { ledger_open: 'yes', delta_visible: '+all' },
        socialImpact: { TRUST: 0.5, SUSPICION: -0.3 },
        lawEffect: { auditTrail: 'created', enforceable: true },
        requiredMemes: [
            record.ledgerkeeping,
            econ.pooling_common_fund,
        ]
    },
    {
        tag: TrustActionTag.PLEDGE_COLLATERAL,
        costEnergy: -0.05,
        costTime: 0.3,
        risk: 0.1,
        rewardSecondary: { TRUST: 0.6, LAW: 0.2, PROPERTY: 0.2 },
        ownershipEffect: {
            collateral_pledged: true,
            itemRef: 'ring#12',
            holder: 'counterparty',
        },
        socialImpact: { TRUST: 0.45 },
        lawEffect: { bondRecord: 'collateral_v1', enforceable: true },
        requiredMemes: [
            record.ledgerkeeping,
            econ.pooling_common_fund,
            econ.deposit_contract,
        ]
    },
    {
        tag: TrustActionTag.SMALL_FAVOR_TEST,
        costEnergy: -0.1,
        costTime: 0.8,
        rewardSecondary: { TRUST: 0.5, COMMUNITY: 0.2 },
        socialImpact: { TRUST: 0.3, SCREENING: 0.3 },
        lawEffect: { agreement: 'favor_test_informal', enforceable: false }
    },
    {
        tag: TrustActionTag.RETURN_BORROWED,
        costEnergy: -0.05,
        costTime: 0.4,
        rewardSecondary: { TRUST: 0.6, LAW: 0.2, REPUTATION: 0.2 },
        tradeEffect: { return_item: 'loaned_item', note: 'returned_intact' },
        socialImpact: { TRUST: 0.5, RELIABILITY: 0.4 }
    },
    {
        tag: TrustActionTag.VOUCH_FOR,
        costEnergy: -0.05,
        costTime: 0.3,
        risk: 0.2,
        rewardSecondary: { TRUST: 0.6, STATUS: 0.2, COMMUNITY: 0.2 },
        socialImpact: { TRUST: 0.5, TRANSITIVE_TRUST: 0.4 },
        lawEffect: { surety: 'personal_vouch', enforceable: true }
    },
    {
        tag: ActionTags.MUTUAL_AID_PACT,
        costEnergy: -0.15,
        costTime: 1.5,
        rewardSecondary: { TRUST: 0.8, BELONGING: 0.5, LOYALTY: 0.3 },
        socialImpact: { TRUST: 0.6, COHESION: 0.5 },
        lawEffect: {
            pactId: 'mutual_aid_v1',
            enforceable: true,
            duration: 'season',
        },
        requiredMemes: [
            record.ledgerkeeping,
            econ.pooling_common_fund,
        ]
    },
    {
        tag: TrustActionTag.ACCOMPANY_RISKY_TRIP,
        costEnergy: -0.35,
        costTime: 3,
        risk: 0.35,
        rewardSecondary: { TRUST: 0.8, SECURITY: 0.4, AFFECTION: 0.3 },
        socialImpact: { TRUST: 0.6, COURAGE: 0.3 },
        ownershipEffect: { sharedLiability: true }
    },
    {
        tag: TrustActionTag.GUARD_SLEEP,
        costEnergy: -0.25,
        costTime: 2,
        rewardSecondary: { TRUST: 0.6, SECURITY: 0.4, BELONGING: 0.3 },
        socialImpact: { TRUST: 0.5, CARE: 0.3 },
        ownershipEffect: { accessScope: 'camp_perimeter', grantAccess: true }
    },
    {
        tag: TrustActionTag.REVEAL_VULNERABILITY,
        costEnergy: -0.05,
        costTime: 0.6,
        risk: 0.2,
        rewardSecondary: { TRUST: 0.7, AFFECTION: 0.4, RESPECT: 0.2 },
        socialImpact: { TRUST: 0.6, INTIMACY: 0.5 },
        lawEffect: { confidentialityOath: 'verbal', enforceable: false }
    },
    {
        tag: TrustActionTag.FORGIVE_MISTAKE,
        costEnergy: -0.05,
        costTime: 0.4,
        rewardSecondary: { TRUST: 0.6, COMMUNITY: 0.3, JUSTICE: 0.2 },
        socialImpact: { TRUST: 0.5, GOODWILL: 0.4 }
    },
    {
        tag: TrustActionTag.VERIFY_RECORDS,
        costEnergy: -0.1,
        costTime: 1.0,
        rewardSecondary: { TRUST: 0.5, KNOWLEDGE: 0.3, LAW: 0.2 },
        tradeEffect: { audit: 'performed', mismatch: 'none|some' },
        socialImpact: { TRUST: 0.4, SUSPICION: -0.2 },
        lawEffect: { auditReport: 'filed', enforceable: true }
    },
    {
        tag: TrustActionTag.ESCROW_EXCHANGE,
        costEnergy: -0.15,
        costTime: 1.5,
        rewardSecondary: { TRUST: 0.7, STABILITY: 0.3, LAW: 0.3 },
        tradeEffect: {
            escrow_hold: 'itemA|itemB',
            condition: 'mutual_release',
        },
        socialImpact: { TRUST: 0.5, FAIRNESS: 0.4 },
        lawEffect: { escrowContract: 'escrow_v1', enforceable: true },
        ownershipEffect: { transferOnCondition: true }
    },
    {
        tag: TrustActionTag.CONSISTENT_ATTENDANCE,
        costEnergy: -0.05,
        costTime: 1.0,
        rewardSecondary: { TRUST: 0.5, STABILITY: 0.3, BELONGING: 0.3 },
        socialImpact: { RELIABILITY: 0.5, TRUST: 0.4 },
        lawEffect: { attendanceLog: 'update', enforceable: false }
    },
    {
        tag: TrustActionTag.HANDSHAKE_OATH,
        costEnergy: -0.02,
        costTime: 0.2,
        rewardSecondary: { TRUST: 0.5, RESPECT: 0.2, COMMUNITY: 0.2 },
        socialImpact: { TRUST: 0.5, HONOR: 0.3 },
        lawEffect: { oathType: 'informal_handshake', enforceable: false }
    },
];
