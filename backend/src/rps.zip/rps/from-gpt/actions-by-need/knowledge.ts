import { ActionDefinition } from '../action-definition';
import { KnowledgeActionTag } from '../action-tags';
import { cog, comm, econ, fire, heat, org, record, tech } from '../../world/memes';
export const KnowledgeActions: ActionDefinition[] = [
    {
        tag: KnowledgeActionTag.VISIT_LIBRARY,
        costEnergy: -0.08,
        costTime: 1.0,
        rewardSecondary: {
            KNOWLEDGE: 0.55,
            MASTERY: 0.2,
            TRADITION: 0.1,
            STABILITY: 0.1,
        },
        requiresLocation: 'library|scriptorium',
        socialImpact: { KNOWLEDGE: 0.45, SCHOLARLY: 0.3 as any },
        ownershipEffect: {
            accessScope: 'stacks|reading_room',
            grantAccess: true,
        },
        lawEffect: { readerPass: 'issued', enforceable: true }
    },
    {
        tag: KnowledgeActionTag.STUDY_SCROLL,
        costEnergy: -0.12,
        costTime: 1.6,
        rewardSecondary: { KNOWLEDGE: 0.65, MASTERY: 0.4, PURPOSE: 0.2 },
        requiresItem: ['scroll|treatise'],
        tradeEffect: { ink_marks: '-minor', lamp_oil: -1 },
        needRework: true,
        requiredMemes: [
            comm.language.written,
            record.ledgerkeeping,
            cog.number_concept,
        ],
        socialImpact: { KNOWLEDGE: 0.5, DISCIPLINE: 0.3 as any },
        lawEffect: { loanSlip: 'signed', enforceable: true }
    },
    {
        tag: KnowledgeActionTag.COPY_MANUSCRIPT,
        costEnergy: -0.2,
        costTime: 2.5,
        rewardSecondary: {
            KNOWLEDGE: 0.7,
            TRADITION: 0.3,
            COMMUNITY: 0.2,
            MASTERY: 0.2,
        },
        requiresItem: ['parchment', 'ink', 'quill'],
        tradeEffect: { parchment: -2, ink: -1, copy_out: '+1' },
        socialImpact: { KNOWLEDGE: 0.55, ACCESSIBILITY: 0.4 as any },
        ownershipEffect: { manuscriptCopy: 'created', provenance: 'scribe' },
        lawEffect: { scriptoriumRecord: 'updated', enforceable: true },
        requiredMemes: [
            comm.language.written,
            record.ledgerkeeping,
        ]
    },
    {
        tag: KnowledgeActionTag.ATTEND_LECTURE,
        costEnergy: -0.1,
        costTime: 1.2,
        rewardSecondary: { COMMUNITY: 0.2, REPUTATION: 0.1, KNOWLEDGE: 0.4 },
        requiresLocation: 'hall|guild_room',
        tradeEffect: { fee: -1 },
        socialImpact: { KNOWLEDGE: 0.5, NETWORK: 0.3, INSPIRATION: 0.2 as any },
        lawEffect: { lectureRoll: 'attendance_marked', enforceable: true },
        requiredMemes: [comm.language.written]
    },
    {
        tag: KnowledgeActionTag.OBSERVE_MASTER_WORK,
        costEnergy: -0.15,
        costTime: 1.6,
        rewardSecondary: { KNOWLEDGE: 0.65, MASTERY: 0.4, RESPECT: 0.2 },
        requiresLocation: 'workshop|forge|lab',
        socialImpact: { KNOWLEDGE: 0.5, HUMILITY: 0.2 as any },
        ownershipEffect: { accessScope: 'master_workbench', grantAccess: true },
        lawEffect: { visitorBadge: 'issued', enforceable: true },
        requiredMemes: [
            heat.industrial,
            fire.control,
            comm.language.written,
            org.workshop_practice,
        ]
    },
    {
        tag: KnowledgeActionTag.RUN_EXPERIMENT,
        costEnergy: -0.25,
        costTime: 2.0,
        risk: 0.22,
        rewardSecondary: { KNOWLEDGE: 0.8, MASTERY: 0.5, STATUS: 0.1 },
        requiresItem: ['lab_kit|forge_tools'],
        tradeEffect: { reagents: -2, wear_tools: '-minor' },
        socialImpact: { KNOWLEDGE: 0.6, INNOVATION_REP: 0.3 as any },
        lawEffect: { testPermit: 'granted', enforceable: true },
        ownershipEffect: { labNotebook: 'updated' },
        requiredMemes: [
            fire.control,
            comm.language.written,
            tech.tool.use_basic,
        ]
    },
    {
        tag: KnowledgeActionTag.FIELD_RESEARCH,
        costEnergy: -0.28,
        costTime: 2.4,
        risk: 0.2,
        rewardSecondary: { CURIOSITY: 0.4, KNOWLEDGE: 0.5 },
        tradeEffect: { travel_supplies: -2, markers: -1 },
        socialImpact: { KNOWLEDGE: 0.6, DISCOVERY: 0.5 as any },
        ownershipEffect: { fieldNotes: 'recorded', samples: '+N' },
        lawEffect: { explorationPermit: 'issued', enforceable: true }
    },
    {
        tag: KnowledgeActionTag.GATHER_ORAL_TRADITIONS,
        costEnergy: -0.16,
        costTime: 1.8,
        rewardSecondary: { KNOWLEDGE: 0.6, COMMUNITY: 0.3, TRADITION: 0.4 },
        tradeEffect: { gifts_for_elders: -1 },
        socialImpact: { KNOWLEDGE: 0.5, MEMORY: 0.5 as any, TRUST: 0.2 },
        ownershipEffect: {
            recordings: 'stories_collected',
            accessScope: 'archive',
        },
        lawEffect: { oralHistoryRoll: 'logged', enforceable: true }
    },
    {
        tag: KnowledgeActionTag.CROSSCHECK_SOURCES,
        costEnergy: -0.14,
        costTime: 1.6,
        rewardSecondary: { KNOWLEDGE: 0.6, STABILITY: 0.3, JUSTICE: 0.2 },
        socialImpact: {
            KNOWLEDGE: 0.55,
            CREDIBILITY: 0.5 as any,
            SKEPTICISM: 0.3,
        },
        lawEffect: { peerReviewNote: 'entered', enforceable: true }
    },
    {
        tag: KnowledgeActionTag.CATALOGUE_ARCHIVE,
        costEnergy: -0.2,
        costTime: 2.2,
        rewardSecondary: { KNOWLEDGE: 0.65, STABILITY: 0.4, TRADITION: 0.3 },
        tradeEffect: { labels: '-N', shelves: 'rearranged' },
        socialImpact: { KNOWLEDGE: 0.5, ACCESSIBILITY: 0.5, ORDER: 0.3 as any },
        ownershipEffect: { archiveIndex: 'v1', accessScope: 'catalogue' },
        lawEffect: { archiveCharter: 'updated', enforceable: true }
    },
    {
        tag: KnowledgeActionTag.MAP_TERRITORY,
        costEnergy: -0.3,
        costTime: 2.8,
        risk: 0.18,
        rewardSecondary: { KNOWLEDGE: 0.85, CONTROL: 0.3, WEALTH: 0.2 },
        requiresItem: ['compass|astrolabe', 'parchment'],
        tradeEffect: { ink: -1, parchment: -2 },
        socialImpact: { KNOWLEDGE: 0.65, READINESS: 0.3 as any },
        ownershipEffect: { mapSheet: 'created', rights: 'cartographer_credit' },
        lawEffect: { mapRegistry: 'filed', enforceable: true },
        requiredMemes: [comm.language.written]
    },
    {
        tag: KnowledgeActionTag.COMPILE_HANDBOOK,
        costEnergy: -0.26,
        costTime: 2.4,
        rewardSecondary: { KNOWLEDGE: 0.8, MASTERY: 0.5, COMMUNITY: 0.3 },
        tradeEffect: { parchment: -3, ink: -2, copies: '+1' },
        socialImpact: { KNOWLEDGE: 0.65, EFFICIENCY_REP: 0.4 as any },
        ownershipEffect: { handbook: 'compiled', license: 'open|guild_only' },
        lawEffect: { guildSeal: 'granted', enforceable: true },
        requiredMemes: [comm.language.written]
    },
    {
        tag: KnowledgeActionTag.TEACH_SEMINAR,
        costEnergy: -0.22,
        costTime: 2.0,
        rewardSecondary: {
            KNOWLEDGE: 0.75,
            COMMUNITY: 0.4,
            STATUS: 0.2,
            MASTERY: 0.3,
        },
        requiresLocation: 'hall|workshop',
        tradeEffect: { fee_collected: '+X', materials_used: -1 },
        socialImpact: { KNOWLEDGE: 0.6, RESPECT: 0.4, NETWORK: 0.3 },
        ownershipEffect: { accessScope: 'classroom', grantAccess: true },
        lawEffect: { classRoll: 'recorded', enforceable: true },
        requiredMemes: [
            comm.language.written,
            org.workshop_practice,
        ]
    },
    {
        tag: KnowledgeActionTag.DEBATE_THEORY,
        costEnergy: -0.12,
        costTime: 1.2,
        risk: 0.12,
        rewardSecondary: { PURPOSE: 0.2, STATUS: 0.1, KNOWLEDGE: 0.4 },
        requiresLocation: 'assembly|guild_hall',
        socialImpact: {
            KNOWLEDGE: 0.55,
            CLARITY: 0.4 as any,
            CONTROVERSY: 0.2,
        },
        lawEffect: { debateDocket: 'logged', enforceable: true },
        requiredMemes: [
            comm.language.written,
            org.workshop_practice,
        ]
    },
    {
        tag: KnowledgeActionTag.OPEN_SCHOLARS_CIRCLE,
        costEnergy: -0.22,
        costTime: 2.2,
        rewardSecondary: {
            KNOWLEDGE: 0.8,
            COMMUNITY: 0.5,
            TRADITION: 0.2,
            STATUS: 0.2,
        },
        tradeEffect: { tea_and_bread: -2, room_rent: -1 },
        socialImpact: { KNOWLEDGE: 0.65, NETWORK: 0.6, INFLUENCE: 0.3 as any },
        ownershipEffect: { societyRoom: 'reserved', membership: 'initiated' },
        lawEffect: { societyCharter: 'filed', enforceable: true }
    },
    {
        tag: KnowledgeActionTag.SEAL_SECRET_KNOWLEDGE,
        costEnergy: -0.1,
        costTime: 1.0,
        rewardSecondary: { KNOWLEDGE: 0.55, CONTROL: 0.3, STATUS: 0.1 },
        risk: 0.1,
        tradeEffect: { seal_wax: -1, lockbox: '-1' },
        socialImpact: { KNOWLEDGE: 0.4, TRUST: 0.2, SUSPICION: 0.15 },
        ownershipEffect: {
            accessScope: 'restricted_shelf',
            accessLevel: 'PRIVILEGED',
            grantAccess: true,
        },
        lawEffect: { secrecyWrit: 'issued', enforceable: true },
        requiredMemes: [
            record.ledgerkeeping,
            econ.pooling_common_fund,
        ]
    },
];
