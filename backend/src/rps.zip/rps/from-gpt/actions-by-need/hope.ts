import { ActionDefinition } from '../action-definition';
import { HopeActionTag } from '../action-tags';
import { cog, comm, culture, econ, health, heat, org, record, tech } from '../../world/memes';
export const HopeActions: ActionDefinition[] = [
    {
        tag: HopeActionTag.DAWN_TORCH_RUN,
        costEnergy: -0.08,
        costTime: 0.8,
        rewardSecondary: {
            MORALE: 0.4,
            COMMUNITY: 0.3,
            INSPIRATION: 0.3 as any,
            HOPE: 0.7,
        },
        requiresLocation: 'gate|main_road',
        tradeEffect: { resin_torches: -1 | (0 as any), oil: -1 | (0 as any) },
        requiredMemes: [
            culture.vigil_ritual,
            cog.timekeeping.basic,
        ],
        socialImpact: { COHESION: 0.3, TRADITION: 0.2 as any },
        ownershipEffect: { routeMarkers: 'placed' }
    },
    {
        tag: HopeActionTag.FOUNDATION_STONE_RITUAL,
        costEnergy: -0.1,
        costTime: 1.0,
        rewardSecondary: {
            STABILITY: 0.3,
            PURPOSE: 0.3 as any,
            COMMUNITY: 0.3,
            HOPE: 0.75,
        },
        requiresLocation: 'hall|construction_site',
        tradeEffect: { stone: -1, ribbon: -1 | (0 as any) },
        socialImpact: { DIGNITY: 0.3 as any, FAITH: 0.2 as any },
        ownershipEffect: { cornerstone: 'laid_named_inscription' },
        lawEffect: { memorialRecord: 'entered', enforceable: false },
        requiredMemes: [
            comm.language.written,
            record.ledgerkeeping,
            econ.pooling_common_fund,
        ]
    },
    {
        tag: HopeActionTag.FUTURE_MURAL_PAINT,
        costEnergy: -0.12,
        costTime: 1.2,
        rewardSecondary: {
            CREATIVITY: 0.5 as any,
            COMMUNITY: 0.3,
            RESPECT: 0.2 as any,
            HOPE: 0.8,
        },
        requiresLocation: 'wall|square',
        tradeEffect: { pigments: -1, lime: -1 | (0 as any) },
        socialImpact: { BEAUTIFICATION: 0.4 as any, OWNERSHIP: 0.2 as any },
        ownershipEffect: { muralPanel: 'painted_with_signoffs' },
        requiredMemes: [
            health.sanitation_norms,
            health.waste_handling,
            tech.tool.use_basic,
            comm.language.written,
        ]
    },
    {
        tag: HopeActionTag.SEED_SHARE_FAIR,
        costEnergy: -0.1,
        costTime: 1.1,
        rewardSecondary: {
            RESILIENCE: 0.4 as any,
            FOOD: 0.3 as any,
            TRUST: 0.2,
            HOPE: 0.75,
        },
        requiresLocation: 'yard|market',
        tradeEffect: {
            seed_packets: '+variety' as any,
            tables: -1 | (0 as any),
        },
        socialImpact: { NETWORKS: 0.3 as any },
        ownershipEffect: { seedLedger: 'varieties_logged' },
        requiredMemes: [
            health.sanitation_norms,
            health.waste_handling,
        ]
    },
    {
        tag: HopeActionTag.APPRENTICE_DAY,
        costEnergy: -0.08,
        costTime: 1.0,
        rewardSecondary: {
            MASTERY: 0.4 as any,
            BELONGING: 0.2,
            RESPECT: 0.2 as any,
            HOPE: 0.7,
        },
        requiresLocation: 'workshop|guild_hall',
        socialImpact: { YOUTH_ENGAGEMENT: 0.4 as any, COHESION: 0.2 },
        ownershipEffect: { apprenticeRoster: 'assigned_pairs' },
        requiredMemes: [
            comm.language.written,
            org.duty_roster,
            org.workshop_practice,
        ]
    },
    {
        tag: HopeActionTag.GOOD_NEWS_CRIER,
        costEnergy: -0.06,
        costTime: 0.6,
        rewardSecondary: { HOPE: 0.6, JOY: 0.4 as any, TRUST: 0.2, ORDER: 0.1 },
        requiresLocation: 'square|market|streets',
        tradeEffect: { bell: -1 | (0 as any), parchment: -1 | (0 as any) },
        socialImpact: { RUMORS: -0.1 as any, MORALE: 0.2 },
        ownershipEffect: { bulletin: 'posted_positive_events' },
        requiredMemes: [
            health.sanitation_norms,
            health.waste_handling,
            comm.language.written,
        ]
    },
    {
        tag: HopeActionTag.LIGHTS_FESTIVAL,
        costEnergy: -0.12,
        costTime: 1.3,
        rewardSecondary: {
            COMMUNITY: 0.4,
            TRADITION: 0.3 as any,
            COMFORT: 0.3 as any,
            HOPE: 0.85,
        },
        requiresLocation: 'square|temple|riverbank',
        tradeEffect: { candles: -2 | (0 as any), oil: -1 | (0 as any) },
        requiredMemes: [
            health.sanitation_norms,
            health.waste_handling,
            culture.vigil_ritual,
            cog.timekeeping.basic,
            comm.language.written,
        ],
        socialImpact: { COHESION: 0.4, PEACE: 0.2 as any },
        ownershipEffect: { lanterns: 'released_counted' },
        risk: 0.05
    },
    {
        tag: HopeActionTag.GREEN_PATCH_START,
        costEnergy: -0.1,
        costTime: 1.1,
        rewardSecondary: {
            FOOD: 0.4 as any,
            RESILIENCE: 0.3 as any,
            BELONGING: 0.2,
            HOPE: 0.75,
        },
        requiresLocation: 'unused_lot|commons',
        tradeEffect: { tools: -1 | (0 as any), compost: -1 | (0 as any) },
        socialImpact: { PARTICIPATION: 0.3 as any, OWNERSHIP: 0.2 as any },
        ownershipEffect: { plotGrid: 'staked_and_named' },
        requiredMemes: [
            health.sanitation_norms,
            health.waste_handling,
            tech.tool.use_basic,
            comm.language.written,
        ]
    },
    {
        tag: HopeActionTag.SCOUTS_NEW_HORIZONS,
        costEnergy: -0.12,
        costTime: 1.2,
        rewardSecondary: {
            CURIOSITY: 0.5 as any,
            SECURITY: 0.2,
            INSPIRATION: 0.2 as any,
            HOPE: 0.7,
        },
        requiresLocation: 'outskirts|trail',
        tradeEffect: { rations: -1, rope: -1 | (0 as any) },
        socialImpact: { COURAGE: 0.3 as any, UNITY: 0.1 },
        ownershipEffect: { mapSheets: 'updated' },
        risk: 0.07
    },
    {
        tag: HopeActionTag.SANCTUARY_VIGIL,
        costEnergy: -0.08,
        costTime: 0.9,
        rewardSecondary: {
            FAITH: 0.4 as any,
            COMMUNITY: 0.2,
            PURPOSE: 0.2 as any,
            HOPE: 0.7,
        },
        requiresLocation: 'temple|memorial',
        tradeEffect: { incense: -1 | (0 as any), candles: -1 | (0 as any) },
        needRework: true,
        requiredMemes: [
            culture.vigil_ritual,
            cog.timekeeping.basic,
        ],
        socialImpact: { DIGNITY: 0.3 as any },
        ownershipEffect: { remembranceRoll: 'names_read' }
    },
    {
        tag: HopeActionTag.PUBLIC_GOAL_TRACKER,
        costEnergy: -0.08,
        costTime: 0.8,
        rewardSecondary: {
            HOPE: 0.7,
            CLARITY: 0.4,
            FOCUS: 0.3 as any,
            TRUST: 0.2,
        },
        requiresLocation: 'hall|notice_board',
        tradeEffect: { chalk: -1, board_or_tablet: -1 | (0 as any) },
        socialImpact: { TRANSPARENCY: 0.3 as any, COHESION: 0.2 },
        ownershipEffect: { milestoneBoard: 'targets_posted' },
        lawEffect: { reportingCadence: 'weekly', enforceable: true },
        requiredMemes: [comm.language.written]
    },
    {
        tag: HopeActionTag.REPAIR_BLITZ,
        costEnergy: -0.12,
        costTime: 1.1,
        rewardSecondary: {
            ORDER: 0.3,
            CULTURE: 0.3 as any,
            COMMUNITY: 0.2,
            HOPE: 0.75,
        },
        requiresLocation: 'streets|workyard',
        tradeEffect: { nails: -1 | (0 as any), planks: -1 | (0 as any) },
        socialImpact: { PARTICIPATION: 0.3 as any },
        ownershipEffect: { repairList: 'closed_items_marked' },
        requiredMemes: [
            health.sanitation_norms,
            health.waste_handling,
        ]
    },
    {
        tag: HopeActionTag.STORY_CIRCLE_HEROES,
        costEnergy: -0.06,
        costTime: 0.7,
        rewardSecondary: {
            TRADITION: 0.3 as any,
            COURAGE: 0.2 as any,
            COMMUNITY: 0.2,
            HOPE: 0.65,
        },
        requiresLocation: 'fire_pit|hall',
        tradeEffect: { wood: -1 | (0 as any) },
        socialImpact: { PRIDE: 0.2 as any, COHESION: 0.2 },
        ownershipEffect: { taleLedger: 'stories_logged' },
        requiredMemes: [
            culture.vigil_ritual,
            cog.timekeeping.basic,
            heat.space.hearth,
            comm.language.written,
            record.ledgerkeeping,
        ]
    },
    {
        tag: HopeActionTag.MARKET_STARTER_KITS,
        costEnergy: -0.1,
        costTime: 1.0,
        rewardSecondary: {
            PRODUCTIVITY: 0.4 as any,
            WEALTH: 0.3 as any,
            TRUST: 0.2,
            HOPE: 0.75,
        },
        requiresLocation: 'market|stores',
        tradeEffect: { starter_kit: '-N' as any, tokens: '-N' as any },
        socialImpact: { MOBILITY: 0.2 as any, CONFIDENCE: 0.2 as any },
        ownershipEffect: { stallPermits: 'issued_with_names' },
        lawEffect: { micrograntRule: 'posted', enforceable: true },
        risk: 0.06,
        requiredMemes: [
            record.ledgerkeeping,
            econ.pooling_common_fund,
            econ.deposit_contract,
            comm.language.written,
        ]
    },
    {
        tag: HopeActionTag.HEALERS_ROUND,
        costEnergy: -0.1,
        costTime: 1.0,
        rewardSecondary: {
            SAFETY: 0.3 as any,
            HEALTH: 0.3 as any,
            MORALE: 0.2 as any,
            HOPE: 0.75,
        },
        requiresLocation: 'homes|quarters',
        tradeEffect: { herbs: -1 | (0 as any), bandages: -1 | (0 as any) },
        socialImpact: { TRUST: 0.3, COHESION: 0.2 },
        ownershipEffect: { patientRoll: 'visited_logged' }
    },
    {
        tag: HopeActionTag.HOPE_CHEST_PLEDGE,
        costEnergy: -0.08,
        costTime: 0.9,
        rewardSecondary: {
            HOPE: 0.7,
            RESILIENCE: 0.3 as any,
            COMMUNITY: 0.3,
            TRUST: 0.2,
        },
        requiresLocation: 'hall|temple',
        tradeEffect: {
            chest: -1 | (0 as any),
            ribbons: -1 | (0 as any),
            tokens: '+pool' as any,
        },
        socialImpact: { SOLIDARITY: 0.4 as any },
        ownershipEffect: { pledgeLedger: 'names_and_amounts' },
        lawEffect: { reliefFund: 'charter_posted', enforceable: true },
        requiredMemes: [
            culture.vigil_ritual,
            cog.timekeeping.basic,
            comm.language.written,
            record.ledgerkeeping,
            econ.pooling_common_fund,
            econ.deposit_contract,
        ]
    },
];
