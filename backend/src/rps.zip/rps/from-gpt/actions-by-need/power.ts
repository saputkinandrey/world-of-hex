import { ActionDefinition } from '../action-definition';
import { PowerActionTag } from '../action-tags';
export const PowerActions: ActionDefinition[] = [
    {
        tag: PowerActionTag.FORMALIZE_CHAIN_OF_COMMAND,
        costEnergy: -0.18,
        costTime: 1.6,
        rewardSecondary: {
            POWER: 0.6,
            CONTROL: 0.6,
            STABILITY: 0.4,
            STATUS: 0.2,
        },
        socialImpact: { POWER: 0.6, ORDER: 0.5, CONFUSION: -0.3 },
        lawEffect: { charter: 'chain_of_command_v1', enforceable: true }
    },
    {
        tag: PowerActionTag.APPOINT_OFFICERS,
        costEnergy: -0.2,
        costTime: 1.4,
        risk: 0.12,
        rewardSecondary: {
            POWER: 0.65,
            CONTROL: 0.5,
            LOYALTY: 0.3,
            STATUS: 0.3,
        },
        socialImpact: { POWER: 0.55, FAVOR: 0.4, ENVY: 0.2 },
        lawEffect: { lettersOfOffice: 'issued', enforceable: true },
        ownershipEffect: { accessScope: 'command_rooms', grantAccess: true }
    },
    {
        tag: PowerActionTag.DELEGATE_AUTHORITY,
        costEnergy: -0.12,
        costTime: 0.9,
        rewardSecondary: {
            POWER: 0.55,
            CONTROL: 0.4,
            PRODUCTIVITY: 0.3,
            TRUST: 0.2,
        },
        socialImpact: { POWER: 0.4, RESPONSIVENESS: 0.4 as any },
        lawEffect: {
            warrant: 'delegation_writ',
            enforceable: true,
            scope: 'limited',
        },
        ownershipEffect: {
            grantAccess: true,
            accessScope: 'assets_subset',
            accessLevel: 'DELEGATE',
        }
    },
    {
        tag: PowerActionTag.ISSUE_DECREE,
        costEnergy: -0.1,
        costTime: 0.7,
        risk: 0.15,
        rewardSecondary: {
            POWER: 0.65,
            CONTROL: 0.5,
            LAW: 0.4,
            STABILITY: 0.2,
        },
        socialImpact: { POWER: 0.55, COMPLIANCE: 0.4 as any, RESENTMENT: 0.15 },
        lawEffect: { decreeId: 'dcr#001', enforceable: true },
        tradeEffect: { notice_posts: '+N', heralds_fee: -1 }
    },
    {
        tag: PowerActionTag.CONVENE_PRIVY_COUNCIL,
        costEnergy: -0.15,
        costTime: 1.2,
        rewardSecondary: {
            POWER: 0.6,
            TRUST: 0.3,
            CONTROL: 0.3,
            STABILITY: 0.2,
        },
        requiresLocation: 'council_chamber',
        socialImpact: { POWER: 0.45, COHESION: 0.35, SECRECY: 0.3 as any },
        lawEffect: { minutes: 'sealed', enforceable: true },
        ownershipEffect: { accessScope: 'privy_council', grantAccess: true }
    },
    {
        tag: PowerActionTag.CONTROL_KEY_RESOURCES,
        costEnergy: -0.3,
        costTime: 2.0,
        risk: 0.2,
        rewardSecondary: {
            POWER: 0.8,
            WEALTH: 0.4,
            CONTROL: 0.6,
            SECURITY: 0.3,
        },
        requiresItem: ['guards'],
        socialImpact: { POWER: 0.7, DEPENDENCE: 0.5 as any, ENVY: 0.25 },
        ownershipEffect: { seize: 'granary|armory|well', steward: 'appointed' },
        lawEffect: { seizureOrder: 'filed', enforceable: true }
    },
    {
        tag: PowerActionTag.GRANT_PRIVILEGE,
        costEnergy: -0.1,
        costTime: 0.8,
        rewardSecondary: { POWER: 0.6, LOYALTY: 0.4, STATUS: 0.3, WEALTH: 0.2 },
        socialImpact: { POWER: 0.45, GRATITUDE: 0.45, ENVY: 0.2 },
        lawEffect: {
            charterGrant: 'monopoly|tax_break',
            enforceable: true,
            duration: 'term',
        },
        ownershipEffect: {
            grantAccess: true,
            accessScope: 'market|resource',
            accessLevel: 'LICENSED',
        }
    },
    {
        tag: PowerActionTag.REVOKE_PRIVILEGE,
        costEnergy: -0.12,
        costTime: 0.9,
        risk: 0.2,
        rewardSecondary: { POWER: 0.55, JUSTICE: 0.3, CONTROL: 0.4 },
        socialImpact: { POWER: 0.5, FEAR: 0.2, RESENTMENT: 0.25 },
        lawEffect: { revocationWrit: 'served', enforceable: true },
        ownershipEffect: {
            accessRevoked: true,
            accessScope: 'resource|office',
        }
    },
    {
        tag: PowerActionTag.ESTABLISH_INTELLIGENCE_NETWORK,
        costEnergy: -0.25,
        costTime: 1.8,
        risk: 0.2,
        rewardSecondary: {
            POWER: 0.7,
            CONTROL: 0.5,
            SECURITY: 0.3,
            KNOWLEDGE: 0.3,
        },
        tradeEffect: { stipends: -3, informants: '+N' },
        socialImpact: { POWER: 0.55, FEAR: 0.15, READINESS: 0.3 as any },
        lawEffect: { secrecyWrit: 'issued', enforceable: true }
    },
    {
        tag: PowerActionTag.ENFORCE_TAX_OR_TITHE,
        costEnergy: -0.22,
        costTime: 1.6,
        risk: 0.18,
        rewardSecondary: { POWER: 0.7, WEALTH: 0.5, LAW: 0.4, STABILITY: 0.3 },
        tradeEffect: { collect_silver: '+X', arrears: '-Y' },
        socialImpact: { POWER: 0.55, RESENTMENT: 0.25, FAIRNESS: 0.2 },
        lawEffect: { taxCode: 'tithed_v1', enforceable: true },
        ownershipEffect: { treasury: 'credited' }
    },
    {
        tag: PowerActionTag.APPOINT_JUDGES,
        costEnergy: -0.18,
        costTime: 1.2,
        rewardSecondary: { POWER: 0.6, JUSTICE: 0.5, STABILITY: 0.4 },
        socialImpact: { POWER: 0.45, TRUST: 0.3, FEAR: 0.1 },
        lawEffect: { benchLetters: 'issued', enforceable: true },
        ownershipEffect: { accessScope: 'court_chamber', grantAccess: true }
    },
    {
        tag: PowerActionTag.RAISE_GUARD_OR_RETINUE,
        costEnergy: -0.35,
        costTime: 2.5,
        risk: 0.2,
        rewardSecondary: {
            POWER: 0.8,
            SECURITY: 0.6,
            CONTROL: 0.5,
            STATUS: 0.3,
        },
        requiresItem: ['arms', 'armor'],
        tradeEffect: { hire_cost: '-X', upkeep: '-Y/season' },
        socialImpact: { POWER: 0.7, FEAR: 0.3, LOYALTY: 0.2 },
        lawEffect: { musterRoll: 'guard_registered', enforceable: true },
        ownershipEffect: { accessScope: 'armory|barracks', grantAccess: true }
    },
    {
        tag: PowerActionTag.CALL_MUSTER,
        costEnergy: -0.28,
        costTime: 2.0,
        risk: 0.18,
        rewardSecondary: { POWER: 0.7, SECURITY: 0.5, COMMUNITY: 0.3 },
        requiresLocation: 'mustering_field',
        socialImpact: { POWER: 0.6, READINESS: 0.6 as any, FEAR: 0.15 },
        lawEffect: { generalSummons: 'issued', enforceable: true }
    },
    {
        tag: PowerActionTag.NEGOTIATE_VASSALAGE,
        costEnergy: -0.25,
        costTime: 2.2,
        risk: 0.15,
        rewardSecondary: {
            POWER: 0.8,
            CONTROL: 0.6,
            WEALTH: 0.3,
            STABILITY: 0.4,
        },
        requiresSkill: 'diplomacy',
        socialImpact: { POWER: 0.65, ALLIANCE: 0.5 as any, LOYALTY: 0.3 },
        lawEffect: {
            fealtyCharter: 'signed',
            enforceable: true,
            obligations: 'tribute+levy',
        },
        ownershipEffect: { grantAccess: true, accessScope: 'overlord_rights' }
    },
    {
        tag: PowerActionTag.HOSTAGE_EXCHANGE,
        costEnergy: -0.2,
        costTime: 1.6,
        risk: 0.25,
        rewardSecondary: {
            POWER: 0.6,
            STABILITY: 0.4,
            SECURITY: 0.3,
            TRUST: 0.2,
        },
        socialImpact: { POWER: 0.5, DETERRENCE: 0.5 as any, RESENTMENT: 0.2 },
        lawEffect: {
            hostageTreaty: 'filed',
            enforceable: true,
            duration: 'term',
        },
        ownershipEffect: { custodyRights: 'reciprocal' }
    },
    {
        tag: PowerActionTag.PUNISHMENT_WITH_DUE_PROCESS,
        costEnergy: -0.22,
        costTime: 1.8,
        risk: 0.2,
        rewardSecondary: { POWER: 0.7, JUSTICE: 0.6, STABILITY: 0.5, LAW: 0.5 },
        socialImpact: { POWER: 0.6, FEAR: 0.25, TRUST: 0.25 },
        lawEffect: {
            sentence: 'passed_by_court',
            enforceable: true,
            appeal: 'allowed',
        }
    },
];
