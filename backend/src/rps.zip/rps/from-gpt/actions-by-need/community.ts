import { ActionDefinition } from '../action-definition';
import { CommunityActionTag } from '../action-tags';
import { cog, comm, culture, econ, health, record, tech } from '../../world/memes';
export const CommunityActions: ActionDefinition[] = [
    {
        tag: CommunityActionTag.ORGANIZE_WORK_BEE,
        costEnergy: -0.25,
        costTime: 2.0,
        risk: 0.08,
        rewardSecondary: {
            COMMUNITY: 0.75,
            BELONGING: 0.5,
            STABILITY: 0.3,
            TRUST: 0.3,
        },
        requiresSkill: 'leadership',
        targetType: 'GROUP',
        tradeEffect: { gather_volunteers: '+N', tool_pool: 'shared' },
        socialImpact: { COHESION: 0.6, COMMUNITY: 0.6, VISIBILITY: 0.3 },
        ownershipEffect: { accessScope: 'public_worksite', grantAccess: true },
        lawEffect: { notice: 'work_bee_called', enforceable: false },
        needRework: true,
    },
    {
        tag: CommunityActionTag.BUILD_COMMON_INFRA,
        costEnergy: -0.5,
        costTime: 4.0,
        rewardSecondary: {
            COMMUNITY: 0.95,
            STABILITY: 0.6,
            SECURITY: 0.3,
            WEALTH: 0.2,
        },
        requiresItem: ['wood', 'stone', 'tools'],
        tradeEffect: { spend_wood: -10, spend_stone: -8, labor_hours: -40 },
        socialImpact: { COMMUNITY: 0.75, GRATITUDE: 0.6, LEGACY: 0.4 },
        ownershipEffect: {
            commonAsset: 'well|bridge|road',
            steward: 'council',
        },
        lawEffect: { workPermit: 'approved', enforceable: true }
    },
    {
        tag: CommunityActionTag.MAINTAIN_COMMON_INFRA,
        costEnergy: -0.3,
        costTime: 2.0,
        rewardSecondary: { COMMUNITY: 0.65, STABILITY: 0.5, HYGIENE: 0.3 },
        tradeEffect: { use_tools: -1, repair_kits: -1 },
        socialImpact: { COMMUNITY: 0.5, RELIABILITY: 0.4 },
        ownershipEffect: { assetUptime: 'extended' },
        lawEffect: { maintenanceLog: 'updated', enforceable: true },
        requiredMemes: [
            comm.language.written,
            tech.tool.use_basic,
        ]
    },
    {
        tag: CommunityActionTag.COLLECT_COMMON_FUND,
        costEnergy: -0.15,
        costTime: 1.2,
        rewardSecondary: { COMMUNITY: 0.55, STABILITY: 0.35, TRUST: 0.25 },
        requiresSkill: 'accounting',
        tradeEffect: { contribute_silver: '+X', ledger: 'community_fund' },
        socialImpact: { COMMUNITY: 0.5, FAIRNESS: 0.3, SUSPICION: -0.1 },
        lawEffect: { fundCharter: 'created', enforceable: true },
        requiredMemes: [
            record.ledgerkeeping,
            econ.pooling_common_fund,
        ]
    },
    {
        tag: CommunityActionTag.DISTRIBUTE_COMMON_RATIONS,
        costEnergy: -0.2,
        costTime: 1.5,
        rewardSecondary: {
            COMMUNITY: 0.6,
            BELONGING: 0.35,
            HYGIENE: 0.15,
            STABILITY: 0.3,
        },
        requiresSkill: 'logistics',
        tradeEffect: { grain_out: '-N', seed_out: '-M', note: 'rations' },
        socialImpact: { COMMUNITY: 0.55, GRATITUDE: 0.45, ENVY: 0.1 },
        ownershipEffect: {
            grantAccess: true,
            accessScope: 'granary',
            accessLevel: 'RECIPIENT',
        },
        lawEffect: { rationPolicy: 'v1', enforceable: true }
    },
    {
        tag: CommunityActionTag.HOST_COMMUNITY_FEAST,
        costEnergy: -0.25,
        costTime: 3.0,
        rewardSecondary: {
            COMMUNITY: 0.9,
            BELONGING: 0.6,
            TRADITION: 0.5,
            MOOD: 0.4 as any,
        },
        tradeEffect: { spend_food: -12, spend_drink: -6, music_fee: -2 },
        socialImpact: { COMMUNITY: 0.75, COHESION: 0.6, JOY: 0.5 as any },
        ownershipEffect: { accessScope: 'feast_hall', grantAccess: true },
        lawEffect: { eventPermit: 'feast#ok', enforceable: true }
    },
    {
        tag: CommunityActionTag.HOLD_OPEN_COUNCIL,
        costEnergy: -0.2,
        costTime: 2.0,
        rewardSecondary: { COMMUNITY: 0.7, TRUST: 0.4, LAW: 0.3 },
        requiresLocation: 'council_hall',
        socialImpact: { COMMUNITY: 0.6, ACCESSIBILITY: 0.5, FAIRNESS: 0.4 },
        lawEffect: { docketOpen: 'petitions_heard', enforceable: true },
        requiredMemes: [comm.language.written]
    },
    {
        tag: CommunityActionTag.POST_PUBLIC_NOTICES,
        costEnergy: -0.08,
        costTime: 0.8,
        rewardSecondary: { COMMUNITY: 0.45, STABILITY: 0.25, KNOWLEDGE: 0.2 },
        tradeEffect: { use_parchment: -1, posts: '+N' },
        socialImpact: { COMMUNITY: 0.45, VISIBILITY: 0.4, CLARITY: 0.3 as any },
        lawEffect: { noticeBoard: 'updated', enforceable: true },
        requiredMemes: [comm.language.written]
    },
    {
        tag: CommunityActionTag.ORGANIZE_MUSTER_DRILL,
        costEnergy: -0.35,
        costTime: 2.5,
        risk: 0.12,
        rewardSecondary: { COMMUNITY: 0.8, SECURITY: 0.6, STABILITY: 0.4 },
        requiresItem: ['practice_weapons'],
        socialImpact: { COMMUNITY: 0.6, READINESS: 0.6 as any, PRIDE: 0.3 },
        lawEffect: { militiaRegister: 'updated', enforceable: true }
    },
    {
        tag: CommunityActionTag.MEDIATE_NEIGHBOR_CONFLICTS,
        costEnergy: -0.15,
        costTime: 1.5,
        risk: 0.1,
        rewardSecondary: { COMMUNITY: 0.7, JUSTICE: 0.4, STABILITY: 0.4 },
        socialImpact: { COMMUNITY: 0.55, HARMONY: 0.55, TRUST: 0.35 },
        lawEffect: { mediationRecord: 'filed', enforceable: true }
    },
    {
        tag: CommunityActionTag.ESTABLISH_MUTUAL_AID,
        costEnergy: -0.22,
        costTime: 2.2,
        rewardSecondary: { COMMUNITY: 0.75, STABILITY: 0.45, TRUST: 0.4 },
        tradeEffect: { dues: '+1/household', emergency_fund: '+pool' },
        socialImpact: { COMMUNITY: 0.65, SAFETY_NET: 0.6 as any },
        ownershipEffect: { fundAccessPolicy: 'need_based', grantAccess: true },
        lawEffect: { mutualAidCharter: 'ratified', enforceable: true },
        needRework: true,
    },
    {
        tag: CommunityActionTag.SET_COMMUNITY_NORMS,
        costEnergy: -0.2,
        costTime: 2.0,
        rewardSecondary: { COMMUNITY: 0.65, TRADITION: 0.5, LAW: 0.4 },
        requiresSkill: 'diplomacy',
        socialImpact: { COMMUNITY: 0.55, CONSENSUS: 0.5 as any, RESPECT: 0.25 },
        lawEffect: { normsCodex: 'adopted', enforceable: true }
    },
    {
        tag: CommunityActionTag.RUN_MARKET_DAY,
        costEnergy: -0.28,
        costTime: 3.0,
        rewardSecondary: { COMMUNITY: 0.8, WEALTH: 0.5, TRUST: 0.3 },
        requiresLocation: 'market_square',
        tradeEffect: { stall_fees: '+X', traffic: '+many', barters: '+N' },
        socialImpact: { COMMUNITY: 0.6, VIBRANCY: 0.5 as any, NETWORK: 0.4 },
        ownershipEffect: { accessScope: 'market_stalls', grantAccess: true },
        lawEffect: { marketRules: 'v1', enforceable: true },
        needRework: true,
    },
    {
        tag: CommunityActionTag.CLEAN_PUBLIC_SPACES,
        costEnergy: -0.2,
        costTime: 1.5,
        rewardSecondary: { COMMUNITY: 0.55, HYGIENE: 0.5, STABILITY: 0.2 },
        tradeEffect: { refuse_removed: '+K', lime_used: -1 },
        socialImpact: { COMMUNITY: 0.45, CIVIC_DUTY: 0.45 as any },
        ownershipEffect: { accessScope: 'square|streets', grantAccess: true },
        needRework: true,
        requiredMemes: [
            health.sanitation_norms,
            health.waste_handling,
            tech.tool.use_basic,
        ]
    },
    {
        tag: CommunityActionTag.FORM_WATCH_PATROLS,
        costEnergy: -0.3,
        costTime: 2.2,
        risk: 0.12,
        rewardSecondary: { COMMUNITY: 0.7, SECURITY: 0.6, STABILITY: 0.3 },
        requiresSkill: 'organization',
        socialImpact: { COMMUNITY: 0.55, SAFETY: 0.6, FEAR: -0.1 },
        ownershipEffect: {
            accessScope: 'streets|gates',
            accessLevel: 'PATROL',
            grantAccess: true,
        },
        lawEffect: { patrolRoster: 'created', enforceable: true },
        requiredMemes: [
            culture.vigil_ritual,
            cog.timekeeping.basic,
        ]
    },
    {
        tag: CommunityActionTag.CELEBRATE_COMMUNITY_RITES,
        costEnergy: -0.2,
        costTime: 2.0,
        rewardSecondary: { COMMUNITY: 0.75, TRADITION: 0.6, SPIRIT: 0.4 },
        tradeEffect: { offerings: -3, festival_costs: -2 },
        socialImpact: {
            COMMUNITY: 0.65,
            IDENTITY: 0.55 as any,
            JOY: 0.45 as any,
        },
        lawEffect: { riteCalendar: 'observed', enforceable: false }
    },
];
