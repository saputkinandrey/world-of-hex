import { ActionDefinition } from '../action-definition';
import { HonorActionTag } from '../action-tags';
import { comm, health } from '../../world/memes';
export const HonorActions: ActionDefinition[] = [
    {
        tag: HonorActionTag.KEEP_WORD,
        costEnergy: -0.08,
        costTime: 0.8,
        rewardSecondary: {
            INTEGRITY: 0.6,
            TRUST: 0.5,
            REPUTATION: 0.3,
            STABILITY: 0.2,
            HONOR: 0.75,
        },
        socialImpact: { CREDIBILITY: 0.5, FAIRNESS: 0.2 },
        lawEffect: { oathRecord: 'fulfilled', enforceable: true }
    },
    {
        tag: HonorActionTag.RETURN_FOUND_PROPERTY,
        costEnergy: -0.06,
        costTime: 0.6,
        rewardSecondary: { HONOR: 0.6, INTEGRITY: 0.5, TRUST: 0.3, ORDER: 0.2 },
        tradeEffect: { found_item: 'returned' },
        socialImpact: { COMMUNITY: 0.2, RESPECT: 0.2 },
        lawEffect: { lostAndFoundLedger: 'updated', enforceable: true }
    },
    {
        tag: HonorActionTag.DECLINE_UNFAIR_ADVANTAGE,
        costEnergy: -0.1,
        costTime: 0.5,
        risk: 0.05,
        rewardSecondary: {
            HONOR: 0.7,
            INTEGRITY: 0.6,
            FAIRNESS: 0.5,
            DISCIPLINE: 0.2,
        },
        socialImpact: { RESPECT: 0.3, TRUST: 0.2 },
        lawEffect: { cheatingAttempt: 'refused', enforceable: true }
    },
    {
        tag: HonorActionTag.STAND_WITNESS_TRUTH,
        costEnergy: -0.12,
        costTime: 1.2,
        risk: 0.15,
        rewardSecondary: {
            HONOR: 0.8,
            JUSTICE: 0.6,
            INTEGRITY: 0.4,
            COURAGE: 0.3,
        },
        requiresLocation: 'hall|court_square',
        socialImpact: { CREDIBILITY: 0.5, ORDER: 0.3 },
        lawEffect: { testimony: 'sworn', enforceable: true },
        requiredMemes: [
            health.sanitation_norms,
            health.waste_handling,
            comm.language.written,
        ]
    },
    {
        tag: HonorActionTag.ACCEPT_DUEL_FORMAL,
        costEnergy: -0.22,
        costTime: 1.6,
        risk: 0.35,
        rewardSecondary: {
            HONOR: 0.9,
            COURAGE: 0.6,
            REPUTATION: 0.4,
            FEAR: -0.2,
        },
        requiresSkill: 'dueling|arms',
        requiresLocation: 'duel_ground',
        socialImpact: { RESPECT: 0.4, CONTROVERSY: 0.2 },
        lawEffect: { duelCode: 'observed', enforceable: true }
    },
    {
        tag: HonorActionTag.ISSUE_FORMAL_APOLOGY,
        costEnergy: -0.1,
        costTime: 1.0,
        risk: 0.12,
        rewardSecondary: {
            HONOR: 0.8,
            INTEGRITY: 0.5,
            CLARITY: 0.4,
            COMMUNITY: 0.2,
        },
        requiresLocation: 'hall|square',
        socialImpact: { TRUST: 0.3, RESENTMENT: -0.2 },
        lawEffect: { apologyRecord: 'filed', enforceable: true },
        requiredMemes: [
            health.sanitation_norms,
            health.waste_handling,
            comm.language.written,
        ]
    },
    {
        tag: HonorActionTag.DEFEND_WEAK,
        costEnergy: -0.18,
        costTime: 1.2,
        risk: 0.2,
        rewardSecondary: {
            HONOR: 0.85,
            COURAGE: 0.5,
            JUSTICE: 0.4,
            SECURITY: 0.3,
        },
        socialImpact: { RESPECT: 0.4, FEAR: -0.1 },
        lawEffect: { assaultPrevention: 'intervened', enforceable: true }
    },
    {
        tag: HonorActionTag.UPHOLD_OATH_GUILD,
        costEnergy: -0.12,
        costTime: 1.0,
        rewardSecondary: {
            HONOR: 0.7,
            DISCIPLINE: 0.5,
            ORDER: 0.4,
            TRUST: 0.3,
        },
        socialImpact: { LOYALTY: 0.3, STABILITY: 0.3 },
        lawEffect: { guildOath: 'compliant', enforceable: true }
    },
    {
        tag: HonorActionTag.PAY_DEBT_PROMPTLY,
        costEnergy: -0.06,
        costTime: 0.6,
        rewardSecondary: {
            HONOR: 0.65,
            TRUST: 0.4,
            ORDER: 0.3,
            STABILITY: 0.3,
        },
        tradeEffect: { coin: '-X' as any },
        socialImpact: { REPUTATION: 0.3, NETWORK: 0.1 },
        lawEffect: { debtLedger: 'cleared', enforceable: true }
    },
    {
        tag: HonorActionTag.REFUSE_BRIBE,
        costEnergy: -0.08,
        costTime: 0.5,
        risk: 0.12,
        rewardSecondary: {
            HONOR: 0.75,
            INTEGRITY: 0.6,
            JUSTICE: 0.3,
            COURAGE: 0.2,
        },
        socialImpact: { RESPECT: 0.3, CORRUPTION: -0.3 as any },
        lawEffect: { briberyCase: 'reported|refused', enforceable: true }
    },
    {
        tag: HonorActionTag.PUBLIC_CODE_DECLARATION,
        costEnergy: -0.08,
        costTime: 0.8,
        rewardSecondary: {
            HONOR: 0.6,
            IDENTITY: 0.4,
            CLARITY: 0.4,
            DISCIPLINE: 0.2,
        },
        requiresLocation: 'square|hall',
        socialImpact: { VISIBILITY: 0.3, TRUST: 0.2 },
        lawEffect: { codePosted: 'yes', enforceable: true },
        requiredMemes: [
            health.sanitation_norms,
            health.waste_handling,
            comm.language.written,
        ]
    },
    {
        tag: HonorActionTag.HONOR_FAIR_CONTRACT,
        costEnergy: -0.14,
        costTime: 1.2,
        rewardSecondary: { HONOR: 0.8, FAIRNESS: 0.5, TRUST: 0.4, ORDER: 0.3 },
        tradeEffect: { deliverables: 'provided', payment: 'released' },
        socialImpact: { CREDIBILITY: 0.4, NETWORK: 0.2 },
        lawEffect: { contract: 'fulfilled', enforceable: true }
    },
    {
        tag: HonorActionTag.RETURN_LOOT_TO_RIGHTFUL,
        costEnergy: -0.1,
        costTime: 1.0,
        risk: 0.1,
        rewardSecondary: {
            HONOR: 0.75,
            JUSTICE: 0.5,
            COMMUNITY: 0.3,
            ORDER: 0.2,
        },
        tradeEffect: { loot_out: '-N' as any },
        socialImpact: { RESPECT: 0.3, FEAR: -0.05 },
        lawEffect: { propertyRestitution: 'completed', enforceable: true }
    },
    {
        tag: HonorActionTag.SHARE_CREDIT,
        costEnergy: -0.06,
        costTime: 0.6,
        rewardSecondary: {
            HONOR: 0.7,
            FAIRNESS: 0.5,
            COMMUNITY: 0.3,
            NETWORK: 0.2,
        },
        socialImpact: { TRUST: 0.3, RESENTMENT: -0.1 },
        ownershipEffect: { record: 'co_authorship', rights: 'shared' },
        lawEffect: { creditNote: 'filed', enforceable: true }
    },
    {
        tag: HonorActionTag.ACCEPT_JUST_PENALTY,
        costEnergy: -0.12,
        costTime: 0.8,
        risk: 0.2,
        rewardSecondary: {
            HONOR: 0.8,
            INTEGRITY: 0.6,
            ORDER: 0.4,
            CLARITY: 0.3,
        },
        socialImpact: { TRUST: 0.3, RESENTMENT: -0.1 },
        lawEffect: { sentence: 'accepted', enforceable: true }
    },
    {
        tag: HonorActionTag.MEDIATE_WITHOUT_FAVOR,
        costEnergy: -0.18,
        costTime: 1.6,
        risk: 0.15,
        rewardSecondary: {
            HONOR: 0.85,
            FAIRNESS: 0.6,
            JUSTICE: 0.5,
            STABILITY: 0.4,
        },
        requiresSkill: 'mediation|custom_law',
        socialImpact: { TRUST: 0.4, COMMUNITY: 0.3 },
        lawEffect: { mediationRecord: 'impartial', enforceable: true }
    },
];
