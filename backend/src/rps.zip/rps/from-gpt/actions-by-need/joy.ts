import { ActionDefinition } from '../action-definition';
import { JoyActionTag } from '../action-tags';
import { cog, comm, culture, econ, health, heat, record } from '../../world/memes';
export const JoyActions: ActionDefinition[] = [
    {
        tag: JoyActionTag.PLAY_MUSIC_TOGETHER,
        costEnergy: -0.08,
        costTime: 0.8,
        rewardSecondary: {
            JOY: 0.85,
            MORALE: 0.5,
            COMMUNITY: 0.4,
            CULTURE: 0.3,
        },
        requiresLocation: 'hearth|hall|green',
        requiresItem: ['flute|drum|lyre'],
        socialImpact: { COHESION: 0.3, RHYTHM: 0.2 as any },
        requiredMemes: [
            culture.vigil_ritual,
            cog.timekeeping.basic,
            heat.space.hearth,
            comm.language.written,
        ]
    },
    {
        tag: JoyActionTag.DANCE_RING,
        costEnergy: -0.14,
        costTime: 1.0,
        risk: 0.04,
        rewardSecondary: { JOY: 0.9, MORALE: 0.6, COMMUNITY: 0.4, HEALTH: 0.2 },
        requiresLocation: 'square|green|hall',
        socialImpact: { COHESION: 0.4, STATUS: 0.1 },
        ownershipEffect: { floorSpace: 'cleared' },
        requiredMemes: [
            health.sanitation_norms,
            health.waste_handling,
            comm.language.written,
        ]
    },
    {
        tag: JoyActionTag.JOKE_STORY_SWAP,
        costEnergy: -0.04,
        costTime: 0.6,
        rewardSecondary: {
            SOCIAL: 0.4 as any,
            COMMUNITY: 0.3,
            RESILIENCE: 0.2,
            JOY: 0.75,
        },
        requiresLocation: 'hearth|mess',
        socialImpact: { EMPATHY: 0.3 as any, RUMORS: -0.1 as any },
        requiredMemes: [
            culture.vigil_ritual,
            cog.timekeeping.basic,
            heat.space.hearth,
        ]
    },
    {
        tag: JoyActionTag.SWEET_TREAT_SHARE,
        costEnergy: -0.06,
        costTime: 0.6,
        rewardSecondary: { JOY: 0.8, LOVE: 0.3, COMMUNITY: 0.3, HEALTH: 0.1 },
        tradeEffect: { honey_cakes: '-N' as any, berries: '-N' as any },
        socialImpact: { GRATITUDE: 0.4 as any, TRUST: 0.2 },
        ownershipEffect: { storesLevel: 'reduced_treat' }
    },
    {
        tag: JoyActionTag.PICNIC_OUTING,
        costEnergy: -0.12,
        costTime: 1.2,
        risk: 0.06,
        rewardSecondary: {
            JOY: 0.85,
            HEALTH: 0.3,
            COMMUNITY: 0.3,
            MORALE: 0.3,
        },
        requiresLocation: 'meadow|river_bank|grove',
        tradeEffect: { bread: -1, fruit: -1 | (0 as any) },
        socialImpact: { COHESION: 0.3, STRESS: -0.2 as any }
    },
    {
        tag: JoyActionTag.FIREWORK_SPARK_SHOW,
        costEnergy: -0.1,
        costTime: 0.8,
        risk: 0.08,
        rewardSecondary: {
            JOY: 0.9,
            CULTURE: 0.3,
            COMMUNITY: 0.3,
            MORALE: 0.4,
        },
        requiresLocation: 'square|river_bank',
        tradeEffect: { pitch: -1 | (0 as any), powder: -1 | (0 as any) },
        requiredMemes: [
            health.sanitation_norms,
            health.waste_handling,
            comm.language.written,
        ],
        socialImpact: { AWE: 0.5 as any, PANIC: -0.05 as any },
        lawEffect: { fireSafety: 'strict', enforceable: true }
    },
    {
        tag: JoyActionTag.CHILDREN_GAMES_HOST,
        costEnergy: -0.1,
        costTime: 1.0,
        rewardSecondary: { JOY: 0.85, COMMUNITY: 0.4, LOVE: 0.3, MORALE: 0.3 },
        requiresLocation: 'green|yard',
        socialImpact: { FAMILY: 0.4 as any, HOPE: 0.3 as any },
        ownershipEffect: { playArea: 'chalk_marked' },
        requiredMemes: [
            health.sanitation_norms,
            health.waste_handling,
        ]
    },
    {
        tag: JoyActionTag.HOBBY_CRAFT_HOUR,
        costEnergy: -0.12,
        costTime: 1.2,
        rewardSecondary: {
            JOY: 0.8,
            CULTURE: 0.3,
            PRODUCTIVITY: 0.2,
            IDENTITY: 0.2,
        },
        requiresLocation: 'workbench|loom|carving_table',
        tradeEffect: {
            wood: '-N' as any,
            yarn: '-N' as any,
            dye: -1 | (0 as any),
        },
        socialImpact: { CREATIVITY: 0.4 as any },
        ownershipEffect: { trinkets: '+N' }
    },
    {
        tag: JoyActionTag.PRAISE_WITH_LAUGHTER,
        costEnergy: -0.04,
        costTime: 0.5,
        rewardSecondary: {
            JOY: 0.75,
            MORALE: 0.4,
            SOCIAL: 0.3 as any,
            RESPECT: 0.2,
        },
        requiresLocation: 'hall|yard',
        socialImpact: { COHESION: 0.3, RESENTMENT: -0.05 },
        ownershipEffect: { honorRoll: 'fun_titles_added' },
        requiredMemes: [
            health.sanitation_norms,
            health.waste_handling,
            comm.language.written,
        ]
    },
    {
        tag: JoyActionTag.SURPRISE_GIFT_TOKEN,
        costEnergy: -0.06,
        costTime: 0.6,
        rewardSecondary: { JOY: 0.85, LOVE: 0.4, COMMUNITY: 0.2, TRUST: 0.2 },
        tradeEffect: { token: -1, ribbon: -1 | (0 as any) },
        socialImpact: { GRATITUDE: 0.5 as any, BOND: 0.3 as any },
        ownershipEffect: { recipientGift: '+1' },
        requiredMemes: [
            record.ledgerkeeping,
            econ.pooling_common_fund,
        ]
    },
    {
        tag: JoyActionTag.COMMUNITY_THEATRE,
        costEnergy: -0.2,
        costTime: 1.8,
        rewardSecondary: {
            JOY: 0.9,
            CULTURE: 0.5,
            COMMUNITY: 0.4,
            MORALE: 0.4,
        },
        requiresLocation: 'hall|square',
        tradeEffect: { props: '-N' as any, dye: -1 | (0 as any) },
        socialImpact: { COHESION: 0.4, REPUTATION: 0.2 },
        ownershipEffect: { stageState: 'set' },
        requiredMemes: [
            health.sanitation_norms,
            health.waste_handling,
            comm.language.written,
        ]
    },
    {
        tag: JoyActionTag.FISHING_PLEASURE_TRIP,
        costEnergy: -0.12,
        costTime: 1.4,
        risk: 0.06,
        rewardSecondary: {
            JOY: 0.8,
            HEALTH: 0.2,
            RESILIENCE: 0.2,
            COMMUNITY: 0.2,
        },
        requiresLocation: 'river|lake',
        requiresItem: ['rod|net|hooks'],
        socialImpact: { CALM: 0.3 as any, NETWORK: 0.1 },
        ownershipEffect: { catch: '+small' }
    },
    {
        tag: JoyActionTag.DRESS_UP_FEST_ATTIRE,
        costEnergy: -0.08,
        costTime: 0.8,
        rewardSecondary: {
            JOY: 0.8,
            CULTURE: 0.4,
            STATUS: 0.2,
            COMMUNITY: 0.2,
        },
        tradeEffect: { ribbons: '-N' as any, polish: -1 | (0 as any) },
        socialImpact: { VISIBILITY: 0.3 as any, RESPECT: 0.1 },
        ownershipEffect: { attireState: 'festive' }
    },
    {
        tag: JoyActionTag.GARDEN_BLOSSOM_WALK,
        costEnergy: -0.06,
        costTime: 0.7,
        rewardSecondary: {
            JOY: 0.75,
            HEALTH: 0.2,
            RESILIENCE: 0.2,
            COMMUNITY: 0.1,
        },
        requiresLocation: 'garden|orchard|grove',
        socialImpact: { CALM: 0.3 as any },
        ownershipEffect: { pathUse: 'stroll' }
    },
    {
        tag: JoyActionTag.FRIENDSHIP_TOAST,
        costEnergy: -0.06,
        costTime: 0.6,
        risk: 0.04,
        rewardSecondary: { JOY: 0.85, COMMUNITY: 0.4, LOVE: 0.3, MORALE: 0.3 },
        requiresLocation: 'mess|hearth|square',
        tradeEffect: { ale_or_kvass: -1 | (0 as any) },
        socialImpact: { BOND: 0.4 as any, TRUST: 0.2 },
        requiredMemes: [
            health.sanitation_norms,
            health.waste_handling,
            culture.vigil_ritual,
            cog.timekeeping.basic,
            heat.space.hearth,
            comm.language.written,
        ]
    },
    {
        tag: JoyActionTag.FUN_COMPETITION_FAIR,
        costEnergy: -0.14,
        costTime: 1.2,
        risk: 0.06,
        rewardSecondary: {
            JOY: 0.9,
            COMMUNITY: 0.4,
            MORALE: 0.4,
            CULTURE: 0.2,
        },
        requiresLocation: 'green|yard|square',
        tradeEffect: { ribbons: '-N' as any, prize_token: -1 | (0 as any) },
        socialImpact: { COHESION: 0.4, COMPETITION: 0.2 },
        ownershipEffect: { fieldState: 'game_lines' },
        requiredMemes: [
            health.sanitation_norms,
            health.waste_handling,
            comm.language.written,
        ]
    },
];
