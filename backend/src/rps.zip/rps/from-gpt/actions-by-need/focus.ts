import { ActionDefinition } from '../action-definition';
import { FocusActionTag } from '../action-tags';
import { comm, org, tech } from '../../world/memes';
export const FocusActions: ActionDefinition[] = [
    {
        tag: FocusActionTag.SET_QUIET_HOURS,
        costEnergy: -0.06,
        costTime: 0.8,
        rewardSecondary: { FOCUS: 0.6, ORDER: 0.3, PRODUCTIVITY: 0.2 },
        socialImpact: { FOCUS: 0.5, DISCIPLINE: 0.3, RESPECT: 0.1 },
        lawEffect: { quietHours: 'posted', enforceable: true }
    },
    {
        tag: FocusActionTag.RESERVE_WORK_NOOK,
        costEnergy: -0.04,
        costTime: 0.6,
        rewardSecondary: { FOCUS: 0.5, EFFICIENCY: 0.2, PRIVACY: 0.3 },
        ownershipEffect: {
            accessScope: 'work_nook|desk',
            grantAccess: true,
            duration: 'slot',
        },
        lawEffect: { bookingRoll: 'logged', enforceable: true }
    },
    {
        tag: FocusActionTag.PREP_TOOLS_AND_MATERIALS,
        costEnergy: -0.08,
        costTime: 0.9,
        rewardSecondary: { FOCUS: 0.55, QUALITY: 0.3, EFFICIENCY: 0.25 },
        tradeEffect: { tools_checked: '+1', materials_sorted: '+1' },
        socialImpact: { FOCUS: 0.45, ORDER: 0.35 },
        ownershipEffect: { kitState: 'staged' },
        requiredMemes: [
            comm.language.written,
            tech.tool.use_basic,
        ]
    },
    {
        tag: FocusActionTag.SINGLE_TASK_SPRINT,
        costEnergy: -0.16,
        costTime: 1.2,
        rewardSecondary: { FOCUS: 0.7, PRODUCTIVITY: 0.5, QUALITY: 0.3 },
        socialImpact: { FOCUS: 0.6, DISCIPLINE: 0.4 },
        lawEffect: { taskLock: 'no_interrupts', enforceable: true }
    },
    {
        tag: FocusActionTag.BATCH_SIMILAR_TASKS,
        costEnergy: -0.14,
        costTime: 1.2,
        rewardSecondary: { FOCUS: 0.6, EFFICIENCY: 0.5, PRODUCTIVITY: 0.4 },
        socialImpact: { FOCUS: 0.5, ORDER: 0.3 },
        lawEffect: { queuePolicy: 'batched', enforceable: true }
    },
    {
        tag: FocusActionTag.USE_CHECKLIST,
        costEnergy: -0.06,
        costTime: 0.6,
        rewardSecondary: { FOCUS: 0.5, QUALITY: 0.35, INTEGRITY: 0.2 },
        tradeEffect: { parchment: -1, ink: -1 },
        socialImpact: { FOCUS: 0.45, CLARITY: 0.35, FAIRNESS: 0.1 },
        ownershipEffect: { checklist: 'created', archive: 'yes' },
        requiredMemes: [comm.language.written]
    },
    {
        tag: FocusActionTag.TIMEBOX_WITH_TIMER,
        costEnergy: -0.08,
        costTime: 0.9,
        rewardSecondary: { FOCUS: 0.6, DISCIPLINE: 0.4, EFFICIENCY: 0.3 },
        requiresItem: ['sand_timer|bell'],
        socialImpact: { FOCUS: 0.5, ORDER: 0.3 },
        lawEffect: { bellRule: 'signal_breaks', enforceable: true }
    },
    {
        tag: FocusActionTag.BLOCK_DISTRACTIONS,
        costEnergy: -0.1,
        costTime: 0.8,
        rewardSecondary: { FOCUS: 0.65, PRIVACY: 0.4, QUALITY: 0.2 },
        tradeEffect: { effect: 'screens|curtains: -1 as any' },
        socialImpact: { FOCUS: 0.55, RESPECT: 0.2 },
        ownershipEffect: { accessScope: 'door|curtain', accessLevel: 'CLOSED' },
        lawEffect: { noVisitorsSign: 'posted', enforceable: true }
    },
    {
        tag: FocusActionTag.FOCUS_BREATH_DRILL,
        costEnergy: -0.03,
        costTime: 0.4,
        rewardSecondary: { FOCUS: 0.45, MOOD: 0.2, STRESS: -0.2 as any },
        requiresLocation: 'quiet_spot',
        socialImpact: { FOCUS: 0.35, CALM: 0.4 as any }
    },
    {
        tag: FocusActionTag.POSTURE_AND_LIGHTING,
        costEnergy: -0.04,
        costTime: 0.5,
        rewardSecondary: { FOCUS: 0.45, HEALTH: 0.2, QUALITY: 0.2 },
        tradeEffect: { lamp_oil: -1 as any },
        needRework: true,
        socialImpact: { FOCUS: 0.35, DILIGENCE: 0.2 as any },
        ownershipEffect: { workspaceState: 'ergonomic' }
    },
    {
        tag: FocusActionTag.MICRO_BREAK_PROTOCOL,
        costEnergy: -0.05,
        costTime: 0.6,
        rewardSecondary: { FOCUS: 0.5, REST: 0.2, RESILIENCE: 0.2 },
        socialImpact: { FOCUS: 0.45, BURNOUT: -0.2 as any },
        lawEffect: { breakIntervals: 'posted', enforceable: true }
    },
    {
        tag: FocusActionTag.CAFFEINATE_OR_TEA,
        costEnergy: -0.02,
        costTime: 0.4,
        risk: 0.06,
        rewardSecondary: { FOCUS: 0.45, ENERGY: 0.3 as any, MOOD: 0.15 },
        tradeEffect: { tea_leaves: -1 | (0 as any) },
        socialImpact: { FOCUS: 0.3, HOSPITALITY: 0.1 as any }
    },
    {
        tag: FocusActionTag.MORNING_PLANNING_RITUAL,
        costEnergy: -0.08,
        costTime: 0.8,
        rewardSecondary: { FOCUS: 0.6, CLARITY: 0.5, PURPOSE: 0.3 },
        tradeEffect: { parchment: -1, ink: -1 },
        socialImpact: { FOCUS: 0.55, ORDER: 0.4, MORALE: 0.2 },
        ownershipEffect: { planSheet: 'created' },
        requiredMemes: [comm.language.written]
    },
    {
        tag: FocusActionTag.END_OF_DAY_REVIEW,
        costEnergy: -0.08,
        costTime: 0.8,
        rewardSecondary: { FOCUS: 0.55, CLARITY: 0.5, QUALITY: 0.3 },
        socialImpact: { FOCUS: 0.5, INTEGRITY: 0.3, DISCIPLINE: 0.3 },
        ownershipEffect: { logbook: 'updated' }
    },
    {
        tag: FocusActionTag.ASSIGN_TASK_BUDDIES,
        costEnergy: -0.12,
        costTime: 1.0,
        rewardSecondary: {
            FOCUS: 0.6,
            ACCOUNTABILITY: 0.5 as any,
            EFFICIENCY: 0.3,
        },
        socialImpact: { FOCUS: 0.55, TRUST: 0.3, NETWORK: 0.2 },
        lawEffect: { buddyRoster: 'posted', enforceable: true },
        ownershipEffect: { accessScope: 'task_board', grantAccess: true },
        requiredMemes: [
            comm.language.written,
            org.duty_roster,
        ]
    },
    {
        tag: FocusActionTag.QUIET_ZONE_ENFORCEMENT,
        costEnergy: -0.14,
        costTime: 1.0,
        risk: 0.1,
        rewardSecondary: { FOCUS: 0.65, ORDER: 0.4, FAIRNESS: 0.2 },
        socialImpact: { FOCUS: 0.6, RESENTMENT: 0.1, RESPECT: 0.2 },
        lawEffect: {
            silenceCode: 'active',
            penalties: 'warning|fine',
            enforceable: true,
        }
    },
];
