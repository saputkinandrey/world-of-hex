import { ActionDefinition } from '../action-definition';
import { FamilyActionTag } from '../action-tags';
import { cog, comm, culture, tech } from '../../world/memes';
export const FamilyActions: ActionDefinition[] = [
    {
        tag: FamilyActionTag.PROVIDE_FOOD_TO_FAMILY,
        costEnergy: -0.15,
        costTime: 1.0,
        rewardSecondary: {
            FAMILY: 0.65,
            BELONGING: 0.4,
            STABILITY: 0.3,
            AFFECTION: 0.3,
        },
        tradeEffect: { transfer_food: -4, pantry_stock: '+4' },
        socialImpact: { FAMILY: 0.6, GRATITUDE: 0.4, TRUST: 0.3 },
        ownershipEffect: { householdPantry: 'replenished' }
    },
    {
        tag: FamilyActionTag.CARE_FOR_CHILD,
        costEnergy: -0.25,
        costTime: 2.0,
        rewardSecondary: {
            FAMILY: 0.8,
            AFFECTION: 0.5,
            HEALTH: 0.3,
            STABILITY: 0.3,
        },
        socialImpact: { FAMILY: 0.6, ATTACHMENT: 0.5 as any, TRUST: 0.3 },
        ownershipEffect: { accessScope: 'home_nursery', grantAccess: true }
    },
    {
        tag: FamilyActionTag.TEACH_CHILD_SKILL,
        costEnergy: -0.2,
        costTime: 2.0,
        rewardSecondary: {
            FAMILY: 0.7,
            MASTERY: 0.4,
            KNOWLEDGE: 0.4,
            TRADITION: 0.3,
        },
        socialImpact: { FAMILY: 0.5, PRIDE: 0.4 as any },
        lawEffect: { apprenticeshipNote: 'family_line', enforceable: false }
    },
    {
        tag: FamilyActionTag.CARE_FOR_ELDER,
        costEnergy: -0.3,
        costTime: 2.5,
        rewardSecondary: {
            FAMILY: 0.85,
            RESPECT: 0.4,
            HEALTH: 0.4,
            TRADITION: 0.3,
        },
        tradeEffect: { use_herbs: -1, time_off_work: '-1' },
        socialImpact: { FAMILY: 0.65, GRATITUDE: 0.5, REVERENCE: 0.3 },
        ownershipEffect: { accessScope: 'elder_quarters', grantAccess: true }
    },
    {
        tag: FamilyActionTag.REPAIR_FAMILY_HOME,
        costEnergy: -0.35,
        costTime: 3.0,
        rewardSecondary: {
            FAMILY: 0.8,
            STABILITY: 0.6,
            SECURITY: 0.4,
            COMFORT: 0.4,
        },
        tradeEffect: { spend_wood: -6, spend_tools: -1 },
        socialImpact: { FAMILY: 0.5, RELIEF: 0.4 as any },
        ownershipEffect: { homeIntegrity: 'improved', accessScope: 'house' },
        requiredMemes: [
            comm.language.written,
            tech.tool.use_basic,
        ]
    },
    {
        tag: FamilyActionTag.GUARD_FAMILY_HOME,
        costEnergy: -0.25,
        costTime: 2.0,
        risk: 0.12,
        rewardSecondary: { FAMILY: 0.65, SECURITY: 0.5, STABILITY: 0.3 },
        socialImpact: { FAMILY: 0.45, SAFETY: 0.45 },
        ownershipEffect: { accessScope: 'home_perimeter', grantAccess: true },
        lawEffect: { curfewWatch: 'home_guard', enforceable: true },
        requiredMemes: [
            culture.vigil_ritual,
            cog.timekeeping.basic,
        ]
    },
    {
        tag: FamilyActionTag.MEDIATE_FAMILY_CONFLICT,
        costEnergy: -0.18,
        costTime: 1.5,
        risk: 0.1,
        rewardSecondary: {
            FAMILY: 0.75,
            STABILITY: 0.5,
            COMMUNITY: 0.4,
            JUSTICE: 0.3,
        },
        socialImpact: { FAMILY: 0.6, HARMONY: 0.6, TRUST: 0.3 },
        lawEffect: { mediationRecord: 'family_pact', enforceable: true }
    },
    {
        tag: FamilyActionTag.SAVE_FOR_DOWRY,
        costEnergy: -0.1,
        costTime: 3.0,
        rewardSecondary: {
            FAMILY: 0.7,
            WEALTH: 0.5,
            STABILITY: 0.4,
            TRADITION: 0.4,
        },
        tradeEffect: { reserve_silver: '+8', lockbox: 'dowry' },
        socialImpact: { FAMILY: 0.5, STATUS: 0.3, EXPECTATION: 0.2 as any },
        ownershipEffect: { earmarkedFunds: 'dowry' },
        lawEffect: { dowryLedger: 'started', enforceable: true }
    },
    {
        tag: FamilyActionTag.ARRANGE_MARRIAGE_MEETING,
        costEnergy: -0.15,
        costTime: 1.8,
        risk: 0.15,
        rewardSecondary: {
            FAMILY: 0.65,
            COMMUNITY: 0.4,
            TRADITION: 0.4,
            STATUS: 0.2,
        },
        socialImpact: { FAMILY: 0.55, ALLIANCE: 0.4 as any, RESPECT: 0.2 },
        lawEffect: { betrothalTalks: 'opened', enforceable: false }
    },
    {
        tag: FamilyActionTag.HOST_FAMILY_GATHERING,
        costEnergy: -0.2,
        costTime: 2.5,
        rewardSecondary: {
            FAMILY: 0.75,
            BELONGING: 0.5,
            TRADITION: 0.4,
            COMMUNITY: 0.4,
        },
        tradeEffect: { spend_food: -8, spend_drink: -4 },
        socialImpact: { FAMILY: 0.6, COHESION: 0.5, JOY: 0.4 as any },
        ownershipEffect: { accessScope: 'home_hall', grantAccess: true }
    },
    {
        tag: FamilyActionTag.HONOR_ANCESTORS_FAMILY,
        costEnergy: -0.1,
        costTime: 1.2,
        rewardSecondary: {
            FAMILY: 0.7,
            TRADITION: 0.5,
            SPIRIT: 0.4,
            IDENTITY: 0.3 as any,
        },
        socialImpact: { FAMILY: 0.6, REVERENCE: 0.45, UNITY: 0.3 as any },
        lawEffect: { ritual: 'family_ancestral_rite', enforceable: false }
    },
    {
        tag: FamilyActionTag.ALLOCATE_INHERITANCE,
        costEnergy: -0.2,
        costTime: 1.8,
        risk: 0.2,
        rewardSecondary: { FAMILY: 0.7, STABILITY: 0.5, JUSTICE: 0.4 },
        socialImpact: { FAMILY: 0.5, FAIRNESS: 0.5, RESENTMENT: -0.2 },
        ownershipEffect: { transferTitles: 'executed', parcels: 'distributed' },
        lawEffect: { willRead: 'completed', enforceable: true }
    },
    {
        tag: FamilyActionTag.BUILD_EXTENSION_FOR_FAMILY,
        costEnergy: -0.45,
        costTime: 3.5,
        rewardSecondary: {
            FAMILY: 0.85,
            STABILITY: 0.6,
            COMFORT: 0.5,
            SECURITY: 0.3,
        },
        tradeEffect: { spend_wood: -10, spend_stone: -6, hire_labor: -2 },
        socialImpact: { FAMILY: 0.55, GRATITUDE: 0.5, PRIDE: 0.3 },
        ownershipEffect: { homeCapacity: '+2_rooms', accessScope: 'new_wing' },
        lawEffect: { buildingPermit: 'granted', enforceable: true }
    },
    {
        tag: FamilyActionTag.SHARE_TOOLS_WITH_KIN,
        costEnergy: -0.08,
        costTime: 0.6,
        rewardSecondary: { FAMILY: 0.55, COMMUNITY: 0.3, WEALTH: 0.2 },
        tradeEffect: { loan_tools: 'plow|hammer', due_back: 'harvest_end' },
        socialImpact: { FAMILY: 0.45, TRUST: 0.35, RECIPROCITY: 0.3 },
        ownershipEffect: { sharedUse: true, itemOwner: 'lender' },
        lawEffect: { loanNote: 'family_tools', enforceable: true },
        requiredMemes: [
            comm.language.written,
            tech.tool.use_basic,
        ]
    },
    {
        tag: FamilyActionTag.ESCORT_FAMILY_MEMBER,
        costEnergy: -0.2,
        costTime: 1.8,
        risk: 0.12,
        rewardSecondary: { FAMILY: 0.6, SECURITY: 0.4, AFFECTION: 0.3 },
        socialImpact: { FAMILY: 0.45, SAFETY: 0.4, CARE: 0.3 },
        ownershipEffect: { accessScope: 'route_pass', grantAccess: true }
    },
    {
        tag: FamilyActionTag.FOSTER_OR_ADOPT_CHILD,
        costEnergy: -0.35,
        costTime: 3.0,
        risk: 0.15,
        rewardSecondary: {
            FAMILY: 0.95,
            COMMUNITY: 0.5,
            JUSTICE: 0.3,
            TRADITION: 0.3,
        },
        socialImpact: { FAMILY: 0.75, AFFECTION: 0.6, REPUTATION: 0.4 },
        ownershipEffect: { guardianship: 'established' },
        lawEffect: { adoptionRoll: 'approved_by_council', enforceable: true }
    },
];
