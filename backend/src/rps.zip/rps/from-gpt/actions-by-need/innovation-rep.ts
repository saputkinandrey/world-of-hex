import { ActionDefinition } from '../action-definition';
import { InnovationRepActionTag } from '../action-tags';
import { comm, econ, fire, health, heat, org, record } from '../../world/memes';
export const InnovationRepActions: ActionDefinition[] = [
    {
        tag: InnovationRepActionTag.PROTOTYPE_BENCH_SETUP,
        costEnergy: -0.18,
        costTime: 1.6,
        rewardSecondary: {
            INNOVATION_REP: 0.8,
            KNOWLEDGE: 0.5,
            PRODUCTIVITY: 0.3,
            STATUS: 0.2,
        },
        requiresLocation: 'workbench|forge|loom',
        tradeEffect: {
            spare_parts: '-N' as any,
            charcoal: '-1 | 0' as any,
            oil: '-1 | 0' as any,
        },
        socialImpact: { REPUTATION: 0.3, NETWORK: 0.2 },
        ownershipEffect: {
            benchState: 'prototype_ready',
            accessScope: 'inventor',
        },
        requiredMemes: [
            heat.industrial,
            fire.control,
        ]
    },
    {
        tag: InnovationRepActionTag.CONTROLLED_TRIAL_RUN,
        costEnergy: -0.16,
        costTime: 1.2,
        risk: 0.12,
        rewardSecondary: {
            INNOVATION_REP: 0.75,
            CLARITY: 0.4,
            QUALITY: 0.3,
            KNOWLEDGE: 0.4,
        },
        requiresLocation: 'yard|field|mill',
        socialImpact: { TRUST: 0.2, REPUTATION: 0.2 },
        ownershipEffect: { trialReport: 'logged' },
        lawEffect: { safetyRule: 'observed', enforceable: true },
        requiredMemes: [
            health.sanitation_norms,
            health.waste_handling,
        ]
    },
    {
        tag: InnovationRepActionTag.GUILD_COLLOQUIUM,
        costEnergy: -0.14,
        costTime: 1.4,
        rewardSecondary: {
            INNOVATION_REP: 0.8,
            NETWORK: 0.5,
            KNOWLEDGE: 0.5,
            REPUTATION: 0.3,
        },
        requiresLocation: 'guild_hall|hall',
        socialImpact: { STATUS: 0.2, COMMUNITY: 0.2 },
        ownershipEffect: { minutes: 'posted' },
        requiredMemes: [
            comm.language.written,
            org.workshop_practice,
        ]
    },
    {
        tag: InnovationRepActionTag.FIELD_DEMONSTRATION,
        costEnergy: -0.18,
        costTime: 1.6,
        risk: 0.1,
        rewardSecondary: {
            INNOVATION_REP: 0.85,
            REPUTATION: 0.5,
            TRUST: 0.3,
            WEALTH: 0.2,
        },
        requiresLocation: 'square|fields|quarry',
        socialImpact: { VISIBILITY: 0.4 as any, COMMUNITY: 0.2 },
        ownershipEffect: { ordersIntent: '+prospects' },
        requiredMemes: [
            health.sanitation_norms,
            health.waste_handling,
            comm.language.written,
        ]
    },
    {
        tag: InnovationRepActionTag.IMPROVEMENT_KATA,
        costEnergy: -0.12,
        costTime: 1.0,
        rewardSecondary: {
            INNOVATION_REP: 0.75,
            EFFICIENCY: 0.4,
            PRODUCTIVITY: 0.3,
            QUALITY: 0.3,
        },
        requiresLocation: 'workbench|loom|forge',
        socialImpact: { DISCIPLINE: 0.3, REPUTATION: 0.2 },
        ownershipEffect: { kaizenLog: 'updated' },
        requiredMemes: [
            heat.industrial,
            fire.control,
        ]
    },
    {
        tag: InnovationRepActionTag.SUGGESTION_CHEST,
        costEnergy: -0.08,
        costTime: 0.8,
        rewardSecondary: {
            INNOVATION_REP: 0.65,
            NETWORK: 0.3,
            TRUST: 0.2,
            KNOWLEDGE: 0.2,
        },
        requiresLocation: 'hall|workyard',
        tradeEffect: { chest: -1 | (0 as any), paper_slips: '-N' as any },
        socialImpact: { PARTICIPATION: 0.3 as any, COMMUNITY: 0.2 },
        ownershipEffect: { ideaInbox: 'active' },
        requiredMemes: [comm.language.written]
    },
    {
        tag: InnovationRepActionTag.INNOVATION_BOUNTY,
        costEnergy: -0.1,
        costTime: 1.0,
        rewardSecondary: {
            INNOVATION_REP: 0.8,
            NETWORK: 0.3,
            WEALTH: 0.3,
            REPUTATION: 0.3,
        },
        tradeEffect: { prize_fund: -1 as any },
        socialImpact: { COMPETITION: 0.3, MOTIVATION: 0.3 as any },
        lawEffect: { bountyRules: 'posted', enforceable: true },
        ownershipEffect: { submissions: '+N' }
    },
    {
        tag: InnovationRepActionTag.CROSS_POLLINATION_VISIT,
        costEnergy: -0.16,
        costTime: 1.6,
        rewardSecondary: {
            INNOVATION_REP: 0.8,
            KNOWLEDGE: 0.5,
            NETWORK: 0.5,
            CULTURE: 0.2,
        },
        tradeEffect: { travel_supplies: -1 },
        requiresLocation: 'neighbor_guild|monastery|other_hamlet',
        socialImpact: { RESPECT: 0.2, STATUS: 0.2 },
        ownershipEffect: { notes: 'exchange_collected' }
    },
    {
        tag: InnovationRepActionTag.POSTMORTEM_SCROLL,
        costEnergy: -0.12,
        costTime: 1.2,
        rewardSecondary: {
            INNOVATION_REP: 0.7,
            CLARITY: 0.5,
            TRUST: 0.2,
            KNOWLEDGE: 0.4,
        },
        tradeEffect: { parchment: -1, ink: -1 },
        socialImpact: { TRANSPARENCY: 0.3 as any, INTEGRITY: 0.2 },
        ownershipEffect: { archiveState: 'failure_lessons_indexed' },
        requiredMemes: [comm.language.written]
    },
    {
        tag: InnovationRepActionTag.SANDBOX_EXPERIMENT_ZONE,
        costEnergy: -0.18,
        costTime: 1.6,
        risk: 0.06,
        rewardSecondary: {
            INNOVATION_REP: 0.8,
            QUALITY: 0.3,
            EFFICIENCY: 0.3,
            PRODUCTIVITY: 0.2,
        },
        requiresLocation: 'yard|annex',
        lawEffect: { safetyPerimeter: 'roped', enforceable: true },
        ownershipEffect: { accessScope: 'sandbox', grantAccess: true },
        requiredMemes: [
            health.sanitation_norms,
            health.waste_handling,
        ]
    },
    {
        tag: InnovationRepActionTag.STANDARDIZE_SUCCESS,
        costEnergy: -0.16,
        costTime: 1.4,
        rewardSecondary: {
            INNOVATION_REP: 0.8,
            QUALITY: 0.4,
            EFFICIENCY: 0.4,
            TRUST: 0.2,
        },
        requiresLocation: 'workbench|guild_hall',
        socialImpact: { ORDER: 0.3, RESPECT: 0.2 },
        lawEffect: { standardRoll: 'ratified', enforceable: true },
        ownershipEffect: { SOP: 'issued' },
        requiredMemes: [
            comm.language.written,
            org.workshop_practice,
        ]
    },
    {
        tag: InnovationRepActionTag.SALVAGE_TO_TOOL_PROGRAM,
        costEnergy: -0.2,
        costTime: 1.8,
        rewardSecondary: {
            INNOVATION_REP: 0.85,
            WEALTH: 0.3,
            PRODUCTIVITY: 0.3,
            REPUTATION: 0.2,
        },
        tradeEffect: { scrap: '-convert', fixtures: '+N' },
        socialImpact: { INGENUITY: 0.4 as any, COMMUNITY: 0.2 },
        ownershipEffect: { toolLibrary: 'expanded' }
    },
    {
        tag: InnovationRepActionTag.OPEN_WORKSHOP_DAY,
        costEnergy: -0.18,
        costTime: 1.6,
        risk: 0.06,
        rewardSecondary: {
            INNOVATION_REP: 0.85,
            NETWORK: 0.5,
            REPUTATION: 0.4,
            TRUST: 0.3,
        },
        requiresLocation: 'workshop|forge|loom',
        socialImpact: { COMMUNITY: 0.3, RESPECT: 0.3 },
        ownershipEffect: { accessScope: 'tour', grantAccess: true },
        lawEffect: { safetyRule: 'visitors_brief', enforceable: true },
        requiredMemes: [
            heat.industrial,
            fire.control,
            comm.language.written,
            org.workshop_practice,
        ]
    },
    {
        tag: InnovationRepActionTag.PATENT_SEAL_REGISTRY,
        costEnergy: -0.14,
        costTime: 1.2,
        rewardSecondary: {
            INNOVATION_REP: 0.8,
            REPUTATION: 0.5,
            WEALTH: 0.3,
            TRUST: 0.2,
        },
        tradeEffect: { fee: -1 as any, wax: -1, parchment: -1 },
        requiresLocation: 'hall|chancery|guild_hall',
        socialImpact: { STATUS: 0.3, RESPECT: 0.3 },
        lawEffect: { patentSeal: 'issued', enforceable: true },
        ownershipEffect: { rights: 'exclusive_craft_term' },
        requiredMemes: [
            comm.language.written,
            record.ledgerkeeping,
            econ.pooling_common_fund,
            org.workshop_practice,
        ]
    },
    {
        tag: InnovationRepActionTag.APPRENTICE_INNOVATOR_TRACK,
        costEnergy: -0.16,
        costTime: 1.6,
        rewardSecondary: {
            INNOVATION_REP: 0.8,
            KNOWLEDGE: 0.5,
            NETWORK: 0.3,
            REPUTATION: 0.3,
        },
        requiresLocation: 'guild_hall|workshop',
        socialImpact: { MASTERY: 0.4 as any, COMMUNITY: 0.2 },
        ownershipEffect: { curriculum: 'innovation_track' },
        requiredMemes: [
            comm.language.written,
            org.workshop_practice,
        ]
    },
    {
        tag: InnovationRepActionTag.RISK_SHARE_CHARTER,
        costEnergy: -0.12,
        costTime: 1.0,
        risk: 0.08,
        rewardSecondary: {
            INNOVATION_REP: 0.75,
            TRUST: 0.4,
            NETWORK: 0.3,
            WEALTH: 0.2,
        },
        requiresLocation: 'hall|council',
        socialImpact: { FAIRNESS: 0.3, COURAGE: 0.2 },
        lawEffect: { riskCharter: 'sealed', enforceable: true },
        ownershipEffect: { profitShare: 'defined' },
        requiredMemes: [comm.language.written]
    },
];
