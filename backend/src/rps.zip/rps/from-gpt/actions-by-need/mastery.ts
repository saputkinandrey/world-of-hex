import { ActionDefinition } from '../action-definition';
import { ActionTags, MasteryActionTag } from '../action-tags';
import { comm, health, org, record, tech } from '../../world/memes';
export const MasteryActions: ActionDefinition[] = [
    {
        tag: MasteryActionTag.PRACTICE_DRILLS,
        costEnergy: -0.25,
        costTime: 1.2,
        rewardSecondary: { HEALTH: 0.1, DISCIPLINE: 0.4 as any, MASTERY: 0.5 },
        requiresLocation: 'training_yard|workbench',
        socialImpact: { RESPECT: 0.1, CONSISTENCY: 0.4 as any },
        lawEffect: { trainingPermit: 'not_required', enforceable: false },
        requiredMemes: [
            health.sanitation_norms,
            health.waste_handling,
        ]
    },
    {
        tag: MasteryActionTag.STUDY_TREATISE,
        costEnergy: -0.18,
        costTime: 1.5,
        rewardSecondary: { KNOWLEDGE: 0.6, MASTERY: 0.4 },
        requiresItem: ['treatise|scroll'],
        tradeEffect: { study_wear: '-minor' },
        socialImpact: { SCHOLARLY: 0.4 as any },
        ownershipEffect: { accessScope: 'library', grantAccess: true }
    },
    {
        tag: MasteryActionTag.APPRENTICE_UNDER_MASTER,
        costEnergy: -0.35,
        costTime: 3.0,
        rewardSecondary: {
            MASTERY: 0.8,
            KNOWLEDGE: 0.6,
            BELONGING: 0.3,
            STATUS: 0.2,
        },
        socialImpact: { RESPECT: 0.2, NETWORK: 0.3, HUMILITY: 0.3 as any },
        lawEffect: { apprenticeshipContract: 'signed', enforceable: true },
        ownershipEffect: { accessScope: 'master_workshop', grantAccess: true },
        tradeEffect: { stipend: '-1/day', tuition: '-1/season' }
    },
    {
        tag: MasteryActionTag.COMPLETE_APPRENTICE_TASK,
        costEnergy: -0.3,
        costTime: 2.0,
        risk: 0.1,
        rewardSecondary: { MASTERY: 0.6, REPUTATION: 0.2 },
        socialImpact: { RELIABILITY: 0.4 as any, TRUST: 0.2 },
        lawEffect: { taskRecord: 'guild_log', enforceable: true },
        tradeEffect: { materials_used: -2, payment: '+1' }
    },
    {
        tag: ActionTags.MENTOR_JUNIOR,
        costEnergy: -0.25,
        costTime: 2.0,
        rewardSecondary: {
            MASTERY: 0.65,
            COMMUNITY: 0.3,
            KNOWLEDGE: 0.4,
            STATUS: 0.2,
        },
        socialImpact: { RESPECT: 0.3, LOYALTY: 0.2, TEACHING_REP: 0.4 as any },
        lawEffect: { mentorRegistry: 'updated', enforceable: true }
    },
    {
        tag: MasteryActionTag.BUILD_TRAINING_RIG,
        costEnergy: -0.4,
        costTime: 3.0,
        rewardSecondary: { PRODUCTIVITY: 0.3, MASTERY: 0.5 },
        requiresItem: ['wood', 'rope', 'tools'],
        tradeEffect: { spend_wood: -5, spend_rope: -2, spend_tools: -1 },
        ownershipEffect: { trainingFacility: 'built', accessScope: 'yard' },
        lawEffect: { buildingPermit: 'granted', enforceable: true },
        requiredMemes: [
            comm.language.written,
            tech.tool.use_basic,
        ]
    },
    {
        tag: MasteryActionTag.ANALYZE_FAILURES,
        costEnergy: -0.15,
        costTime: 1.2,
        rewardSecondary: { MASTERY: 0.55, KNOWLEDGE: 0.5, STABILITY: 0.2 },
        socialImpact: { HUMILITY: 0.3 as any, IMPROVEMENT: 0.4 as any },
        lawEffect: { logPostmortem: 'kept', enforceable: false }
    },
    {
        tag: MasteryActionTag.FIELD_TEST_TECHNIQUE,
        costEnergy: -0.35,
        costTime: 1.8,
        risk: 0.25,
        rewardSecondary: { MASTERY: 0.7, REPUTATION: 0.2 },
        socialImpact: { COURAGE: 0.3, INNOVATION_REP: 0.3 as any },
        lawEffect: { testPermit: 'required', enforceable: true },
        tradeEffect: { consumables_used: -1 }
    },
    {
        tag: MasteryActionTag.MASTER_CLASS_DEMO,
        costEnergy: -0.2,
        costTime: 1.5,
        rewardSecondary: {
            MASTERY: 0.75,
            STATUS: 0.3,
            COMMUNITY: 0.3,
            KNOWLEDGE: 0.3,
        },
        requiresLocation: 'guild_hall',
        socialImpact: { RESPECT: 0.5, FAME: 0.4, INFLUENCE: 0.3 as any },
        lawEffect: { eventPermit: 'demo_ok', enforceable: true },
        tradeEffect: { ticket_donations: '+2' },
        requiredMemes: [
            comm.language.written,
            org.workshop_practice,
        ]
    },
    {
        tag: MasteryActionTag.GUILD_EXAM_ATTEMPT,
        costEnergy: -0.3,
        costTime: 2.0,
        risk: 0.35,
        rewardSecondary: { MASTERY: 0.9, STATUS: 0.5, WEALTH: 0.3, LAW: 0.2 },
        requiresLocation: 'guild_hall',
        socialImpact: { RESPECT: 0.5, SUSPENSE: 0.3 as any },
        lawEffect: { certification: 'pending|granted', enforceable: true },
        tradeEffect: { exam_fee: -3, materials: -2 },
        ownershipEffect: {
            license: 'if_passed',
            accessScope: 'guild_contracts',
        },
        requiredMemes: [
            comm.language.written,
            org.workshop_practice,
        ]
    },
    {
        tag: MasteryActionTag.SPECIALIZE_BRANCH,
        costEnergy: -0.2,
        costTime: 1.6,
        rewardSecondary: { POWER: 0.1, EFFICIENCY: 0.4 as any, MASTERY: 0.6 },
        socialImpact: { IDENTITY: 0.3 as any, NICHE_REP: 0.4 as any },
        lawEffect: {
            registryUpdate: 'specialization_noted',
            enforceable: true,
        }
    },
    {
        tag: MasteryActionTag.RECORD_KNOWLEDGE_SCROLL,
        costEnergy: -0.18,
        costTime: 1.4,
        rewardSecondary: { MASTERY: 0.6, KNOWLEDGE: 0.6, TRADITION: 0.2 },
        tradeEffect: { use_parchment: -1, ink: -1, scroll_created: '+1' },
        socialImpact: { SCHOLARLY: 0.5, COMMUNITY: 0.2 },
        ownershipEffect: { ipClaim: 'treatise_v1', author: 'self' },
        lawEffect: { scriptoriumRecord: 'filed', enforceable: true },
        requiredMemes: [
            comm.language.written,
            record.ledgerkeeping,
        ]
    },
    {
        tag: MasteryActionTag.OPTIMIZE_WORKFLOW,
        costEnergy: -0.22,
        costTime: 1.8,
        rewardSecondary: {
            MASTERY: 0.65,
            PRODUCTIVITY: 0.6,
            WEALTH: 0.2,
            STABILITY: 0.2,
        },
        socialImpact: { EFFICIENCY_REP: 0.4 as any },
        ownershipEffect: { toolCalibrations: 'updated' }
    },
    {
        tag: MasteryActionTag.LEARN_FROM_RIVAL,
        costEnergy: -0.2,
        costTime: 1.6,
        risk: 0.12,
        rewardSecondary: { MASTERY: 0.65, KNOWLEDGE: 0.5, COMPETITION: 0.2 },
        socialImpact: { HUMILITY: 0.3, NETWORK: 0.3 },
        lawEffect: { codeOfHonor: 'observe_no_theft', enforceable: true }
    },
    {
        tag: MasteryActionTag.RITUAL_OF_FOCUS,
        costEnergy: -0.12,
        costTime: 0.8,
        rewardSecondary: { SPIRIT: 0.3, REST: 0.2, MASTERY: 0.3 },
        requiresLocation: 'shrine|quiet_room',
        socialImpact: { CALM: 0.4 as any, DISCIPLINE: 0.3 as any },
        lawEffect: { ritual: 'focus_v1', enforceable: false }
    },
    {
        tag: MasteryActionTag.CRAFT_SIGNATURE_WORK,
        costEnergy: -0.5,
        costTime: 3.5,
        risk: 0.2,
        rewardSecondary: {
            MASTERY: 1.0,
            STATUS: 0.5,
            REPUTATION: 0.5,
            WEALTH: 0.3,
        },
        requiresItem: ['rare_materials?'],
        tradeEffect: { spend_rare: -3, price_potential: '+high' },
        socialImpact: { FAME: 0.6, AWE: 0.5, RESPECT: 0.4 },
        ownershipEffect: { claimAuthorship: true, masterpiece: 'created' },
        lawEffect: { hallmark: 'stamped', enforceable: true }
    },
];
