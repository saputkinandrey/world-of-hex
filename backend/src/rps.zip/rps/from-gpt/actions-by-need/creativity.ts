import { ActionDefinition } from '../action-definition';
import { CreativityActionTag } from '../action-tags';
import { comm, econ, health, record, tech } from '../../world/memes';
export const CreativityActions: ActionDefinition[] = [
    {
        tag: CreativityActionTag.SKETCH_CONCEPT,
        costEnergy: -0.06,
        costTime: 0.8,
        rewardSecondary: { CREATIVITY: 0.55, CURIOSITY: 0.3, PURPOSE: 0.2 },
        requiresItem: ['charcoal|chalk', 'scrap_parchment'],
        tradeEffect: { charcoal: -1, parchment: -1 },
        socialImpact: { CREATIVITY: 0.45, INSPIRATION: 0.4 as any },
        ownershipEffect: { sketchbook: 'updated', conceptId: 'new' },
        lawEffect: { none: true },
        requiredMemes: [comm.language.written]
    },
    {
        tag: CreativityActionTag.COMPOSE_SONG_OR_POEM,
        costEnergy: -0.08,
        costTime: 1.2,
        rewardSecondary: {
            CREATIVITY: 0.65,
            COMMUNITY: 0.2,
            TRADITION: 0.2,
            REPUTATION: 0.1,
        },
        socialImpact: { CREATIVITY: 0.5, MOOD: 0.4 as any },
        ownershipEffect: { composition: 'created', performanceRight: 'author' },
        lawEffect: { bardicRoll: 'noted', enforceable: true }
    },
    {
        tag: CreativityActionTag.CRAFT_DECORATIVE_ART,
        costEnergy: -0.2,
        costTime: 1.8,
        rewardSecondary: {
            CREATIVITY: 0.7,
            STATUS: 0.2,
            WEALTH: 0.2,
            TRADITION: 0.2,
        },
        requiresItem: ['wood|clay|metal', 'tools'],
        tradeEffect: { materials: -3, sale_value: '+potential' },
        socialImpact: { CREATIVITY: 0.5, AESTHETICS: 0.5 as any },
        ownershipEffect: { artifact: 'created', provenance: 'atelier' },
        lawEffect: { hallmark: 'stamped', enforceable: true },
        requiredMemes: [
            comm.language.written,
            tech.tool.use_basic,
        ]
    },
    {
        tag: CreativityActionTag.DESIGN_FUNCTIONAL_TOOL,
        costEnergy: -0.22,
        costTime: 2.2,
        rewardSecondary: {
            CREATIVITY: 0.75,
            PRODUCTIVITY: 0.4,
            MASTERY: 0.3,
            WEALTH: 0.2,
        },
        requiresItem: ['workbench', 'draft_tools'],
        tradeEffect: { prototypes: '-1..2', scrap: '+1' },
        socialImpact: { CREATIVITY: 0.55, INNOVATION_REP: 0.4 },
        ownershipEffect: { blueprint: 'tool_v1', license: 'open|guild' },
        lawEffect: { guildPatent: 'pending', enforceable: true }
    },
    {
        tag: CreativityActionTag.PAINT_MURAL_PUBLIC,
        costEnergy: -0.28,
        costTime: 2.6,
        risk: 0.12,
        rewardSecondary: {
            CREATIVITY: 0.9,
            COMMUNITY: 0.5,
            STATUS: 0.3,
            TRADITION: 0.2,
        },
        requiresLocation: 'public_wall|hall',
        tradeEffect: { pigments: -3, limewash: -2, scaffold: '-time' },
        socialImpact: { CREATIVITY: 0.75, VISIBILITY: 0.6, COHESION: 0.3 },
        ownershipEffect: { mural: 'created_public', stewardship: 'council' },
        lawEffect: { muralPermit: 'granted', enforceable: true },
        requiredMemes: [comm.language.written]
    },
    {
        tag: CreativityActionTag.CARVE_STATUE_OR_TOTEM,
        costEnergy: -0.32,
        costTime: 3.0,
        rewardSecondary: {
            CREATIVITY: 0.95,
            STATUS: 0.4,
            SPIRIT: 0.2,
            TRADITION: 0.3,
        },
        requiresItem: ['stone|hardwood', 'chisels'],
        tradeEffect: { stone_blocks: -3, tool_wear: '-minor' },
        socialImpact: { CREATIVITY: 0.7, REVERENCE: 0.4, AWE: 0.4 },
        ownershipEffect: { monument: 'statue|totem', location: 'plaza|grove' },
        lawEffect: { monumentCharter: 'approved', enforceable: true }
    },
    {
        tag: CreativityActionTag.WEAVE_CEREMONIAL_TEXTILE,
        costEnergy: -0.24,
        costTime: 2.2,
        rewardSecondary: {
            CREATIVITY: 0.8,
            TRADITION: 0.5,
            COMMUNITY: 0.3,
            STATUS: 0.2,
        },
        requiresItem: ['loom', 'yarn|dyed_thread'],
        tradeEffect: { yarn: -4, dye: -1 },
        socialImpact: { CREATIVITY: 0.6, IDENTITY: 0.4 as any },
        ownershipEffect: { textile: 'ceremonial', accessScope: 'clan_chest' },
        lawEffect: { clanPattern: 'registered', enforceable: true }
    },
    {
        tag: CreativityActionTag.PERFORM_STREET_THEATRE,
        costEnergy: -0.18,
        costTime: 1.6,
        risk: 0.1,
        rewardSecondary: {
            CREATIVITY: 0.75,
            COMMUNITY: 0.5,
            REPUTATION: 0.3,
            PURPOSE: 0.2,
        },
        requiresLocation: 'market_square',
        tradeEffect: { hat_coins: '+X', props_wear: '-minor' },
        socialImpact: { CREATIVITY: 0.6, MOOD: 0.6, UNITY: 0.3 as any },
        ownershipEffect: {
            troupeAccess: 'granted',
            accessScope: 'square_stage',
        },
        lawEffect: { buskingPermit: 'approved', enforceable: true },
        requiredMemes: [
            health.sanitation_norms,
            health.waste_handling,
            comm.language.written,
        ]
    },
    {
        tag: CreativityActionTag.HOST_SALON_OR_SHOWCASE,
        costEnergy: -0.22,
        costTime: 2.0,
        rewardSecondary: {
            CREATIVITY: 0.8,
            NETWORK: 0.5 as any,
            STATUS: 0.3,
            WEALTH: 0.2,
        },
        requiresLocation: 'hall|atelier',
        tradeEffect: {
            refreshments: -2,
            invitations: '+N',
            sales: '+potential',
        },
        socialImpact: {
            CREATIVITY: 0.6,
            VISIBILITY: 0.6,
            PATRONAGE: 0.4 as any,
        },
        ownershipEffect: { exhibit: 'staged', guestList: 'archived' },
        lawEffect: { eventPermit: 'granted', enforceable: true },
        requiredMemes: [comm.language.written]
    },
    {
        tag: CreativityActionTag.COLLABORATE_ARTISAN_GUILD,
        costEnergy: -0.18,
        costTime: 1.8,
        rewardSecondary: {
            CREATIVITY: 0.7,
            MASTERY: 0.3,
            WEALTH: 0.2,
            COMMUNITY: 0.2,
        },
        tradeEffect: { shared_costs: -2, order_backlog: '+potential' },
        socialImpact: { CREATIVITY: 0.5, TRUST: 0.3, LOYALTY: 0.2 },
        ownershipEffect: { accessScope: 'guild_workshop', grantAccess: true },
        lawEffect: { collaborationCharter: 'filed', enforceable: true }
    },
    {
        tag: CreativityActionTag.EXPERIMENT_NEW_MEDIUM,
        costEnergy: -0.2,
        costTime: 1.8,
        risk: 0.2,
        rewardSecondary: {
            CREATIVITY: 0.8,
            CURIOSITY: 0.4,
            INNOVATION_REP: 0.4 as any,
        },
        tradeEffect: { rare_pigment: -1, binder: -1, waste_risk: 0.3 as any },
        socialImpact: {
            CREATIVITY: 0.6,
            CONTROVERSY: 0.2,
            FASCINATION: 0.3 as any,
        },
        lawEffect: { atelierSafety: 'observed', enforceable: true },
        requiredMemes: [
            health.sanitation_norms,
            health.waste_handling,
        ]
    },
    {
        tag: CreativityActionTag.RESTORE_OLD_ARTWORK,
        costEnergy: -0.24,
        costTime: 2.4,
        risk: 0.15,
        rewardSecondary: {
            CREATIVITY: 0.8,
            TRADITION: 0.5,
            REPUTATION: 0.3,
            COMMUNITY: 0.2,
        },
        requiresSkill: 'restoration',
        tradeEffect: { resin: -1, gold_leaf: -1, linen: -1 },
        socialImpact: { CREATIVITY: 0.55, REVERENCE: 0.5 },
        ownershipEffect: {
            stewardship: 'art_guardian',
            accessScope: 'reliquary',
        },
        lawEffect: { restorationWrit: 'approved', enforceable: true }
    },
    {
        tag: CreativityActionTag.COMMISSIONED_PIECE,
        costEnergy: -0.26,
        costTime: 2.6,
        risk: 0.18,
        rewardSecondary: {
            CREATIVITY: 0.85,
            WEALTH: 0.5,
            STATUS: 0.4,
            REPUTATION: 0.4,
        },
        requiresSkill: 'negotiation|craft',
        tradeEffect: { deposit: '+X', materials: '-Y' },
        socialImpact: {
            CREATIVITY: 0.6,
            PATRONAGE: 0.6,
            EXPECTATION: 0.3 as any,
        },
        ownershipEffect: {
            commissionContract: 'signed',
            rights: 'artist_copyright',
        },
        lawEffect: { contractRoll: 'filed', enforceable: true }
    },
    {
        tag: CreativityActionTag.TEACH_ART_WORKSHOP,
        costEnergy: -0.2,
        costTime: 2.0,
        rewardSecondary: {
            CREATIVITY: 0.75,
            COMMUNITY: 0.4,
            MASTERY: 0.3,
            STATUS: 0.2,
        },
        requiresLocation: 'hall|atelier',
        tradeEffect: { fee_collected: '+X', materials_used: -2 },
        socialImpact: { CREATIVITY: 0.55, RESPECT: 0.4, NETWORK: 0.3 },
        ownershipEffect: { accessScope: 'classroom', grantAccess: true },
        lawEffect: { classRoll: 'recorded', enforceable: true },
        requiredMemes: [comm.language.written]
    },
    {
        tag: CreativityActionTag.RITUALIZE_CREATIVE_PROCESS,
        costEnergy: -0.12,
        costTime: 1.0,
        rewardSecondary: {
            SPIRIT: 0.3,
            DISCIPLINE: 0.3 as any,
            STABILITY: 0.2,
            CREATIVITY: 0.6,
        },
        requiresLocation: 'quiet_room|shrine',
        socialImpact: { CREATIVITY: 0.45, FOCUS: 0.4 as any },
        lawEffect: { atelierRite: 'noted', enforceable: false }
    },
    {
        tag: CreativityActionTag.REGISTER_ART_MARK,
        costEnergy: -0.08,
        costTime: 0.8,
        rewardSecondary: { CREATIVITY: 0.55, STATUS: 0.2, POWER: 0.1 },
        tradeEffect: { seal_fee: -1, stamp: 'issued' },
        socialImpact: {
            CREATIVITY: 0.4,
            CREDIBILITY: 0.4,
            IDENTITY: 0.3 as any,
        },
        ownershipEffect: { artMark: 'registered', provenance: 'traceable' },
        lawEffect: { hallmarkRoll: 'updated', enforceable: true },
        requiredMemes: [
            record.ledgerkeeping,
            econ.pooling_common_fund,
            comm.language.written,
        ]
    },
];
